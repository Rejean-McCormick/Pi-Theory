# Niveaux épistémiques

## E0 — Fait mathématique/physique établi
Ex. définition de π, identité d'Euler, théorème de Noether, théorie de Shannon.

## E1 — Observation reproductible dans le corpus
Ex. une segmentation définie de la fenêtre étudiée produit certains tokens.

## E2 — Lecture sémiotique
Ex. `M ≈ aime`, `B0UM ≈ boom`, `16 → seize ≈ size`.

## E3 — Convergence comparative
Ex. différenciation/réintégration chez Böhme, Louria, Simondon, Empédocle.

## E4 — Hypothèse métaphysique
Ex. le réel comme résolution d'une structure mathématique.

## E5 — Hypothèse physique forte
Ex. matière = manifestation spécifique de π avec prédictions quantitatives.

### Règle éditoriale
Chaque chapitre du futur livre doit marquer explicitement le niveau auquel appartient chaque proposition. Une convergence historique ou conceptuelle n'est jamais une validation physique.

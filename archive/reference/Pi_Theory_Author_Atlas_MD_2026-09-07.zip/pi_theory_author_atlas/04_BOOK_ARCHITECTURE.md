# Architecture de livre proposée — basée sur l'atlas

## I. π : objet mathématique, représentation, énigme
1. π exact
2. π comme invariant de rotation
3. développement décimal et base de représentation
4. histoire du décodage v12 → v13

## II. Le kernel
5. Love/cohésion
6. Good/orientation
7. Divide/Process
8. Assemble/Reunite
9. B0UM/seuil
10. 88/SIZE

## III. De la distinction à la mesure
11. Spencer-Brown
12. Cues
13. Hegel
14. Cantor/Riemann
15. Weyl/Einstein

## IV. Processus, information et matière
16. Whitehead/Simondon
17. Shannon/Turing/Landauer
18. Wheeler/Bohm
19. matière comme mémoire

## V. Vie et conscience
20. Darwin / morphogenèse
21. systèmes et auto-organisation
22. Varela/Deacon
23. Teilhard et complexité-conscience
24. conscience réflexive

## VI. Traditions métaphysiques et spirituelles
25. Plotin/Proclus/Denys/Érigène
26. Cues/Böhme
27. Louria/Vital
28. Saint-Martin/Chevillon
29. convergences et différences

## VII. Méthode
30. sémiotique de Peirce
31. coût interprétatif
32. null models et préenregistrement
33. Rosetta/kOA
34. ce qui pourrait falsifier la théorie

## VIII. Ontologie proposée
35. Source ≠ structure ≠ représentation ≠ matière
36. π exact / résolu / manifesté
37. hypothèse cosmique
38. limites et programme de recherche

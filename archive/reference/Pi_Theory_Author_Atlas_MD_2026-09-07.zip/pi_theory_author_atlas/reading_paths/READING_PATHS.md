# Parcours de lecture

## Parcours A — métaphysique de la manifestation
Plotin → Proclus → Pseudo-Denys → Érigène → Cues → Böhme → Schelling → Whitehead.

## Parcours B — distinction → mesure
Spencer-Brown → Hegel (Mesure) → Cantor → Riemann → Weyl → Einstein.

## Parcours C — information → matière
Shannon → Turing → Landauer → Wheeler → Bohm/Hiley → Deacon.

## Parcours D — vivant → conscience
Darwin → D'Arcy Thompson → Turing morphogenèse → Waddington → Maturana/Varela → Deacon → Teilhard (comparatif).

## Parcours E — Teilhard / science et spiritualité
Bergson → Teilhard → Whitehead → Prigogine/Stengers → Haught.

## Parcours F — ésotérisme occidental historiquement contrôlé
Pseudo-Denys → Böhme → Saint-Martin → Martinès de Pasqually → Papus → Chevillon, accompagné de Hanegraaff/Faivre.

## Parcours court prioritaire pour le manuscrit
Cues → Hegel → Simondon → Weyl → Shannon → Landauer → Teilhard → Peirce.

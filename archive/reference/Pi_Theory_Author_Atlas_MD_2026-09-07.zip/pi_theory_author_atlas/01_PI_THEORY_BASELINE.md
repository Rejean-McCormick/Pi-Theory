# Baseline Pi Theory — version de travail

## Statut
Ce dossier prend **Pi v13** comme centre de gravité conceptuel actuel. Les versions antérieures restent des archives de découverte.

## Kernel

`M → BIEN → GIHECEF → JNON → B0UM → SIZE`

Lecture fonctionnelle :

`Cohésion → orientation/valeur → différenciation/traitement → assemblage/réintégration → seuil/événement → échelle/magnitude`

Pulse central :

`DIFFÉRENCIER ↔ INTÉGRER`

## 88 / SIZE
Le chemin sémiotique à documenter est :

- `8, 8` : deux formes pouvant être iconiquement rapprochées de `∞, ∞`;
- `8 + 8 = 16`;
- français `16 = seize`;
- rapprochement phonétique `seize ≈ size`;
- abstraction : `SIZE = magnitude / scale`.

Ce n'est **pas** l'équation `∞ + ∞ = 16`.

## Trois niveaux de π
1. **π exact** : objet mathématique exact.
2. **π représenté/résolu** : développement dans une base donnée.
3. **π manifesté** : hypothèse métaphysique selon laquelle le cosmos actualise ou résout physiquement une structure dont π serait une expression privilégiée.

## Thèse forte à tester
`Source → cohésion → différence → relation → intégration → seuil → échelle → mesure → matière → vie → conscience → retour réflexif`

Cette chaîne est une **carte de recherche**, non une démonstration.

# Chronologie intellectuelle — usage technique

Cette chronologie doit être utilisée avec prudence : ordre chronologique ≠ influence.

## Grandes lignes
1. Présocratiques / Platonisme : nombre, harmonie, séparation/réunion.
2. Néoplatonisme : procession, participation, retour.
3. Christianisation apophatique : Denys, Érigène.
4. Infini mathématico-théologique : Nicolas de Cues.
5. Théosophie / Kabbale : Böhme, Louria/Vital.
6. Modernité : Leibniz, Spinoza, Schelling, Hegel.
7. Mathématiques/physique modernes : Riemann, Cantor, Einstein, Weyl, Noether.
8. Processus / évolution / information : Bergson, Whitehead, Teilhard, Shannon, Wiener, Turing.
9. Individuation / complexité / cognition : Simondon, Prigogine, Maturana/Varela, Deacon.
10. Fondements contemporains : Wheeler, Bohm, Penrose, Tegmark, Rovelli, Friston.

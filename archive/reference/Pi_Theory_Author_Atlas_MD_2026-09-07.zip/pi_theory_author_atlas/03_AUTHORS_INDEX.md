# Index des auteurs

| Auteur | Dates | Domaine | Priorité | Fiche |
|---|---|---|---|---|
| Pythagore et les Pythagoriciens | VIe–Ve s. av. J.-C. | philosophie antique / mathématiques / harmonie | A | [fiche](authors/001_pythagore_et_les_pythagoriciens.md) |
| Empédocle | c. 494–434 av. J.-C. | présocratique / cosmologie | A | [fiche](authors/002_empedocle.md) |
| Platon | c. 428–348 av. J.-C. | métaphysique / philosophie des mathématiques | A | [fiche](authors/003_platon.md) |
| Plotin | 204/5–270 | néoplatonisme | A | [fiche](authors/004_plotin.md) |
| Proclus | 412–485 | néoplatonisme systématique | A | [fiche](authors/005_proclus.md) |
| Pseudo-Denys l'Aréopagite | fin Ve–début VIe s. | théologie apophatique / néoplatonisme chrétien | A | [fiche](authors/006_pseudo_denys_l_areopagite.md) |
| Jean Scot Érigène | c. 800–c. 877 | métaphysique chrétienne / néoplatonisme | A | [fiche](authors/007_jean_scot_erigene.md) |
| Nicolas de Cues | 1401–1464 | métaphysique / mathématiques / théologie | A | [fiche](authors/008_nicolas_de_cues.md) |
| Giordano Bruno | 1548–1600 | métaphysique / cosmologie | B | [fiche](authors/009_giordano_bruno.md) |
| Jacob Böhme | 1575–1624 | théosophie chrétienne / métaphysique | A | [fiche](authors/010_jacob_bohme.md) |
| Paracelse | 1493/4–1541 | médecine / philosophie naturelle / signatures | C | [fiche](authors/011_paracelse.md) |
| Martinès de Pasqually | c. 1727–1774 | théurgie / martinisme primitif | B | [fiche](authors/012_martines_de_pasqually.md) |
| Louis-Claude de Saint-Martin | 1743–1803 | mystique chrétienne / martinisme | B | [fiche](authors/013_louis_claude_de_saint_martin.md) |
| Papus (Gérard Encausse) | 1865–1916 | occultisme / martinisme moderne | C | [fiche](authors/014_papus_gerard_encausse.md) |
| Constant Chevillon | 1880–1944 | ésotérisme chrétien / martinisme | B | [fiche](authors/015_constant_chevillon.md) |
| Sefer Yetzirah (tradition) | Antiquité tardive / haut Moyen Âge | mystique juive / cosmologie des lettres et nombres | A | [fiche](authors/016_sefer_yetzirah_tradition.md) |
| Isaac Louria | 1534–1572 | Kabbale lourianique | A | [fiche](authors/017_isaac_louria.md) |
| Hayyim Vital | 1542–1620 | Kabbale lourianique / transmission | A | [fiche](authors/018_hayyim_vital.md) |
| Leibniz | 1646–1716 | métaphysique / mathématiques | A/B | [fiche](authors/019_leibniz.md) |
| Spinoza | 1632–1677 | métaphysique / immanence | B | [fiche](authors/020_spinoza.md) |
| Schelling | 1775–1854 | idéalisme allemand / philosophie de la nature | A | [fiche](authors/021_schelling.md) |
| Hegel | 1770–1831 | idéalisme allemand / logique | A | [fiche](authors/022_hegel.md) |
| Bergson | 1859–1941 | philosophie du temps / évolution | B | [fiche](authors/023_bergson.md) |
| Alfred North Whitehead | 1861–1947 | philosophie du processus / mathématiques | A | [fiche](authors/024_alfred_north_whitehead.md) |
| Pierre Teilhard de Chardin | 1881–1955 | paléontologie / théologie / évolution cosmique | A | [fiche](authors/025_pierre_teilhard_de_chardin.md) |
| Gilbert Simondon | 1924–1989 | philosophie de la technique / individuation | A | [fiche](authors/026_gilbert_simondon.md) |
| George Spencer-Brown | 1923–2016 | logique / formes | A | [fiche](authors/027_george_spencer_brown.md) |
| Charles S. Peirce | 1839–1914 | logique / sémiotique / métaphysique | A | [fiche](authors/028_charles_s_peirce.md) |
| Ernst Cassirer | 1874–1945 | néokantisme / formes symboliques | B | [fiche](authors/029_ernst_cassirer.md) |
| Leonhard Euler | 1707–1783 | mathématiques | A | [fiche](authors/030_leonhard_euler.md) |
| Georg Cantor | 1845–1918 | théorie des ensembles / infini | A | [fiche](authors/031_georg_cantor.md) |
| Bernhard Riemann | 1826–1866 | géométrie / analyse | A | [fiche](authors/032_bernhard_riemann.md) |
| Hermann Weyl | 1885–1955 | mathématiques / physique / philosophie | A | [fiche](authors/033_hermann_weyl.md) |
| Emmy Noether | 1882–1935 | mathématiques / physique théorique | A | [fiche](authors/034_emmy_noether.md) |
| Kurt Gödel | 1906–1978 | logique / fondements | B | [fiche](authors/035_kurt_godel.md) |
| Alan Turing | 1912–1954 | logique / calcul / morphogenèse | A | [fiche](authors/036_alan_turing.md) |
| Gregory Chaitin | 1947– | algorithmic information theory | B | [fiche](authors/037_gregory_chaitin.md) |
| Andrey Kolmogorov | 1903–1987 | probabilités / complexité | A/B | [fiche](authors/038_andrey_kolmogorov.md) |
| Albert Einstein | 1879–1955 | physique théorique | A | [fiche](authors/039_albert_einstein.md) |
| Niels Bohr | 1885–1962 | physique quantique / philosophie de la physique | B | [fiche](authors/040_niels_bohr.md) |
| Werner Heisenberg | 1901–1976 | physique quantique / philosophie | B | [fiche](authors/041_werner_heisenberg.md) |
| Erwin Schrödinger | 1887–1961 | physique quantique / philosophie du vivant | B | [fiche](authors/042_erwin_schrodinger.md) |
| Wolfgang Pauli | 1900–1958 | physique quantique / symétrie / dialogue avec Jung | B | [fiche](authors/043_wolfgang_pauli.md) |
| John Archibald Wheeler | 1911–2008 | physique théorique / fondements | A/B | [fiche](authors/044_john_archibald_wheeler.md) |
| David Bohm | 1917–1992 | physique théorique / philosophie | A | [fiche](authors/045_david_bohm.md) |
| Basil Hiley | 1935– | physique mathématique | B | [fiche](authors/046_basil_hiley.md) |
| Roger Penrose | 1931– | mathématiques / gravitation / conscience | B | [fiche](authors/047_roger_penrose.md) |
| Max Tegmark | 1967– | cosmologie / fondements | B | [fiche](authors/048_max_tegmark.md) |
| Carlo Rovelli | 1956– | gravité quantique / philosophie de la physique | B | [fiche](authors/049_carlo_rovelli.md) |
| Lee Smolin | 1955– | gravité quantique / cosmologie | B | [fiche](authors/050_lee_smolin.md) |
| Julian Barbour | 1937– | fondements de la physique / temps | B | [fiche](authors/051_julian_barbour.md) |
| Claude Shannon | 1916–2001 | théorie de l'information | A | [fiche](authors/052_claude_shannon.md) |
| Rolf Landauer | 1927–1999 | physique de l'information | A | [fiche](authors/053_rolf_landauer.md) |
| Norbert Wiener | 1894–1964 | cybernétique | A/B | [fiche](authors/054_norbert_wiener.md) |
| W. Ross Ashby | 1903–1972 | cybernétique / systèmes | A/B | [fiche](authors/055_w_ross_ashby.md) |
| Heinz von Foerster | 1911–2002 | cybernétique de second ordre | B | [fiche](authors/056_heinz_von_foerster.md) |
| Ludwig von Bertalanffy | 1901–1972 | théorie générale des systèmes | B | [fiche](authors/057_ludwig_von_bertalanffy.md) |
| Gregory Bateson | 1904–1980 | anthropologie / cybernétique / écologie de l'esprit | A/B | [fiche](authors/058_gregory_bateson.md) |
| Humberto Maturana | 1928–2021 | biologie / cognition | B | [fiche](authors/059_humberto_maturana.md) |
| Francisco Varela | 1946–2001 | biologie / cognition / phénoménologie | A/B | [fiche](authors/060_francisco_varela.md) |
| Ilya Prigogine | 1917–2003 | thermodynamique / systèmes hors équilibre | A/B | [fiche](authors/061_ilya_prigogine.md) |
| Stuart Kauffman | 1939– | biologie théorique / complexité | B | [fiche](authors/062_stuart_kauffman.md) |
| Terrence Deacon | 1950– | anthropologie biologique / sémiotique | A/B | [fiche](authors/063_terrence_deacon.md) |
| Karl Friston | 1959– | neurosciences théoriques | B/C | [fiche](authors/064_karl_friston.md) |
| Charles Darwin | 1809–1882 | biologie évolutive | A/B | [fiche](authors/065_charles_darwin.md) |
| D'Arcy Wentworth Thompson | 1860–1948 | biologie mathématique / forme | A/B | [fiche](authors/066_d_arcy_wentworth_thompson.md) |
| Conrad Waddington | 1905–1975 | biologie du développement | B | [fiche](authors/067_conrad_waddington.md) |
| René Thom | 1923–2002 | mathématiques / morphogenèse | A/B | [fiche](authors/068_rene_thom.md) |
| Brian Goodwin | 1931–2009 | biologie théorique | C | [fiche](authors/069_brian_goodwin.md) |
| William James | 1842–1910 | psychologie / philosophie | B | [fiche](authors/070_william_james.md) |
| Carl Gustav Jung | 1875–1961 | psychologie analytique | C | [fiche](authors/071_carl_gustav_jung.md) |
| Marie-Louise von Franz | 1915–1998 | psychologie analytique / nombre | C | [fiche](authors/072_marie_louise_von_franz.md) |
| Giulio Tononi | 1960– | neurosciences / théorie de la conscience | C | [fiche](authors/073_giulio_tononi.md) |
| Evan Thompson | 1962– | philosophie de l'esprit / sciences cognitives | B | [fiche](authors/074_evan_thompson.md) |
| Ian Barbour | 1923–2013 | science et religion | B | [fiche](authors/076_ian_barbour.md) |
| John Polkinghorne | 1930–2021 | physique / théologie | B | [fiche](authors/077_john_polkinghorne.md) |
| John F. Haught | 1942– | théologie / évolution | B | [fiche](authors/078_john_f_haught.md) |
| Luciano Floridi | 1964– | philosophie de l'information | B | [fiche](authors/079_luciano_floridi.md) |
| Niklas Luhmann | 1927–1998 | théorie des systèmes / sociologie | C | [fiche](authors/080_niklas_luhmann.md) |
| René Guénon | 1886–1951 | métaphysique traditionnelle / critique de la modernité | B/C | [fiche](authors/081_rene_guenon.md) |

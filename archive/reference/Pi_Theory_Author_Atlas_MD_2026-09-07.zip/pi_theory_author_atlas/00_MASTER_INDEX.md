# Pi Theory — Atlas technique des auteurs et disciplines

## Entrées principales
- [Baseline Pi Theory](01_PI_THEORY_BASELINE.md)
- [Niveaux épistémiques](02_EPISTEMIC_LEVELS.md)
- [Index des auteurs](03_AUTHORS_INDEX.md)
- [Architecture du futur livre](04_BOOK_ARCHITECTURE.md)
- [Top 25 indispensable](05_TOP_25_INDISPENSABLE.md)
- [Inventaire 100+](06_TOP_100_EXTENDED.md)

## Modules thématiques
- [Source et manifestation](thematic/01_SOURCE_AND_MANIFESTATION.md)
- [Différenciation / intégration](thematic/02_DIFFERENTIATION_INTEGRATION.md)
- [Infini / Scale / mesure](thematic/03_INFINITY_SCALE_MEASURE.md)
- [Mathématiques et réalité](thematic/04_MATHEMATICS_AND_REALITY.md)
- [Physique et cosmologie](thematic/05_PHYSICS_COSMOLOGY.md)
- [Information et calcul](thematic/06_INFORMATION_COMPUTATION.md)
- [Complexité et systèmes](thematic/07_COMPLEXITY_SYSTEMS.md)
- [Biologie / morphogenèse](thematic/08_BIOLOGY_EVOLUTION_MORPHOGENESIS.md)
- [Conscience](thematic/09_CONSCIOUSNESS.md)
- [Teilhard / science-religion](thematic/10_TEILHARD_SCIENCE_RELIGION.md)
- [Sémiotique / langage](thematic/11_SEMIOTICS_LANGUAGE_SYMBOL.md)
- [Kabbale](thematic/12_KABBALAH.md)
- [Böhme / martinisme](thematic/13_BOEHME_MARTINISM.md)
- [Processus / individuation](thematic/14_PROCESS_INDIVIDUATION.md)
- [Critiques / garde-fous](thematic/15_CRITICS_AND_GUARDRAILS.md)

## Matrices
- [Auteurs × thèmes](matrices/AUTHOR_THEME_MATRIX.md)
- [Influence vs convergence](matrices/INFLUENCE_VS_CONVERGENCE.md)

## Recherche
- [Préenregistrement](research/PREREGISTRATION_TEMPLATE.md)
- [Hypothèses testables](research/TESTABLE_HYPOTHESES.md)

## Bibliographie / scholars
- [Bibliographie maîtresse](sources/MASTER_BIBLIOGRAPHY.md)
- [Scholars](sources/SCHOLARS_INDEX.md)
- [Sources numériques vérifiées](sources/DIGITAL_SOURCE_REGISTRY.md)

## Parcours
- [Reading paths](reading_paths/READING_PATHS.md)

## Principe éditorial
Ce dépôt distingue systématiquement :
**fait établi → observation du corpus → interprétation → convergence comparative → hypothèse métaphysique → hypothèse physique.**

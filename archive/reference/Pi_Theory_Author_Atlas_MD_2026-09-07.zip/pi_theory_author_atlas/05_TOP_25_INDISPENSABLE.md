# Top 25 indispensable

1. **Pythagore et les Pythagoriciens** — Point de départ historique pour toute ontologie où nombre, proportion et ordre ne sont pas de simples instruments descriptifs.
2. **Empédocle** — Très proche du pulse différenciation ↔ intégration : l'Amour rassemble, la Discorde sépare, et les mondes apparaissent dans leurs régimes intermédiaires.
3. **Platon** — Le Timée fournit un paradigme majeur d'un cosmos dont l'intelligibilité passe par forme, proportion, mesure et géométrie.
4. **Plotin** — Modèle canonique pour Source → procession → multiplicité → retour sans réduire la Source à un étant interne.
5. **Proclus** — L'architecture demeurer → procéder → revenir est l'une des structures les plus proches de la distinction Source / manifestation / réintégration.
6. **Pseudo-Denys l'Aréopagite** — Fondamental pour éviter l'identification Source = nombre : le principe ultime excède toute détermination et toute représentation.
7. **Jean Scot Érigène** — Très forte convergence avec Source → causes → effets manifestés → retour; permet de séparer Source, grammaire générative et monde.
8. **Nicolas de Cues** — Interlocuteur majeur pour 88/SIZE, infini, mesure, cercle, représentation finie d'un principe qui la dépasse.
9. **Jacob Böhme** — L'un des parallèles les plus forts : la différence et la contrariété deviennent conditions productives de manifestation.
10. **Sefer Yetzirah (tradition)** — Source majeure pour l'idée que lettres, nombres et opérations combinatoires peuvent être pensés comme grammaire de création.
11. **Isaac Louria** — Comparaison indépendante puissante : infini → contraction → différenciation/brisure → réparation/réintégration.
12. **Hayyim Vital** — Conduit textuel indispensable si le livre utilise réellement Louria.
13. **Leibniz** — Réunit harmonie, mathématiques, infinitésimal et pluralité de centres représentatifs.
14. **Schelling** — Pont majeur entre Böhme et la modernité; différenciation, opposition et nature productive sont directement utiles.
15. **Hegel** — Probablement le complément philosophique le plus puissant pour SIZE → mesure : la mesure articule qualité et quantité.
16. **Alfred North Whitehead** — Très fort pour la thèse matière comme héritage/stabilisation de processus et pour l'intégration du multiple en un nouvel un.
17. **Pierre Teilhard de Chardin** — Auteur clé pour élargir Pi Theory au vivant et à la conscience : matière → complexification → vie → pensée → réflexivité.
18. **Gilbert Simondon** — Probablement le meilleur langage moderne pour potentiel → résolution de tension → nouvelle structure / nouveau régime.
19. **George Spencer-Brown** — Interlocuteur direct pour la question de la première distinction : une forme apparaît quand une frontière est tracée.
20. **Charles S. Peirce** — Indispensable pour décomposer le passage 88 → icône d'infini → nombre → mot → fonction et pour analyser le statut du sens.
21. **Leonhard Euler** — Ancre mathématique rigoureuse du dossier e/π/i via e^{iθ}=cosθ+i sinθ.
22. **Georg Cantor** — Garde-fou indispensable : 'infini' n'est pas un concept unique; les deux infinis de 88 doivent être définis avant toute formalisation.
23. **Bernhard Riemann** — Essentiel pour corriger SIZE → space : une multiplicité ou une grandeur possible ne suffit pas à déterminer une métrique.
24. **Hermann Weyl** — Auteur technique central pour Scale → comparaison locale → mesure → géométrie → physique.
25. **Emmy Noether** — Donne un sens technique puissant à l'idée que ce qui demeure sous transformation peut structurer la physique.

# Template de préenregistrement — prochains décodages

## 1. Dataset
- constante:
- base numérique:
- fenêtre de digits:
- sens de lecture:

## 2. Règles fixées avant inspection
- segmentation:
- mapping:
- traitement de 0:
- opérations arithmétiques admissibles:
- langues admissibles:
- seuil phonétique:
- stop rule:

## 3. Prédictions
- nombre de blocs attendu:
- rôles attendus:
- ordre attendu:
- motifs attendus:
- critères de succès/échec:

## 4. Contrôles
- chaînes aléatoires:
- permutations conservant histogramme:
- fenêtres aléatoires de π:
- e, √2, φ:
- évaluateurs aveugles:

## 5. Publication
Publier également les résultats nuls et toutes les décisions post hoc.

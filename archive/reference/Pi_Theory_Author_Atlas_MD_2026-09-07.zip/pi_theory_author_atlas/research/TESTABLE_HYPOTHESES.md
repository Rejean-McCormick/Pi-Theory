# Hypothèses testables

## H1 — stabilité du décodage
La grammaire verrouillée produit plus de cohérence sur la fenêtre cible que sur des nulls appariés.

## H2 — prédiction Rosetta
Deux grammaires indépendantes permettent de prédire une fonction encore non identifiée dans une troisième.

## H3 — distinction → mesure
Un ensemble minimal d'axiomes de distinction/composition peut générer formellement ordre puis valuation; préciser les axiomes additionnels nécessaires pour une métrique.

## H4 — matière comme mémoire
La formation d'un système laisse des signatures quantifiables de son histoire (hystérésis, information mutuelle, causal states, path dependence).

## H5 — hypothèse physique π-spécifique
Une formulation de Pi Theory doit produire au moins une quantité dimensionless, relation d'échelle, spectre, phase ou invariant quantitativement distinct des modèles concurrents.

### Critère de statut
Sans H5, « le cosmos est π qui se résout » reste une métaphysique possible, pas une théorie physique confirmée.

# Scholars contemporains / historiens de référence

| Scholar | Domaine | Priorité | Fiche |
|---|---|---|---|
| Lloyd P. Gerson | Plotin, platonisme ancien | A | [fiche](../scholars/001_lloyd_p_gerson.md) |
| Dominic O'Meara | néoplatonisme, Plotin, Proclus | A | [fiche](../scholars/002_dominic_o_meara.md) |
| Carlos Steel | Proclus, philosophie médiévale | A | [fiche](../scholars/003_carlos_steel.md) |
| Andrew Louth | Pseudo-Denys, mystique chrétienne | A | [fiche](../scholars/004_andrew_louth.md) |
| Paul Rorem | Pseudo-Denys | A | [fiche](../scholars/005_paul_rorem.md) |
| Dermot Moran | Jean Scot Érigène, phénoménologie | A | [fiche](../scholars/006_dermot_moran.md) |
| Deirdre Carabine | Érigène, théologie négative | B | [fiche](../scholars/007_deirdre_carabine.md) |
| Jasper Hopkins | Nicolas de Cues | A | [fiche](../scholars/008_jasper_hopkins.md) |
| Andrew Weeks | Jacob Böhme | A | [fiche](../scholars/009_andrew_weeks.md) |
| Cyril O'Regan | Böhme, idéalisme allemand, théologie | A | [fiche](../scholars/010_cyril_o_regan.md) |
| Ariel Hessayon | Böhme et réception | B | [fiche](../scholars/011_ariel_hessayon.md) |
| Lawrence Fine | Isaac Louria, Kabbale | A | [fiche](../scholars/012_lawrence_fine.md) |
| Moshe Idel | Kabbale et mystique juive | A | [fiche](../scholars/013_moshe_idel.md) |
| Gershom Scholem | histoire de la Kabbale | A | [fiche](../scholars/014_gershom_scholem.md) |
| Elliot R. Wolfson | Kabbale, symbolisme, langage | A | [fiche](../scholars/015_elliot_r_wolfson.md) |
| Boaz Huss | Kabbale moderne / études critiques | B | [fiche](../scholars/016_boaz_huss.md) |
| Wouter J. Hanegraaff | ésotérisme occidental | A | [fiche](../scholars/017_wouter_j_hanegraaff.md) |
| Antoine Faivre | ésotérisme occidental | A/B | [fiche](../scholars/018_antoine_faivre.md) |
| Isabelle Stengers | Whitehead, Prigogine, philosophie des sciences | A | [fiche](../scholars/019_isabelle_stengers.md) |
| Muriel Combes | Simondon | A | [fiche](../scholars/020_muriel_combes.md) |
| Jean-Hugues Barthélémy | Simondon | A | [fiche](../scholars/021_jean_hugues_barthelemy.md) |
| Thomas Ryckman | Weyl, relativité, philosophie de la physique | A | [fiche](../scholars/022_thomas_ryckman.md) |
| Erhard Scholz | Weyl, histoire des mathématiques et jauge | A | [fiche](../scholars/023_erhard_scholz.md) |
| Yvette Kosmann-Schwarzbach | Noether | A | [fiche](../scholars/024_yvette_kosmann_schwarzbach.md) |
| T. L. Short | Peirce | A | [fiche](../scholars/025_t_l_short.md) |
| Cheryl Misak | Peirce, pragmatisme | B | [fiche](../scholars/026_cheryl_misak.md) |
| Ursula King | Teilhard de Chardin | A | [fiche](../scholars/027_ursula_king.md) |
| John F. Haught | Teilhard / science et religion | A/B | [fiche](../scholars/028_john_f_haught.md) |
| Evan Thompson | Varela, enaction, esprit et vie | A | [fiche](../scholars/029_evan_thompson.md) |
| Sonu Shamdasani | Jung, histoire de la psychologie | A/B | [fiche](../scholars/030_sonu_shamdasani.md) |

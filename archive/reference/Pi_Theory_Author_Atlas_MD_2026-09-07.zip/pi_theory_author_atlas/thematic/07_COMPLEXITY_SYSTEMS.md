# Complexité, systèmes et auto-organisation

## Auteurs
Wiener, Ashby, von Bertalanffy, von Foerster, Bateson, Prigogine, Kauffman, Maturana, Varela, Luhmann.

## Pertinence
Ces traditions permettent de remplacer des correspondances vagues par :
- variables d'état;
- feedback;
- variété;
- stabilité;
- bifurcation;
- couplage;
- organisation;
- émergence.

## Rosetta/kOA
Le test fort n'est pas « les systèmes se ressemblent », mais : deux grammaires peuvent-elles prédire une relation non encore identifiée dans la troisième ?

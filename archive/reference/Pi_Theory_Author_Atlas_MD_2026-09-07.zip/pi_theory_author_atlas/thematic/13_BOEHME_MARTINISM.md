# Böhme, Saint-Martin, martinisme, Chevillon

## Filiation réelle
Böhme exerce une influence majeure sur Saint-Martin. Le martinisme moderne, Papus et Chevillon appartiennent à une histoire plus tardive et éclectique.

## Rôle dans le livre
- Böhme : source métaphysique profonde;
- Saint-Martin : transmission et réintégration;
- Martinès : architecture de réintégration;
- Papus : contexte institutionnel;
- Chevillon : point de confluence moderne et point de départ de la recherche.

## Kernel
Böhme est surtout utile pour :
`indétermination → volonté/désir → contrariété → qualités → manifestation`.

# Information, calcul et matière

## Garde-fous
**Shannon** : information statistique, pas sens.
**Landauer** : l'information physiquement existante doit être implémentée physiquement.
**Turing** : préciser ce qu'est un calcul effectif.
**Kolmogorov/Chaitin** : complexité et compressibilité.

## Échelle des thèses
1. Un état physique porte des traces de son histoire.
2. Un support physique peut stocker de l'information.
3. La matière peut être modélisée comme processus/inheritance.
4. La matière est spécifiquement la résolution de π.

Les niveaux 1–3 ont des analogues scientifiques/philosophiques sérieux. Le niveau 4 exige une théorie nouvelle.

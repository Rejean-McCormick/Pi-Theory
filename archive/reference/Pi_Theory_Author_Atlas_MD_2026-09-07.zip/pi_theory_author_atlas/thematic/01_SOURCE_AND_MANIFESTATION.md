# Source, procession et manifestation

## Question
Comment un principe non déterminé peut-il donner lieu au déterminé sans devenir simplement une chose parmi les choses ?

## Auteurs de premier rang
- Plotin
- Proclus
- Pseudo-Denys
- Jean Scot Érigène
- Nicolas de Cues
- Böhme
- Spinoza comme contrepoint d'immanence

## Pi Theory
La distinction `Source ≠ principe de manifestation ≠ ordre manifesté` doit être protégée. Elle empêche l'identification naïve `Dieu = π = digits = matière`.

## Problèmes techniques
- causalité sans temporalité;
- dépendance ontologique vs production chronologique;
- exactitude intemporelle vs manifestation séquentielle;
- immanence vs transcendance.

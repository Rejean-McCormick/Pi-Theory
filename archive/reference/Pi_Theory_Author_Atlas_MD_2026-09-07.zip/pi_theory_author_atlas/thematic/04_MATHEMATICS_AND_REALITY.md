# Mathématiques et réalité

## Positions à comparer
- Platonisme mathématique : Penrose, Gödel (nuancé)
- Structuralisme : Resnik, Shapiro
- Mathematical Universe : Tegmark
- Processus : Whitehead
- Relationalisme physique : Rovelli
- Temps fondamental : Smolin

## Question Pi Theory
Le réel est-il :
1. décrit par des mathématiques;
2. instanciation d'une structure mathématique;
3. calcul d'une structure;
4. résolution physique de π ?

Ces quatre propositions ne sont pas équivalentes.

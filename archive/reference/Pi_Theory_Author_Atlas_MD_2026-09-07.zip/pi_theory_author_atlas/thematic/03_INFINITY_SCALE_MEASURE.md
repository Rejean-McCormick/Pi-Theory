# Infini, échelle, magnitude et mesure

## Point de départ
`88 → ∞ ∞` est iconique/symbolique; `8+8=16 → seize≈size` est arithmético-phonétique.

## Question indépendante
Peut-on construire une chaîne formelle :

`distinction → ordre → comparabilité → valuation → magnitude → mesure → métrique` ?

## Auteurs/contrôles
- Nicolas de Cues : fini/infini et proportion;
- Hegel : quantité → mesure;
- Cantor : pluralité des notions d'infini;
- Riemann : multiplicité ≠ métrique;
- Weyl : mesure locale, géométrie, symétrie;
- Einstein : métrique physique dynamique.

## Règle
`SIZE ≠ espace`. L'espace physique exige une structure métrique et dynamique beaucoup plus riche.

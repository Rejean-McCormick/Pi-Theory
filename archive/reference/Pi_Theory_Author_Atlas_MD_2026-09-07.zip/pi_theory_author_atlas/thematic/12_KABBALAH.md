# Kabbale — module technique

## Sources primaires
Sefer Yetzirah, Zohar, Hayyim Vital.

## Louria/Vital
`Ein-Sof → tzimtzum → shevirah → tikkun`.

## Comparaison avec Pi Theory
La proximité structurale se situe dans :
- infini/source;
- création d'un domaine de différenciation;
- rupture/séparation;
- réintégration.

## Discipline historique
Lire Louria à travers Vital et les scholars modernes : Lawrence Fine, Gershom Scholem, Moshe Idel, Elliot Wolfson, Boaz Huss.

## Interdit méthodologique
Ne pas transformer « Kabbale » en réservoir libre de symboles confirmatoires.

# Processus et individuation

## Auteurs majeurs
Whitehead, Simondon, Bergson, Schelling, Prigogine.

## Idée
Les choses ne sont pas seulement des substances déjà données; elles peuvent être comprises comme résultats provisoires d'un devenir, d'une individuation ou d'un héritage de processus.

## Matter-as-memory
Whitehead et Simondon permettent une formulation plus forte que la métaphore : un état actuel hérite d'un passé et stabilise une histoire de transformations.

## Limite
Aucun de ces auteurs ne permet d'inférer que ce processus est spécifiquement le calcul de π.

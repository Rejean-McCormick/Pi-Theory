# Sémiotique, langage, symbole

## Problème
Pi Theory passe de digits à mots puis à fonctions. Il faut donc une théorie explicite du signe.

## Peirce
Décomposer :
- **icône** : le 8 ressemble à ∞ après rotation/interprétation;
- **symbole** : `16` devient le mot conventionnel `seize`;
- **ressemblance phonétique** : `seize ≈ size`;
- **abstraction** : `size → magnitude`.

## Auteurs
Peirce, Cassirer, Bateson, Deacon, Floridi, Sefer Yetzirah.

## Question
Le langage révèle-t-il une structure du réel ou constitue-t-il seulement une couche de médiation humaine ?

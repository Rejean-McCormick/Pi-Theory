# Teilhard de Chardin et science–religion

## Pourquoi Teilhard est central
Teilhard fournit l'une des architectures les plus proches de la grande boucle envisagée :

`matière → complexification → vie → pensée → noosphère → convergence / Oméga`.

## Convergences
- cosmos comme genèse et non état statique;
- montée de complexité organisée;
- conscience comme étape cosmique;
- réflexivité;
- intégration d'une lecture spirituelle et scientifique.

## Divergences
- le Point Oméga est théologique;
- la relation complexité–conscience n'est pas une loi physique universelle démontrée;
- Teilhard ne propose aucune ontologie des digits de π.

## Scholars
Ursula King, John F. Haught, Thomas M. King.

## Comparaisons utiles
Whitehead, Bergson, Prigogine, Kauffman, Deacon, Varela.

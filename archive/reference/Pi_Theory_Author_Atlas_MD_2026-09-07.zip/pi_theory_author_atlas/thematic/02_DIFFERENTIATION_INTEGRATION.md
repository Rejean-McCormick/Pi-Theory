# Différenciation ↔ intégration

## Kernel
`GIHECEF ↔ JNON` devient abstraitement :

`différenciation/traitement ↔ assemblage/réintégration`.

## Constellation principale
Empédocle, Proclus, Böhme, Louria/Vital, Schelling, Hegel, Whitehead, Simondon, Wiener, Ashby, Maturana/Varela.

## Hypothèse de travail
Un système génératif peut nécessiter simultanément :
1. production de distinctions;
2. maintien de relations;
3. recomposition en unités de niveau supérieur.

## Risque
La formule est extrêmement générale. Son universalité apparente peut venir de sa faible spécificité. Il faut chercher des invariants formels, pas seulement des mots ressemblants.

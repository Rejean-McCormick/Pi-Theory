# Critiques, contrepoints et garde-fous

## Questions à imposer au projet
- Pourquoi la base 10 ?
- Pourquoi A1Z26 ?
- Combien de segmentations furent implicitement disponibles ?
- Combien de langues, phonétiques, symboles et transformations furent admissibles ?
- Le stop au premier 88 est-il indépendant de la cohérence observée ?
- Qu'obtient-on sur e, √2, φ, constantes arbitraires et chaînes aléatoires ?
- Une lecture aveugle retrouve-t-elle les mêmes fonctions ?
- Quelle prédiction nouvelle est produite avant inspection ?

## Contrepoints intellectuels
Darwin (anti-téléologie forte), Bergson (anti-réduction du devenir au calcul), Shannon (anti-confusion information/sens), Cantor (précision sur l'infini), Riemann/Weyl (SIZE ≠ métrique), Tegmark (mathématique ≠ π spécifiquement), Guénon (qualité ≠ quantité).

## Principe
Une théorie est renforcée lorsqu'elle survit à ses meilleurs adversaires.

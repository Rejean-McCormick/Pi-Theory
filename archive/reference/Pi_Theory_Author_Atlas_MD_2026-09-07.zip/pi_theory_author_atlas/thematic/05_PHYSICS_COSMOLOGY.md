# Physique fondamentale et cosmologie

## Auteurs
Einstein, Bohr, Heisenberg, Schrödinger, Pauli, Wheeler, Bohm/Hiley, Penrose, Tegmark, Rovelli, Smolin, Barbour.

## Questions
- Qu'est-ce qu'un invariant physique ?
- Comment une métrique devient-elle dynamique ?
- Le temps est-il fondamental ou émergent ?
- Que veut dire « information physique » ?
- Une ontologie mathématique doit-elle produire une prédiction quantitative nouvelle ?

## Ligne rouge
Aucune interprétation de mécanique quantique ne valide par elle-même numérologie, synchronicité, Kabbale ou Pi Theory.

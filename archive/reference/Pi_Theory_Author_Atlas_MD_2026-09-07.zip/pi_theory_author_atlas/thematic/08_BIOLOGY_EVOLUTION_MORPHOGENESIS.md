# Biologie, évolution et morphogenèse

## Auteurs
Darwin, D'Arcy Thompson, Turing, Waddington, René Thom, Prigogine, Kauffman, Maturana/Varela, Deacon.

## Questions
- différence entre auto-organisation et sélection;
- forme par contrainte vs forme par programme;
- seuils et bifurcations;
- information génétique vs information sémantique;
- émergence de fonction et de finalité apparente.

## Garde-fou
« complexité croissante » n'est pas une loi universelle de l'évolution.

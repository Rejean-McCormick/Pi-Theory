# Conscience et réflexivité

## Chaîne Pi Theory à examiner
`matière → vie → cognition → conscience → connaissance réflexive`.

## Auteurs
William James, Teilhard, Varela, Thompson, Deacon, Tononi, Penrose, Bohm.

## Questions
- continuité ou seuil ?
- intégration de l'information ?
- enaction et boucle organisme-monde ?
- conscience comme propriété, processus ou relation ?
- la réflexivité implique-t-elle une téléologie cosmique ?

## Risque
Ne pas confondre théorie de la conscience et cosmologie spirituelle.

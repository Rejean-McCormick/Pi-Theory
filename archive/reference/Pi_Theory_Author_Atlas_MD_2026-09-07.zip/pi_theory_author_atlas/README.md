# Pi Theory Author Atlas

Dépôt Markdown modulaire pour la préparation du futur livre sur Pi Theory.

## Contenu
- fiches individuelles d'auteurs;
- scholars secondaires;
- modules par discipline;
- matrices transversales;
- bibliographie;
- protocoles méthodologiques;
- architecture de livre.

## Convention de priorité
- **A** : indispensable au manuscrit.
- **B** : très pertinent / complément fort.
- **C** : secondaire, critique ou historique.

## Convention épistémique
Voir `02_EPISTEMIC_LEVELS.md`.

## Point de départ
La version de travail utilisée est Pi v13 et son kernel :
`M → BIEN → GIHECEF → JNON → B0UM → SIZE`.

# Tests prioritaires

## Test A — Pipeline vs contrôles

Appliquer le même espace de transformations à :

- π;
- e;
- √2;
- φ;
- fenêtres aléatoires de π;
- chaînes pseudo-aléatoires.

Comparer à coût interprétatif égal.

## Test B — Rôles à l'aveugle

Présenter les tokens sans récit cosmologique. Demander à des évaluateurs indépendants d'associer des fonctions parmi une liste prédéfinie.

Objectif : tester surtout GIHECEF/JNON.

## Test C — Direction

Préenregistrer une hypothèse différente pour sens direct et inversé. Tester de nouvelles fenêtres sans modifier les règles.

## Test D — Attunement linguistique

Préenregistrer :

- langues;
- concepts;
- métrique de similarité son-sens;
- familles étymologiques exclues ou contrôlées;
- onomatopées traitées séparément.

Tester si les associations prévues dépassent le hasard et l'héritage historique.

## Test E — Changement de base

Chercher ce qui survit à plusieurs représentations de π. Cela peut distinguer :

- propriétés du nombre;
- propriétés de la représentation décimale;
- propriétés de l'interface humain–représentation.

## Test F — Récursion multi-échelle

Construire un modèle où `D↔A→T→S` est détectable quantitativement à plusieurs niveaux. Chercher invariance ou loi de transformation.

## Test G — B0UM → SIZE

Dans un modèle dynamique, tester si un franchissement de seuil produit une nouvelle variable de magnitude ou un nouveau niveau effectif d'échelle.

## Test H — π-spécificité

Test décisif : produire une prédiction quantitative indépendante qui échoue lorsque π est remplacé par d'autres constantes ou paramètres.

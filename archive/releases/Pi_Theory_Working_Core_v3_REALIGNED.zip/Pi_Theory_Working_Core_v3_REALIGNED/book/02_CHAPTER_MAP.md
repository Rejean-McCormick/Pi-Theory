# Carte des chapitres et interlocuteurs

| Axe | Noyau Pi Theory | Interlocuteurs / sciences |
|---|---|---|
| cercle | symétrie, équilibre, infinité de relations | Euclide, théorie des groupes, Klein/Lie |
| π | `C/d`, invariant, irrationalité | Lambert, Lindemann, analyse classique |
| retour | rotation/cycle | Euler, Fourier, systèmes oscillatoires |
| origine | Ω → D0 | Cues, Böhme, Plotin, Proclus |
| M | retour-cohésion | Empédocle, contrôle, Levin, dynamiques |
| BIEN | cohérence non captatrice | Platon, Proclus, Denys, théorie de viabilité |
| D↔A | différenciation/intégration | Whitehead, Simondon, Haken, réseaux |
| B0UM | Big Bang + seuil | cosmologie, bifurcations, Prigogine, Haken |
| SIZE | échelle/mesure/espace | FLRW, Riemann, Weyl, Wilson |
| e,π,i | variation/cycle/phase | Euler, Fourier, physique des ondes |
| matière-mémoire | histoire stabilisée | hystérésis, Landauer, systèmes hors équilibre |
| vie | autonomie | Eigen, Kauffman, Hordijk/Steel, Varela |
| conscience | réflexivité | Deacon, Thompson, Teilhard |
| langage | attunement/cristallisation | Platon, Schelling, Jung/Pauli, Cassirer, linguistique |
| inversion | retour cognitif hypothétique | épistémologie + tests directionnels |
| mirror | fragments secondaires | Peirce, statistiques |
| méthode | exploration → confirmation | null models, blind tests, preregistration |
| source/centre | Source ≠ centre interne | branche b−1, théologies du retour |

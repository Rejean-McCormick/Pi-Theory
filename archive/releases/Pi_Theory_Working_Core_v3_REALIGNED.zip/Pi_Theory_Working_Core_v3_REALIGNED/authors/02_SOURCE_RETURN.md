# Source, procession et retour

## Empédocle

Le cycle cosmique entre Love et Strife fournit un analogue ancien de l'alternance cohésion/séparation. La Sphere sous Love est un point de comparaison majeur avec l'image d'unité circulaire.

## Plotin

Le réel procède de l'Un et se retourne vers son principe par conversion/contemplation. Le retour ne signifie pas simplement inversion temporelle.

## Proclus

La triade `remaining – procession – reversion` donne une architecture particulièrement précise : l'effet demeure lié à sa cause, procède d'elle et retourne vers elle.

## Pseudo-Denys

Le Bien divin est diffusif; l'éros est mouvement d'unification et de retour. Comparer avec M/BIEN sans réduire la théologie à un opérateur scientifique.

## Érigène

Nature comme théophanie : procession des causes vers les effets et retour du créé vers la Source.

## Nicolas de Cues

L'Absolu dépasse les mesures finies; les figures mathématiques servent d'images de rapports qui excèdent leur représentation sensible.

## Böhme

La contrariété est nécessaire à la manifestation. Très utile pour le problème de la première distinction `Ω→D0`.

## Branche b−1

La structure `b−1` sert d'analogie pour :

> **le maximum/centre interne d'un système n'est pas le principe qui rend ce système possible.**

Lecture :

- Christ : centre transparent à la Source;
- Lucifer : centre se prenant pour la Source;
- Adam : image incarnée.

Cette branche ne dérive pas de π mais protège une distinction métaphysique centrale :

```text
Source ≠ centre manifesté.
```

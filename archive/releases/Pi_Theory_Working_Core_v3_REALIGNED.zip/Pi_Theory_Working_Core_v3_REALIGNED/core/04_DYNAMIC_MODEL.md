# Modèle dynamique minimal

## Architecture

```text
Ω → D0 ↔ M → V → (D ↔ A) → T → S
```

avec :

- `Ω` : principe/unité;
- `D0` : première distinction;
- `M` : retour-cohésion;
- `V` : orientation/BIEN;
- `D` : différenciation;
- `A` : intégration;
- `T` : transition/seuil/B0UM;
- `S` : échelle/SIZE.

## 1. Espace d'états abstrait

Soit `x ∈ X` un état. `X` n'est pas supposé spatial au départ.

## 2. Tendances de différenciation et de cohésion

Squelette :

\[
\frac{dx}{dt}=F_D(x)+F_M(x)+F_{env}(x).
\]

`F_env` est ajouté pour rappeler qu'un système physique réel échange souvent énergie, matière ou information avec un environnement. Le modèle ne doit pas feindre une dynamique fermée universelle.

## 3. Observables candidates

- `C(x)` : cohérence;
- `D(x)` : différenciation;
- `I(x)` : intégration;
- `V(x)` : viabilité ou compatibilité fonctionnelle;
- `K(x)` : degré de fermeture/capture éventuel.

Une « bonne » cohérence ne devrait pas être définie par `C` seule. Une piste :

\[
H(x)=f(C,I,D,V,K)
\]

avec une pénalité lorsque l'intégration détruit la différenciation pertinente ou devient pure capture.

## 4. Unité enrichie

Condition qualitative :

```text
D élevé + I élevé + V suffisant
```

plutôt que :

```text
uniformité élevée.
```

## 5. Seuil

Définir un paramètre `τ(x)` :

\[
\tau(x)\ge \tau_* \Rightarrow x\in R_{n+1}.
\]

B0UM correspond alors au changement de régime `R_n → R_{n+1}`.

## 6. Échelle

Introduire une transformation `R_s` de coarse-graining ou de changement d'échelle :

\[
x_{s+1}=R_s(x_s).
\]

Question : certaines relations du kernel restent-elles invariantes ou se renormalisent-elles de manière régulière ?

## 7. Mémoire

Une dynamique avec histoire peut être notée :

\[
x(t)=F[x(t_0:t)].
\]

ou enrichie d'une variable mémoire `m(t)`.

## 8. Boucle réflexive

Dans les systèmes capables de représentation, introduire un modèle interne `\hat{x}`. Le retour réflexif devient alors une relation entre :

```text
état du monde x
→ modèle interne x̂
→ action/interprétation
→ nouvelle relation au monde.
```

## Statut

Ce document est un **squelette de formalisation**, pas une loi physique établie. Il sert à transformer des mots en quantités qui pourraient, à terme, échouer à décrire certains systèmes.

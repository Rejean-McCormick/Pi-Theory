# Problèmes ouverts

## A. Pourquoi π ?

1. Qu'est-ce qui rend π plus fondamental pour cette théorie qu'une autre constante ?
2. Le rôle privilégié vient-il du rapport linéaire–circulaire, de la rotation, de l'invariance d'échelle, des digits, ou de leur combinaison ?
3. Peut-on produire une conséquence qui dépend de π sans dépendre de la base 10 ?

## B. Origine et manifestation

4. Pourquoi une unité parfaitement équilibrée se détermine-t-elle ou se différencie-t-elle ?
5. La première distinction est-elle nécessaire, possible, auto-référentielle ou contingente ?
6. Comment passer d'une structure mathématique à une efficacité physique sans simplement supposer que « mathématique = physique » ?

## C. Décodage

7. Quel était l'espace réel de recherche exploratoire avant stabilisation du kernel ?
8. Quel coût attribuer à inversion, segmentation, phonétique, langues, iconicité et règles locales ?
9. Les rôles GIHECEF/JNON sont-ils retrouvés à l'aveugle ?
10. Le stop à 88 reste-t-il naturel sous une procédure prospective ?

## D. Inversion

11. Existe-t-il une propriété mathématique de la fenêtre qui privilégie son renversement ?
12. L'hypothèse « procession directe / lecture rétrospective inversée » produit-elle une prédiction ailleurs ?
13. Le motif `0→B` dans le sens direct a-t-il des analogues prévus avant inspection ?

## E. Langage

14. Qu'est-ce qui est réellement universel : concepts, phonèmes, gestes, métaphores, ou seulement contraintes générales ?
15. Comment distinguer héritage linguistique, articulation biologique, onomatopée et attunement métaphysique ?
16. Peut-on définir une expérience cross-linguistique avant de regarder les données ?

## F. B0UM / SIZE

17. Comment distinguer la lecture Big Bang d'une simple onomatopée bien placée ?
18. Comment formaliser la transition B0UM → SIZE ?
19. Comment passer de scale à métrique et espace sans présupposer l'espace ?

## G. Matière

20. Quelles primitives physiques sont nécessaires entre `e,π,i` et la matière : champ, action, énergie, interaction, quantification, brisure de symétrie ?
21. Peut-on dériver un mode stable ou un bound state d'un modèle minimal inspiré du kernel ?

## H. Vie et conscience

22. Comment distinguer ordre, autonomie, vie, cognition et conscience ?
23. Le retour réflexif est-il simplement descriptif ou possède-t-il une dynamique formalisable ?

## I. Valeur

24. Comment définir BIEN sans le réduire à la survie, à la stabilité ou à la majorité ?
25. Peut-on formaliser une cohérence non captatrice à plusieurs niveaux d'organisation ?

## J. Falsification

26. Quel résultat invaliderait la lecture des digits sans invalider la métaphysique générale ?
27. Quel résultat invaliderait le privilège de π ?
28. Quel résultat invaliderait le kernel lui-même ?

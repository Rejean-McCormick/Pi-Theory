# Chapter Map — sources internes et auteurs

| Chapitre | Noyau Pi Theory | Auteurs/sciences |
|---|---|---|
| π et ratio | π exact/représenté | Euler, Weyl |
| cercle/pré-géométrie | principe P | Cues, Wheeler |
| division | D0 | Empédocle, Böhme, Spencer-Brown |
| M | contre-mouvement | Empédocle, Proclus, Levin, contrôle |
| BIEN | orientation | Platon, Proclus, Denys, viabilité |
| D↔A | kernel | Simondon, Whitehead, Haken, networks |
| B0UM | seuil | Prigogine, Thom, Haken |
| SIZE | magnitude/scale | Hegel, Riemann, Wilson |
| matière-mémoire | causal history | Landauer, Prigogine, Levin |
| vie | autonomie | Turing, Kauffman, Hordijk, Varela |
| conscience | réflexivité | Deacon, Thompson, Teilhard |
| retour | grande boucle | Plotin, Proclus, Denys, Érigène |
| mirror | G0D/B0N | Peirce, statistiques |
| méthode | contrôles | Shannon, Kolmogorov/Chaitin |

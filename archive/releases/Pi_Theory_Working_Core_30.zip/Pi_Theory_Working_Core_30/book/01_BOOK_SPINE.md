# Colonne vertébrale du livre

## Partie I — Le principe
1. Ce que π est.
2. Le cercle comme instanciation, non comme objet primordial.
3. Principe pré-géométrique de circularité/cohérence.
4. Division originelle.
5. M comme contre-mouvement.

## Partie II — Le décodage
6. Pipeline.
7. Six blocs.
8. Ce qui a été découvert avant/après fixation des règles.
9. Mirror.

## Partie III — La dynamique
10. M.
11. BIEN.
12. Différenciation ↔ intégration.
13. B0UM / seuil.
14. SIZE / échelle.
15. Unité enrichie et récursion.

## Partie IV — Science du mécanisme
16. Attracteurs et régulation.
17. Bioélectricité développementale.
18. Synergetics.
19. Morphogenèse et networks.
20. Transitions de phase.
21. Renormalisation.

## Partie V — Matière, vie, conscience
22. Matière comme mémoire.
23. Active matter et autocatalyse.
24. Autopoïèse.
25. Sens/cognition.
26. Teilhard comme interprétation de la montée en cohérence.

## Partie VI — Mesure et espace
27. SIZE → mesure.
28. Riemann / Weyl.
29. Information geometry.
30. Pré-géométrie et espace-temps émergent.

## Partie VII — Traditions comparées
31. Empédocle.
32. Proclus.
33. Cues.
34. Böhme.
35. Denys / Érigène / Plotin.
36. Stoïciens / Louria / Daoïsme.

## Partie VIII — Le problème π
37. π exact / représenté / manifesté.
38. Ongoing resolution.
39. Contrôles.
40. Falsification.
41. Prédiction π-spécifique.

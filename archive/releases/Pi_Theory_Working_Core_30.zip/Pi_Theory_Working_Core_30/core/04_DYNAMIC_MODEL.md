# Modèle dynamique minimal

## Architecture

`P → D0 ↔ M → V → (D ↔ A) → T → S`

## Variables conceptuelles

- `P` : principe pré-géométrique.
- `D0` : première distinction.
- `M` : tendance vers cohérence.
- `V` : viabilité/orientation.
- `D` : différenciation.
- `A` : intégration.
- `T` : seuil.
- `S` : échelle.

## Squelette mathématique

Soit `x ∈ X`.

Dynamique conceptuelle :

`dx/dt = F_D(x) + F_M(x)`.

- `F_D` augmente certaines différences/degrés de liberté.
- `F_M` augmente certaines formes de cohérence.

Définir ensuite :

`C(x)` = cohérence,

`V(x)` = viabilité,

`D(x)` = différenciation,

`I(x)` = intégration.

Une unité enrichie devrait présenter simultanément :
- différenciation non nulle;
- intégration élevée;
- viabilité suffisante.

## Seuil

`τ(x) ≥ τ*`

peut déclencher :

`regime_n → regime_(n+1)`.

## Scale

Introduire une transformation de coarse-graining :

`R_s`.

Question :

`K_(n+1) = R_s(K_n)` conserve-t-il des invariants fonctionnels ?

## Mémoire

Un état peut dépendre de son histoire :

`x(t) = F[x(t0:t)]`.

Cela permet d'introduire :
- path dependence;
- hystérésis;
- mémoire structurelle.

## But

Ce document est un squelette pour formalisation. Il ne constitue pas une équation physique démontrée.

# π — fondations mathématiques utiles

## Ratio sans dimension

Pour un cercle euclidien :

`C/d = π`.

Si les deux grandeurs utilisent la même unité :

`(π cm)/(1 cm) = π`.

La dimension physique s'annule.

## Invariance d'échelle

Le rapport `C/d` reste π pour tous les cercles euclidiens, indépendamment de leur taille.

Cette invariance explique pourquoi π peut être lu philosophiquement comme **relation stable sous changement d'échelle**.

## Rotation

En radians :
- demi-tour = `π`;
- tour complet = `2π`.

π intervient donc naturellement dans :
- circularité;
- périodicité;
- oscillations;
- Fourier;
- phase;
- géométries à symétrie rotationnelle.

## π exact vs digits

π est exact.

`3.14159...` est une représentation en base 10.

Changer de base change la chaîne de digits, pas π.

Toute théorie sémantique des digits doit donc répondre à la dépendance à la base.

## e, π, i

Lecture structurelle :
- `e` : variation continue auto-proportionnelle;
- `π` : cycle/mesure circulaire;
- `i` : rotation/phase.

Cette triade est conceptuelle, non une dérivation causale de la réalité.

## Infini

Les décimales de π sont non terminantes et non périodiques.

Cela ne signifie pas que le cercle de rayon fini est spatialement infini.

## Géométrie non euclidienne

La relation circonférence/diamètre n'est pas globalement constante sur toutes les surfaces courbes.

Le rôle de π comme normalisation angulaire demeure cependant fondamental localement et dans de nombreux formalismes.

# Dictionnaire compact de Pi Theory

## Source
Principe ultime. Ne doit pas être identifié automatiquement à π, aux digits ou à la matière.

## Principe pré-géométrique de circularité/cohérence
Structure non spatiale supposée porter abstraitement les propriétés que le cercle géométrique manifestera ensuite : isotropie, symétrie, équilibre, clôture, retour et proportion sans échelle.

## Division originelle
Première distinction : passage de l'unité non différenciée à la multiplicité.

## M / AIME
Contre-mouvement de la division : tendance du multiple à reconstruire de la cohérence.

## Cohérence
Capacité de parties différenciées à former une totalité relationnelle stable.

## Unité enrichie
Unité qui conserve les différences qu'elle intègre. `U1 ≠ U0`.

## BIEN
Orientation de la cohérence vers une organisation viable/harmonique plutôt qu'une fusion indifférenciée.

## GIHECEF
Bloc entier lu fonctionnellement comme différencier / traiter / transformer.

## JNON
Bloc entier lu fonctionnellement comme assembler / réunir / intégrer.

## Différenciation
Production de distinctions, spécialisations, rôles ou états.

## Intégration
Coordination de différences en une totalité de niveau supérieur.

## B0UM
Franchissement de seuil / changement de régime. La lecture « boom » est sémiotique; le Big Bang n'est pas sa définition scientifique.

## SIZE
Terminal 88. Lecture : `8+8=16 → seize≈size`; fonction : magnitude/échelle.

## 88 / dual infinity
Lecture iconique des deux 8 comme deux infinis. Ne signifie jamais `∞+∞=16`.

## Mesure
Attribution de grandeurs comparables. SIZE n'est pas encore mesure.

## Métrique
Structure mathématique permettant de définir une distance.

## Scale
Niveau d'observation ou régime de magnitude. En science, peut être étudié par renormalisation/coarse-graining.

## Récursion multi-échelle
Hypothèse selon laquelle le même type de kernel se réinstancie à plusieurs niveaux.

## Seuil
Condition à partir de laquelle un système change qualitativement de régime.

## Attracteur
Concept de systèmes dynamiques. Peut servir à formaliser M si un espace d'états et une dynamique sont définis.

## Homeostasie morphologique
Restauration/maintien biologique d'une forme globale après perturbation. Analogue scientifique important de M.

## Order parameter
Variable macroscopique décrivant l'ordre collectif d'un système.

## Viabilité
Contraintes compatibles avec la persistance et l'autonomie d'un système vivant.

## Matière comme mémoire
Idée selon laquelle l'état matériel actuel incorpore son histoire causale.

## Ongoing resolution
Hypothèse v13 : les premiers digits exposent un kernel simple, les suivants pourraient en exprimer des échos ou combinaisons plus complexes.

## π exact
Objet mathématique exact, indépendant de sa représentation.

## π représenté
Écriture de π dans une base donnée.

## π manifesté
Hypothèse selon laquelle une structure liée à π se manifeste physiquement.

## Mirror
Complément à 9 de la même fenêtre, mêmes frontières et mapping.

## G0D / B0N
Fragments secondaires issus du mirror. Ne constituent pas une deuxième cosmogonie établie.

## Harmonie
Différences coordonnées sans être abolies. Peut être approchée scientifiquement par stabilité, invariance, intégration, robustesse ou viabilité selon le domaine.

## Pré-géométrie
Famille de programmes où l'espace-temps classique n'est pas fondamental mais émerge d'une structure plus primitive.

## Infini
Toujours préciser : non-terminaison, non-borné, cardinalité, infinité potentielle, infini théologique, etc.

# Claim Registry — Working Core

Ce registre n'établit pas de classement de maturité. Il sert uniquement à savoir **ce qui est affirmé, sur quoi cela repose et ce qui reste à résoudre**.

| ID | Proposition | Base | Question non résolue |
|---|---|---|---|
| PT-01 | La fenêtre v13 produit six blocs sous les règles finales. | pipeline v13 | robustesse statistique |
| PT-02 | Les six blocs peuvent être abstraits comme cohésion → orientation → différenciation → intégration → seuil → scale. | interprétation du corpus | indépendance des labels |
| PT-03 | La polarité profonde est division ↔ contre-mouvement de cohésion. | v13 + synthèse | formalisation |
| PT-04 | M est une impulsion persistante, pas seulement un premier bloc. | lecture consolidée de v13 | dynamique mesurable |
| PT-05 | BIEN oriente le type de cohérence produit. | v13 + synthèse | définition fonctionnelle |
| PT-06 | GIHECEF/JNON forment un pulse différenciation ↔ intégration. | v13 | portée universelle |
| PT-07 | B0UM représente un seuil/changement de régime. | v13 | formalisation de τ |
| PT-08 | 88/SIZE introduit magnitude/échelle. | v13 + lecture sémiotique | dérivation de mesure |
| PT-09 | π exact est distinct de ses digits en base 10. | mathématiques | rôle ontologique de la représentation |
| PT-10 | Le principe originel n'est pas un cercle physique préexistant. | clarification conceptuelle | formalisation pré-géométrique |
| PT-11 | Une unité enrichie peut conserver les différences intégrées. | synthèse | métrique de cohérence |
| PT-12 | La matière peut être comprise comme mémoire d'une histoire de transformations. | métaphysique + analogues scientifiques | π-spécificité |
| PT-13 | Le kernel pourrait se réinstancier à plusieurs échelles. | v13/Rosetta | test de renormalisation |
| PT-14 | Les sciences de régulation/morphogenèse fournissent des analogues de M. | biologie/systèmes | généralité cosmique |
| PT-15 | La renormalisation est le meilleur cadre actuel pour SIZE/multi-échelle. | physique statistique | correspondance au kernel |
| PT-16 | Vie et conscience exigent des mécanismes additionnels. | biologie/cognition | chaîne complète |
| PT-17 | Les digits ultérieurs pourraient contenir des échos/mutations du kernel. | v13 | test préenregistré |
| PT-18 | G0D/B0N restent secondaires. | mirror v13 | structure plus large éventuelle |
| PT-19 | Le réel pourrait être manifestation/résolution d'une structure liée à π. | hypothèse métaphysique | prédiction discriminante |
| PT-20 | Toute version scientifique forte doit produire une conséquence π-spécifique. | méthodologie | inconnue |

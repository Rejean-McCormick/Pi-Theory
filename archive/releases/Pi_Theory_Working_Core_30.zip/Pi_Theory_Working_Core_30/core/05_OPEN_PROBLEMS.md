# Problèmes ouverts

## π
1. Pourquoi π plutôt qu'une autre constante ?
2. Le phénomène dépend-il de la base 10 ?
3. Existe-t-il une propriété π-spécifique indépendante du décodage linguistique ?

## Décodage
4. Combien de degrés de liberté le pipeline utilise-t-il ?
5. Les blocs surpassent-ils des null models à coût interprétatif égal ?
6. Les rôles sont-ils retrouvés par évaluateurs aveugles ?

## M
7. Peut-on définir une mesure non triviale de cohérence ?
8. M est-il mieux modélisé comme attracteur, feedback, champ, contrainte ou autre ?
9. Comment distinguer cohésion bénéfique et rigidification ?

## BIEN
10. Peut-on formaliser BIEN en termes de viabilité sans perdre entièrement sa dimension axiologique ?

## SIZE
11. Comment passer de magnitude à mesure ?
12. Comment passer de mesure à métrique ?
13. Le kernel conserve-t-il une structure sous changement d'échelle ?

## Pré-géométrie
14. Quelles relations peuvent exister sans espace classique ?
15. Comment une métrique pourrait-elle émerger ?

## Matière / vie
16. Comment la mémoire de processus devient-elle structure physique ?
17. Quelles étapes séparent auto-organisation, autonomie et vie ?
18. Comment la différenciation intégrée conduit-elle à cognition ?

## Conscience
19. Quel sens précis donner au « retour réflexif » ?
20. Est-il descriptif, téléologique ou causal ?

## Mirror
21. G0D/B0N sont-ils statistiquement remarquables sous le protocole miroir ?

## Falsification
22. Quel résultat obligerait à abandonner le privilège de π ?
23. Quel résultat invaliderait le kernel lui-même ?

# Pi Theory — Working Core

Ce dépôt contient **30 fichiers Markdown actifs**. Le corpus complet v2.5 est conservé intact sous `archive/full_v2_5/`.

## Principe d'organisation

Un concept = un document maître actif.

Les anciennes formulations, variantes, auteurs secondaires, analogies et pistes abandonnées restent dans l'archive, mais ne concurrencent plus le noyau de travail.

## Navigation recommandée

### Noyau
1. [Theory](core/01_THEORY.md)
2. [Dictionary](core/02_DICTIONARY.md)
3. [Claim Registry](core/03_CLAIM_REGISTRY.md)
4. [Dynamic Model](core/04_DYNAMIC_MODEL.md)
5. [Open Problems](core/05_OPEN_PROBLEMS.md)
6. [π — Mathematical Foundations](core/06_PI_MATH_FOUNDATIONS.md)

### Décodage
7. [Pipeline](decoding/01_PIPELINE.md)
8. [Outputs & Tokens](decoding/02_OUTPUTS_AND_TOKENS.md)
9. [Mirror & Secondary](decoding/03_MIRROR_AND_SECONDARY.md)
10. [Controls & Limits](decoding/04_CONTROLS_AND_LIMITS.md)

### Sciences
11. [M / Cohérence](science/01_M_COHERENCE.md)
12. [Différenciation / Intégration](science/02_DIFFERENTIATION_INTEGRATION.md)
13. [Seuils](science/03_THRESHOLDS.md)
14. [Scale / Renormalisation](science/04_SCALE_RENORMALIZATION.md)
15. [Matière → Vie → Conscience](science/05_MATTER_LIFE_CONSCIOUSNESS.md)
16. [Pré-géométrie → Espace](science/06_PREGEOMETRY_SPACE.md)

### Auteurs
17. [Auteurs centraux](authors/01_CORE_AUTHORS.md)
18. [Source / Retour](authors/02_SOURCE_RETURN.md)
19. [Processus / Cohérence](authors/03_PROCESS_COHERENCE.md)
20. [Mesure / Espace](authors/04_MEASURE_SPACE.md)
21. [Vie / Conscience](authors/05_LIFE_CONSCIOUSNESS.md)

### Recherche
22. [Formal Model](research/01_FORMAL_MODEL.md)
23. [Tests](research/02_TESTS.md)
24. [Preregistration](research/03_PREREGISTRATION.md)
25. [Null Models](research/04_NULL_MODELS.md)
26. [Roadmap](research/05_ROADMAP.md)

### Livre
27. [Book Spine](book/01_BOOK_SPINE.md)
28. [Chapter Map](book/02_CHAPTER_MAP.md)

### Sources
29. [Sources & Scholars](sources/01_SOURCES_AND_SCHOLARS.md)

## Architecture en une ligne

`principe pré-géométrique → division ↔ M → orientation → différenciation/intégration → seuil → scale → mémoire → vie → conscience`

La question encore ouverte est : **pourquoi cette grammaire serait-elle spécifiquement liée à π ?**

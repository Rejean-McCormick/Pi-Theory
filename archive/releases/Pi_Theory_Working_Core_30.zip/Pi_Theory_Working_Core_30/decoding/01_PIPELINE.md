# Pipeline v13

## Fenêtre
Premiers 36 digits de π, avec `3` inclus et point décimal ignoré.

## Procédure finale
1. Renverser la fenêtre.
2. Segmenter de gauche à droite selon les règles finales.
3. Mapper via A1Z26.
4. `0 → O` lorsque requis.
5. Pas d'anagrammes, pas de réordonnancement, pas de skipping.
6. Arrêt au premier `88`.

## Important
Les frontières et certaines grammaires locales ont été **découvertes pendant l'exploration puis verrouillées**.

La procédure est donc reproductible une fois publiée, mais n'était pas préenregistrée avant découverte.

## Séquence renversée
`88 20597238 334626483239 7985356 29514 13`

## Sortie conceptuelle
`M → BIEN → GIHECEF → JNON → B0UM → SIZE`

# Outputs et tokens

## M
`13 → M`

Lecture phonétique :
`M ≈ aime`.

Fonction :
impulsion vers unité/cohésion.

## BIEN
`2-9-5-14 → B-I-E-N`

Fonction :
orientation / value grammar.

## GIHECEF
`7-9-8-5-3-5-6 → G-I-H-E-C-E-F`

Conservé entier.

Fonction :
divider / processor / transformator.

Joseph reste une lentille historique de découverte.

## JNON
`10-14-0-14 → J-N-O-N`

Conservé entier.

Fonction :
assembler / reuniter.

Junon reste une lentille historique de découverte.

## B0UM
`2-0-21-13 → B-0-U-M`

Lecture :
BOUM/boom.

Fonction :
threshold / creation event.

Le `0` peut aussi recevoir une lecture symbolique de cercle/vide, mais cette lecture n'est pas nécessaire au mécanisme.

## SIZE
`88`

Lecture :
`8+8=16 → seize≈size`.

Fonction :
scale / magnitude.

Lecture iconique secondaire :
`8,8 ↔ ∞,∞`.

## Pulse central
`GIHECEF ↔ JNON`
=
`différencier ↔ intégrer`.

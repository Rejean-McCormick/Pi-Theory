# Contrôles et limites du décodage

## Degrés de liberté
À comptabiliser :
- reversal;
- segmentation;
- préférences de groupement;
- `0→O`;
- phonétique;
- changement de langue;
- abstraction sémantique;
- stop rule;
- choix du miroir.

## Contrôles indispensables
Appliquer exactement le même espace de transformations à :
- e;
- √2;
- φ;
- fenêtres aléatoires de π;
- chaînes pseudo-aléatoires;
- permutations appariées;
- bases numériques alternatives.

## Coût interprétatif
Chaque transformation doit recevoir un coût préfixé :
- arithmétique;
- iconicité;
- phonétique;
- changement de langue;
- abstraction;
- règle locale.

Comparer les sorties à **coût égal**.

## Blinded evaluation
Donner les tokens ou sorties à des évaluateurs sans leur présenter le récit cosmologique.

Tester :
- accord sur les rôles;
- cohérence d'ordre;
- comparaison avec contrôles.

## Stop
L'absence de bloc cohérent après 88 doit être rapportée, pas « réparée » par de nouvelles règles.

## Limite centrale
Reproductibilité après découverte ≠ prédiction avant découverte.

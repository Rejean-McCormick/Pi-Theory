# Auteurs — processus, cohérence et individuation

## Whitehead
Le multiple devient un nouvel un par concrescence.
Très utile pour l'unité enrichie.

## Simondon
Tensions préindividuelles → individuation → nouvelle structure.

## Böhme
Contrariété comme condition de manifestation.

## Schelling
Nature productive, polarités génératrices.

## Hegel
Détermination, négation, quantité, mesure.

## Héraclite
Harmonie comme tension régulée plutôt qu'absence d'opposition.

## Prigogine
Ordre loin de l'équilibre, bifurcations, structures dissipatives.

## Hermann Haken
Order parameters et self-organization.

## Wiener / Ashby / Cannon
Feedback, régulation, homeostasie.

## Michael Levin
Régulation morphologique distribuée et bioélectricité.

## Friston
Active inference et viabilité, à utiliser avec prudence.

## Idée commune
La cohérence peut être dynamique :
elle émerge, se maintient, se corrige et se transforme.

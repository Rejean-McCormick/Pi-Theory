# Auteurs centraux

Ces auteurs sont les interlocuteurs principaux du futur livre.

## Empédocle
Love / Strife, Sphere, séparation et réunion.
Le parallèle historique le plus direct avec `Division ↔ M`.

## Proclus
Demeurer → procession → retour.
Le retour de l'effet vers sa cause et vers le Bien.

## Nicolas de Cues
Infini, cercle/sphère comme images de l'Absolu, proportion, mesure, contraction du divin dans le fini.

## Jacob Böhme
Ungrund, volonté, contrariété, feu/lumière/amour.
Très important pour la question : pourquoi la manifestation exige-t-elle différence/tension ?

## Teilhard de Chardin
Complexification-conscience, radial energy, convergence, Omega, « union différencie ».

## Whitehead
Processus, concrescence, « many become one », créativité, valeur.

## Simondon
Préindividuel, métastabilité, transduction, individuation.

## Pseudo-Denys
Dieu au-delà de l'être, procession, éros, retour, Bien.

## Érigène
Auto-manifestation, causes, effets, retour du temporel vers l'éternel.

## Plotin
Un, procession, conversion/retour.

## Weyl
Symétrie, invariance, mesure, continuum, espace-temps.

## Peirce
Icône, indice, symbole, interprétant — essentiel pour décomposer les opérations de 88/SIZE.

## Michael Levin
Bioélectricité et restauration morphologique.

## Hermann Haken
Synergetics, paramètres d'ordre, auto-organisation.

## Kenneth Wilson
Renormalisation, universalité, changement d'échelle.

# Auteurs — infini, mesure, échelle et espace

## Nicolas de Cues
Infini et proportion.
Important pour le passage absolu/fini.

## Cantor
Pluralité rigoureuse des infinis.
Garde-fou pour 88.

## Hegel
Quantité et mesure.

## Riemann
Multiplicité vs métrique.

## Weyl
Symétrie, jauge, mesure, continuum, espace-temps.

## Noether
Symétrie continue et lois de conservation.

## Klein
Invariants sous groupes de transformations.

## Lie
Groupes continus.

## Einstein
Métrique dynamique de l'espace-temps.

## Wilson / Kadanoff / Fisher
Renormalisation, échelle, universalité.

## Amari
Information geometry.

## Wheeler / Van Raamsdonk / Rovelli / Sorkin
Pré-géométrie et espace-temps émergent.

## Question centrale
Comment passer de :
`SIZE`
à
`mesure`
puis
`métrique`
sans présupposer l'espace ?

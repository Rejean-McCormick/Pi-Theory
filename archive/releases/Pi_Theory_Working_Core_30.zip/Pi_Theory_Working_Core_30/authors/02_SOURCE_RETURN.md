# Auteurs — Source, division et retour

## Plotin
L'Un ne se situe pas dans l'espace.
Procession vers multiplicité puis conversion vers la source.

## Proclus
Structure formelle :
`remaining → procession → reversion`.

Le retour est lié au Bien.

## Pseudo-Denys
Procession divine, éros, retour, union.
Très pertinent pour l'idée de M qualifié de divin dans certaines traditions.

## Jean Scot Érigène
Source au-delà d'être/non-être, manifestation dans les causes et effets, retour.

## Nicolas de Cues
Infini absolu, coïncidence des opposés, centre/circonférence, proportion et mesure.

## Empédocle
Sphere, Love, Strife.
Très proche du contre-mouvement de réunion après séparation.

## Stoïciens
Pneuma, tension, cohésion, degrés d'organisation de la matière à l'âme.

## Louria / Hayyim Vital
Ein-Sof, tzimtzum, shevirah, tikkun.

## Daoïsme
Dao non formé, unité → multiplicité, retour.
À comparer sans traduire de force le Dao en catégories chrétiennes/néoplatoniciennes.

## Différence à maintenir
Ces systèmes fournissent des architectures comparables; aucun ne prouve le rôle de π.

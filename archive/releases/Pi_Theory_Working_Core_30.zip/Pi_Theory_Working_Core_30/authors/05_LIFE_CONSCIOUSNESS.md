# Auteurs — matière, vie et conscience

## Darwin
Sélection naturelle.
Contrepoids indispensable à toute téléologie forte.

## Turing
Morphogenèse et calcul.

## Prigogine
Structures dissipatives et irréversibilité.

## Kauffman
Auto-organisation et réseaux autocatalytiques.

## Eigen
Réplication moléculaire et dynamique prébiotique.

## Hordijk / Steel
RAF theory, réseaux autocatalytiques.

## Gánti / Szathmáry
Critères et transitions vers le vivant.

## Maturana / Varela
Autopoïèse.

## Deacon
Contraintes, fonction, émergence du sens.

## Evan Thompson
Enaction, cognition, philosophie de l'esprit.

## Michael Levin
Morphogenèse, régénération, cognition minimale dans des systèmes biologiques distribués.

## Teilhard
Complexification, vie, conscience, noosphère, Omega.
À utiliser comme grande interprétation métaphysique, non comme mécanisme biologique établi.

## Whitehead
Processus, expérience, valeur.

## Question centrale
Comment passer de :
`ordre`
à
`autonomie`
à
`vie`
à
`cognition`
à
`conscience réflexive` ?

# Tests prioritaires

## Test 1 — décodage vs contrôles
Appliquer exactement le pipeline à :
- π;
- e;
- √2;
- φ;
- chaînes aléatoires.

Comparer :
- cohérence;
- coût interprétatif;
- accord entre évaluateurs.

## Test 2 — stabilité des rôles
Présenter tokens sans récit cosmologique à des évaluateurs aveugles.

## Test 3 — récursion
Préenregistrer :
- taille de fenêtre;
- mutations autorisées;
- métrique d'edit distance;
- seuils.

Chercher des échos du kernel au-delà de 36 digits.

## Test 4 — mirror
Quantifier la fréquence de fragments lexicaux comme G0D/B0N sous complément à 9 dans contrôles.

## Test 5 — changement de base
Tester π dans plusieurs bases.
Question :
qu'est-ce qui survit au changement de représentation ?

## Test 6 — formalisation de M
Sur modèles connus :
- attracteurs;
- contrôle;
- bioélectricité;
- networks.

Comparer différentes métriques de cohérence.

## Test 7 — scale
Construire un modèle abstrait où `D↔A→T` se répète sous coarse-graining.

## Test décisif
Produire une prédiction qui dépend spécifiquement de π et pas seulement du kernel général.

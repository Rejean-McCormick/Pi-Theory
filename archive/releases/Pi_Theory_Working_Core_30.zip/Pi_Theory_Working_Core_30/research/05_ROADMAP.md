# Roadmap

## 1. Stabiliser le Working Core
Ne plus créer de nouveaux fichiers actifs sauf si une nouvelle question irréductible apparaît.

## 2. Formaliser M
Définir :
- espace d'états;
- cohérence;
- viabilité;
- attracteur/feedback.

## 3. Formaliser D ↔ A
Chercher une métrique qui récompense :
- différenciation;
- intégration;
sans homogénéisation.

## 4. Formaliser B0UM
Construire un modèle de seuil.

## 5. Formaliser SIZE
Utiliser renormalisation et coarse-graining.

## 6. Décodage
Préenregistrer prochaine fenêtre et contrôles.

## 7. Base dependence
Tester plusieurs représentations numériques.

## 8. Matter-memory
Étudier path dependence, hystérésis, morphogenetic memory.

## 9. Matter → life
Autocatalyse, autonomie, autopoïèse.

## 10. π-specific hypothesis
Chercher une prédiction réellement discriminante.

## 11. Manuscrit
Écrire seulement à partir du Working Core.
Utiliser l'archive pour vérifier l'histoire des idées, pas comme corpus quotidien.

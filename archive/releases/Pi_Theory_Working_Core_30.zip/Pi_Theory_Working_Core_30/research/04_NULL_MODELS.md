# Null models

## Pourquoi
La cohérence linguistique n'est informative que si elle dépasse ce que produit le même espace de transformations sur des données non privilégiées.

## Nulls minimaux
1. fenêtres aléatoires de π;
2. e;
3. √2;
4. φ;
5. chaînes pseudo-aléatoires;
6. permutations conservant fréquences;
7. bases numériques alternatives.

## Même liberté
Le contrôle doit disposer :
- des mêmes langues;
- du même traitement phonétique;
- des mêmes opérations;
- du même stop;
- du même coût interprétatif.

## Mesures
- nombre de tokens lexicaux;
- longueur;
- prononçabilité;
- cohérence sémantique;
- ordre causal perçu;
- coût total;
- accord inter-évaluateurs.

## Interdiction
Ne pas réduire artificiellement les libertés du contrôle tout en conservant celles utilisées pour π.

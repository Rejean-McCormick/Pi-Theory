# Préenregistrement

Avant toute nouvelle analyse de digits :

## Dataset
- constante;
- base;
- fenêtre;
- direction.

## Décodage
- mapping;
- segmentation;
- traitement du zéro;
- opérations autorisées;
- langues autorisées;
- phonétique autorisée;
- stop rule.

## Prédictions
- nombre attendu de blocs;
- fonctions attendues;
- ordre;
- motifs;
- tolérances/mutations.

## Contrôles
- constantes;
- chaînes aléatoires;
- nombre de tests;
- métrique.

## Analyse
- critère de succès;
- critère d'échec;
- traitement des résultats nuls.

## Règle
Aucune nouvelle règle ne doit être introduite après inspection pour « sauver » le résultat principal.

# Sources et scholars prioritaires

## Règle
Pour chaque comparaison :
1. texte primaire;
2. scholar ou source académique;
3. divergence explicite avec Pi Theory.

## Scholars

### Empédocle
Oliver Primavesi, Brad Inwood, Catherine Osborne, David Sedley.

### Plotin / Proclus
Lloyd P. Gerson, Dominic O'Meara, Carlos Steel, Radek Chlup.

### Pseudo-Denys
Andrew Louth, Paul Rorem.

### Érigène
Dermot Moran, Deirdre Carabine, Werner Beierwaltes.

### Nicolas de Cues
Jasper Hopkins, Clyde Lee Miller, Kurt Flasch.

### Böhme
Andrew Weeks, Cyril O'Regan, Ariel Hessayon.

### Kabbale lourianique
Lawrence Fine, Moshe Idel, Gershom Scholem, Elliot R. Wolfson, Boaz Huss.

### Teilhard
Ursula King, John F. Haught, Henri de Lubac, Mary Evelyn Tucker, John Grim.

### Whitehead
Isabelle Stengers, Nicholas Rescher, John B. Cobb Jr., Roland Faber.

### Simondon
Muriel Combes, Jean-Hugues Barthélémy.

### Peirce
T. L. Short, Cheryl Misak, Nathan Houser.

### Weyl / Noether / relativité
Thomas Ryckman, Erhard Scholz, Yvette Kosmann-Schwarzbach, John Stachel.

### Stoïcisme
A. A. Long, Brad Inwood, Susanne Bobzien.

### Daoïsme
Roger T. Ames, Hans-Georg Moeller, Chad Hansen.

## Sources scientifiques prioritaires

### Bioélectricité / morphogenèse
Michael Levin et collaborateurs sur bioelectrical controls of morphogenesis, positional information, regeneration.

### Synergetics
Hermann Haken, *Synergetics*.

### Renormalisation
Kenneth G. Wilson, Nobel Lecture; Kadanoff; Michael Fisher.

### Active matter
Marchetti, Joanny, Ramaswamy et al., *Hydrodynamics of Soft Active Matter*.

### Origine de la vie
Hordijk & Steel sur autocatalytic networks; Eigen; Kauffman; Gánti; Szathmáry.

### Active inference
Karl Friston, avec littérature critique sur la portée universelle du FEP.

### Information geometry
Shun-ichi Amari, *Information Geometry and Its Applications*.

### Emergent spacetime
John Wheeler; Mark Van Raamsdonk; Carlo Rovelli; Rafael Sorkin.

## Corpus interne primaire
- `Pi v13 (2).docx`
- `Base de calcul, racine numérique, être manifesté, Lucifer, Christ, Adam et pi.docx`
- `π — Synthèse précise de sa nature fondamentale.docx`
- `3 foundamental constants.docx`
- `A Rosetta Stone of Three Grammars...`
- versions antérieures conservées uniquement pour l'histoire de découverte.

# Matière → vie → conscience

## Matière comme mémoire
Un état physique peut dépendre de son histoire.

Concepts :
- path dependence;
- hystérésis;
- métastabilité;
- mémoire physique;
- information matérialisée.

Landauer :
l'information physiquement réalisée implique un support physique.

## Active matter
Unités locales consommant de l'énergie → ordre collectif hors équilibre.

Pertinence :
cohérence immanente sans organisateur extérieur.

## Origine de la vie
Étapes à distinguer :
- chimie hors équilibre;
- autocatalyse;
- compartimentation;
- auto-entretien;
- réplication;
- hérédité;
- évolution.

Auteurs :
Eigen, Kauffman, Hordijk, Steel, Gánti, Szathmáry, Pross, Walker.

## Autopoïèse
Maturana/Varela :
le vivant maintient l'organisation qui le constitue.

## Deacon
Contraintes, fonction, téléodynamique, émergence du sens.

## Cognition
Varela/Thompson :
enaction, autonomie, cognition incarnée.

## Teilhard
Utilité métaphysique :
matière → complexité → vie → conscience → convergence.

À garder distinct des mécanismes biologiques.

## Garde-fou
Plus d'ordre n'implique pas automatiquement :
- vie;
- intelligence;
- conscience;
- valeur.

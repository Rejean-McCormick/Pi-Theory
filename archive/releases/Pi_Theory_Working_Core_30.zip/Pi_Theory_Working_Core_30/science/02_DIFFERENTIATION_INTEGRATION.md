# Différenciation / intégration

## Problème
Comment créer de la différence sans désintégration, et de l'unité sans homogénéisation ?

## Synergetics
Ordre collectif issu de nombreuses composantes.

## Network science
Concepts :
- modularité;
- communautés;
- hubs;
- intégration;
- hiérarchie;
- réseaux multi-échelles.

Un système complexe peut maintenir des modules spécialisés tout en augmentant leur coordination.

## Mechanobiology
La forme vivante dépend de tensions, forces, contraintes et feedbacks mécaniques.

Idée clé :
**harmonie ≠ absence de tension**.

Une structure stable peut être une tension coordonnée.

## Morphogenèse
Turing, Waddington, Thom :
différenciation de patterns, canalisation, changements qualitatifs de forme.

## Simondon
Individuation/transduction :
une tension métastable produit une nouvelle structure qui résout partiellement le problème initial.

## Formulation Pi Theory
`D élevé + I élevé`

est plus pertinent que :
`uniformité élevée`.

Une future mesure de cohérence devrait récompenser l'intégration **sans effacer la spécialisation**.

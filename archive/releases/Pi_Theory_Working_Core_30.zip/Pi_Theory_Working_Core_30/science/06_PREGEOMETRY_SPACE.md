# Pré-géométrie → espace

## Problème
Le principe originel de Pi Theory est supposé non spatial.

Il faut donc éviter de lui attribuer un cercle physique.

## Pré-géométrie
Plusieurs programmes de physique fondamentale explorent des structures plus primitives que l'espace-temps classique.

Auteurs/programmes :
- Wheeler;
- causal sets / Sorkin;
- loop quantum gravity / Rovelli;
- entanglement & geometry / Van Raamsdonk;
- tensor networks.

## Information geometry
Amari :
une géométrie peut être définie sur des familles de distributions probabilistes.

Intérêt :
`différence informationnelle → métrique`.

## Riemann
Une multiplicité n'a pas automatiquement une métrique.

## Weyl
Symétrie, mesure, géométrie, espace-temps.

## Einstein
La métrique spatio-temporelle participe à la dynamique physique.

## Programme Pi Theory
Étudier la chaîne :

`relation/distinction → comparabilité → mesure → métrique → dimension → espace`.

## Limite
Aucun programme contemporain de pré-géométrie n'implique M/AIME ou le rôle causal de π.

# Seuils — B0UM

## Bifurcation
Une petite variation de paramètre peut changer qualitativement le régime d'un système.

## Transitions de phase
Un système peut passer d'un type d'ordre à un autre à proximité d'un seuil critique.

## Prigogine
Les systèmes loin de l'équilibre peuvent produire de nouvelles structures dissipatives.

## René Thom
Les changements qualitatifs de forme peuvent être étudiés par singularités/catastrophes.

## Haken
L'instabilité d'un état peut permettre l'apparition d'un nouveau paramètre d'ordre.

## Pi Theory
B0UM devient :

`préparation → τ* → nouveau régime`.

C'est plus général et plus utile que l'identification immédiate au Big Bang.

## Question
Quels observables précis correspondraient à `τ` et `τ*` dans un modèle Pi Theory ?

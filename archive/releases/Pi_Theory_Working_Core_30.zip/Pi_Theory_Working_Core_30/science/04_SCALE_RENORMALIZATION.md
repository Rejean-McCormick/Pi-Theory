# Scale, renormalisation et universalité

## SIZE
SIZE ne signifie pas seulement « grand ».

Il peut désigner :
- magnitude;
- nouveau niveau d'observation;
- nouveau régime effectif.

## Renormalisation
Kenneth Wilson, Kadanoff, Fisher.

Concepts :
- coarse-graining;
- flow;
- fixed points;
- relevant variables;
- universality;
- scale invariance.

## Question Pi Theory
Le kernel :

`D ↔ A → T → S`

est-il stable ou transformé de manière régulière lorsqu'on change d'échelle ?

## Universalité
Des systèmes microscopiquement différents peuvent partager les mêmes comportements macroscopiques.

Cela fournit un modèle scientifique de « même grammaire, substrats différents ».

## Pourquoi mieux que fractal
La récurrence multi-échelle n'exige pas une auto-similarité géométrique parfaite.

## Test
Définir une transformation `R_s` et chercher :
- invariants;
- fixed points;
- variables pertinentes;
- classes de comportement.

## Limite
Même une universalité du kernel ne rendrait pas automatiquement π causalement privilégié.

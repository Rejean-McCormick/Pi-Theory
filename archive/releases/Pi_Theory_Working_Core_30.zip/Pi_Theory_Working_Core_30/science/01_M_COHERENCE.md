# M / cohérence — sciences pertinentes

## Question
Comment un système perturbé revient-il vers un régime organisé ?

## Systèmes dynamiques
Concepts :
- attracteur;
- bassin d'attraction;
- stabilité;
- perturbation.

Pi Theory :
M peut être comparé à une dynamique qui rend certains états cohérents attractifs.

## Contrôle
Concepts :
- feedback;
- erreur;
- correction;
- robustesse;
- homeostasie;
- allostasie.

Pi Theory :
`division/écart → contre-action → régime viable`.

## Bioélectricité développementale
Michael Levin et collaborateurs étudient la coordination multicellulaire de forme, de polarité et de régénération.

Pertinence :
`perturbation → coordination distribuée → restauration morphologique`.

C'est le meilleur analogue expérimental actuel de M, sans être M lui-même.

## Synergetics
Hermann Haken :
des paramètres d'ordre peuvent coordonner de nombreux degrés de liberté.

Pertinence :
`multiplicité → ordre collectif`.

## BIEN
Pour passer de cohérence à « bonne cohérence », étudier :
- viabilité;
- persistance;
- réparabilité;
- maintien de diversité;
- fonction.

## Auteurs
Poincaré, Lyapunov, Wiener, Ashby, Cannon, Michael Levin, Hermann Haken, Karl Friston avec prudence.

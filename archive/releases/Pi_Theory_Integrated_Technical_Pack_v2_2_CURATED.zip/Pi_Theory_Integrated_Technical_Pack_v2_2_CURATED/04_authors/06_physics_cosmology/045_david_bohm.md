---
name: "David Bohm"
dates: "1917–1992"
domain: "physique théorique / philosophie"
priority: "A"
status: "research-note"
---

# David Bohm

## Position dans l'atlas
**Dates :** 1917–1992  
**Domaine :** physique théorique / philosophie  
**Priorité :** A

## Concepts pertinents
- ordre impliqué
- ordre expliqué
- holomouvement
- déploiement
- dialogue

## Convergence exacte avec Pi Theory
Très proche du langage de structure implicite → déploiement → monde manifeste et de la totalité comme processus.

## Divergence / limites
L'ordre impliqué n'est pas une confirmation expérimentale de Pi Theory.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Wholeness and the Implicate Order*
- *The Undivided Universe (avec Hiley)*

## Scholars / études secondaires
- Basil Hiley
- David Peat

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Niels Bohr"
dates: "1885–1962"
domain: "physique quantique / philosophie de la physique"
priority: "B"
status: "research-note"
---

# Niels Bohr

## Position dans l'atlas
**Dates :** 1885–1962  
**Domaine :** physique quantique / philosophie de la physique  
**Priorité :** B

## Concepts pertinents
- complémentarité
- conditions de description
- mesure

## Convergence exacte avec Pi Theory
Contrepoids utile : le cadre de mesure et la description expérimentale sont constitutifs de ce qui peut être affirmé.

## Divergence / limites
La complémentarité ne doit pas devenir un synonyme général de 'deux polarités'.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Atomic Physics and Human Knowledge*

## Scholars / études secondaires
- Jan Faye

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

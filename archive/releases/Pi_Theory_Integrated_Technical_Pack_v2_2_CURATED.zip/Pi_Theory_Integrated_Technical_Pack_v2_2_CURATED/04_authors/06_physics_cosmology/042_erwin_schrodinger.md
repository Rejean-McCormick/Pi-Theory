---
name: "Erwin Schrödinger"
dates: "1887–1961"
domain: "physique quantique / philosophie du vivant"
priority: "B"
status: "research-note"
---

# Erwin Schrödinger

## Position dans l'atlas
**Dates :** 1887–1961  
**Domaine :** physique quantique / philosophie du vivant  
**Priorité :** B

## Concepts pertinents
- fonction d'onde
- What Is Life?
- ordre à partir de l'ordre

## Convergence exacte avec Pi Theory
Pont important entre physique, information biologique et question de la vie.

## Divergence / limites
Ses spéculations philosophiques sur l'unité de conscience ne sont pas des conséquences de l'équation de Schrödinger.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *What Is Life?*
- *Mind and Matter*

## Scholars / études secondaires
- Walter Moore

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

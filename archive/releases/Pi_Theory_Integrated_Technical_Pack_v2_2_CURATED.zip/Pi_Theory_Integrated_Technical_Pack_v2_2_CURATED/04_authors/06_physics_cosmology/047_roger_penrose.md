---
name: "Roger Penrose"
dates: "1931–"
domain: "mathématiques / gravitation / conscience"
priority: "B"
status: "research-note"
---

# Roger Penrose

## Position dans l'atlas
**Dates :** 1931–  
**Domaine :** mathématiques / gravitation / conscience  
**Priorité :** B

## Concepts pertinents
- réalisme mathématique
- géométrie
- twistors
- conscience non algorithmique

## Convergence exacte avec Pi Theory
Interlocuteur majeur pour une ontologie réaliste des structures mathématiques.

## Divergence / limites
Ses hypothèses sur conscience et réduction objective restent contestées; rien n'établit un rôle ontologique spécial des digits de π.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *The Road to Reality*
- *The Emperor's New Mind*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

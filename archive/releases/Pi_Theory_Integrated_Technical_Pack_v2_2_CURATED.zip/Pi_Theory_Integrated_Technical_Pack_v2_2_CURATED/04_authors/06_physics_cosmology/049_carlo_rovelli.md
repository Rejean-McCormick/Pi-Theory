---
name: "Carlo Rovelli"
dates: "1956–"
domain: "gravité quantique / philosophie de la physique"
priority: "B"
status: "research-note"
---

# Carlo Rovelli

## Position dans l'atlas
**Dates :** 1956–  
**Domaine :** gravité quantique / philosophie de la physique  
**Priorité :** B

## Concepts pertinents
- relation
- temps
- gravité quantique à boucles
- information relationnelle

## Convergence exacte avec Pi Theory
Très utile pour une ontologie où les relations précèdent les objets et où le temps n'est pas une simple coordonnée absolue.

## Divergence / limites
La relationalité rovellienne ne mène pas à une cosmogonie numérique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Reality Is Not What It Seems*
- *The Order of Time*
- *Helgoland*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Werner Heisenberg"
dates: "1901–1976"
domain: "physique quantique / philosophie"
priority: "B"
status: "research-note"
---

# Werner Heisenberg

## Position dans l'atlas
**Dates :** 1901–1976  
**Domaine :** physique quantique / philosophie  
**Priorité :** B

## Concepts pertinents
- incertitude
- matrices
- symétrie
- Platonisme tardif

## Convergence exacte avec Pi Theory
Pertinent pour le retour des symétries et structures mathématiques au cœur de la physique moderne.

## Divergence / limites
Ses réflexions platoniciennes tardives sont philosophiques, non des résultats de mécanique quantique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Physics and Philosophy*

## Scholars / études secondaires
- Helmut Rechenberg

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

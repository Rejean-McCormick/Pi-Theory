---
name: "Julian Barbour"
dates: "1937–"
domain: "fondements de la physique / temps"
priority: "B"
status: "research-note"
---

# Julian Barbour

## Position dans l'atlas
**Dates :** 1937–  
**Domaine :** fondements de la physique / temps  
**Priorité :** B

## Concepts pertinents
- temps émergent
- configuration
- Platonia

## Convergence exacte avec Pi Theory
Interlocuteur pour la possibilité que le temps ne soit pas fondamental mais dérivé de relations entre configurations.

## Divergence / limites
Modèle très différent de la temporalité comme calcul séquentiel.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *The End of Time*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Albert Einstein"
dates: "1879–1955"
domain: "physique théorique"
priority: "A"
status: "research-note"
---

# Albert Einstein

## Position dans l'atlas
**Dates :** 1879–1955  
**Domaine :** physique théorique  
**Priorité :** A

## Concepts pertinents
- relativité
- géométrie de l'espace-temps
- invariance
- intelligibilité mathématique

## Convergence exacte avec Pi Theory
Indispensable pour toute transition mesure → espace-temps : la géométrie physique devient dynamique et relationnelle.

## Divergence / limites
Einstein n'appuie aucune lecture sémantique des décimales de π.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Relativity: The Special and the General Theory*
- *articles de relativité générale*

## Scholars / études secondaires
- John Stachel

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

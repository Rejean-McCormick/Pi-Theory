---
name: "John Archibald Wheeler"
dates: "1911–2008"
domain: "physique théorique / fondements"
priority: "A/B"
status: "research-note"
---

# John Archibald Wheeler

## Position dans l'atlas
**Dates :** 1911–2008  
**Domaine :** physique théorique / fondements  
**Priorité :** A/B

## Concepts pertinents
- it from bit
- participatory universe
- information

## Convergence exacte avec Pi Theory
Interlocuteur direct pour la thèse réalité/information et la question de savoir si la physique est construite à partir de distinctions informationnelles.

## Divergence / limites
It from Bit est un programme conceptuel, pas une théorie établie selon laquelle le monde est un flux sémantique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Information, Physics, Quantum: The Search for Links*
- *It from Bit*

## Scholars / études secondaires
- Kenneth Ford

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

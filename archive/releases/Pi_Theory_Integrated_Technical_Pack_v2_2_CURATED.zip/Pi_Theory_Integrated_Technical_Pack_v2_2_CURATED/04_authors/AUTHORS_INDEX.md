# Index des auteurs

| Auteur | Domaine | Priorité | Fiche |
|---|---|---|---|
| Pythagore et les Pythagoriciens | philosophie antique / mathématiques / harmonie | A | [01_antiquity_neoplatonism/001_pythagore_et_les_pythagoriciens.md](01_antiquity_neoplatonism/001_pythagore_et_les_pythagoriciens.md) |
| Empédocle | présocratique / cosmologie | A | [01_antiquity_neoplatonism/002_empedocle.md](01_antiquity_neoplatonism/002_empedocle.md) |
| Platon | métaphysique / philosophie des mathématiques | A | [01_antiquity_neoplatonism/003_platon.md](01_antiquity_neoplatonism/003_platon.md) |
| Plotin | néoplatonisme | A | [01_antiquity_neoplatonism/004_plotin.md](01_antiquity_neoplatonism/004_plotin.md) |
| Proclus | néoplatonisme systématique | A | [01_antiquity_neoplatonism/005_proclus.md](01_antiquity_neoplatonism/005_proclus.md) |
| Pseudo-Denys l'Aréopagite | théologie apophatique / néoplatonisme chrétien | A | [01_antiquity_neoplatonism/006_pseudo_denys_l_areopagite.md](01_antiquity_neoplatonism/006_pseudo_denys_l_areopagite.md) |
| Jean Scot Érigène | métaphysique chrétienne / néoplatonisme | A | [01_antiquity_neoplatonism/007_jean_scot_erigene.md](01_antiquity_neoplatonism/007_jean_scot_erigene.md) |
| Nicolas de Cues | métaphysique / mathématiques / théologie | A | [01_antiquity_neoplatonism/008_nicolas_de_cues.md](01_antiquity_neoplatonism/008_nicolas_de_cues.md) |
| Giordano Bruno | métaphysique / cosmologie | B | [01_antiquity_neoplatonism/009_giordano_bruno.md](01_antiquity_neoplatonism/009_giordano_bruno.md) |
| Jacob Böhme | théosophie chrétienne / métaphysique | A | [02_christian_mysticism_martinism/010_jacob_bohme.md](02_christian_mysticism_martinism/010_jacob_bohme.md) |
| Paracelse | médecine / philosophie naturelle / signatures | C | [02_christian_mysticism_martinism/011_paracelse.md](02_christian_mysticism_martinism/011_paracelse.md) |
| Martinès de Pasqually | théurgie / martinisme primitif | B | [02_christian_mysticism_martinism/012_martines_de_pasqually.md](02_christian_mysticism_martinism/012_martines_de_pasqually.md) |
| Louis-Claude de Saint-Martin | mystique chrétienne / martinisme | B | [02_christian_mysticism_martinism/013_louis_claude_de_saint_martin.md](02_christian_mysticism_martinism/013_louis_claude_de_saint_martin.md) |
| Papus (Gérard Encausse) | occultisme / martinisme moderne | C | [02_christian_mysticism_martinism/014_papus_gerard_encausse.md](02_christian_mysticism_martinism/014_papus_gerard_encausse.md) |
| Constant Chevillon | ésotérisme chrétien / martinisme | B | [02_christian_mysticism_martinism/015_constant_chevillon.md](02_christian_mysticism_martinism/015_constant_chevillon.md) |
| René Guénon | métaphysique traditionnelle / critique de la modernité | B/C | [02_christian_mysticism_martinism/081_rene_guenon.md](02_christian_mysticism_martinism/081_rene_guenon.md) |
| Sefer Yetzirah (tradition) | mystique juive / cosmologie des lettres et nombres | A | [03_kabbalah/016_sefer_yetzirah_tradition.md](03_kabbalah/016_sefer_yetzirah_tradition.md) |
| Isaac Louria | Kabbale lourianique | A | [03_kabbalah/017_isaac_louria.md](03_kabbalah/017_isaac_louria.md) |
| Hayyim Vital | Kabbale lourianique / transmission | A | [03_kabbalah/018_hayyim_vital.md](03_kabbalah/018_hayyim_vital.md) |
| Leibniz | métaphysique / mathématiques | A/B | [04_modern_philosophy_process/019_leibniz.md](04_modern_philosophy_process/019_leibniz.md) |
| Spinoza | métaphysique / immanence | B | [04_modern_philosophy_process/020_spinoza.md](04_modern_philosophy_process/020_spinoza.md) |
| Schelling | idéalisme allemand / philosophie de la nature | A | [04_modern_philosophy_process/021_schelling.md](04_modern_philosophy_process/021_schelling.md) |
| Hegel | idéalisme allemand / logique | A | [04_modern_philosophy_process/022_hegel.md](04_modern_philosophy_process/022_hegel.md) |
| Bergson | philosophie du temps / évolution | B | [04_modern_philosophy_process/023_bergson.md](04_modern_philosophy_process/023_bergson.md) |
| Alfred North Whitehead | philosophie du processus / mathématiques | A | [04_modern_philosophy_process/024_alfred_north_whitehead.md](04_modern_philosophy_process/024_alfred_north_whitehead.md) |
| Pierre Teilhard de Chardin | paléontologie / théologie / évolution cosmique | A | [04_modern_philosophy_process/025_pierre_teilhard_de_chardin.md](04_modern_philosophy_process/025_pierre_teilhard_de_chardin.md) |
| Gilbert Simondon | philosophie de la technique / individuation | A | [04_modern_philosophy_process/026_gilbert_simondon.md](04_modern_philosophy_process/026_gilbert_simondon.md) |
| George Spencer-Brown | logique / formes | A | [04_modern_philosophy_process/027_george_spencer_brown.md](04_modern_philosophy_process/027_george_spencer_brown.md) |
| Charles S. Peirce | logique / sémiotique / métaphysique | A | [04_modern_philosophy_process/028_charles_s_peirce.md](04_modern_philosophy_process/028_charles_s_peirce.md) |
| Ernst Cassirer | néokantisme / formes symboliques | B | [04_modern_philosophy_process/029_ernst_cassirer.md](04_modern_philosophy_process/029_ernst_cassirer.md) |
| Leonhard Euler | mathématiques | A | [05_math_foundations/030_leonhard_euler.md](05_math_foundations/030_leonhard_euler.md) |
| Georg Cantor | théorie des ensembles / infini | A | [05_math_foundations/031_georg_cantor.md](05_math_foundations/031_georg_cantor.md) |
| Bernhard Riemann | géométrie / analyse | A | [05_math_foundations/032_bernhard_riemann.md](05_math_foundations/032_bernhard_riemann.md) |
| Hermann Weyl | mathématiques / physique / philosophie | A | [05_math_foundations/033_hermann_weyl.md](05_math_foundations/033_hermann_weyl.md) |
| Emmy Noether | mathématiques / physique théorique | A | [05_math_foundations/034_emmy_noether.md](05_math_foundations/034_emmy_noether.md) |
| Kurt Gödel | logique / fondements | B | [05_math_foundations/035_kurt_godel.md](05_math_foundations/035_kurt_godel.md) |
| Alan Turing | logique / calcul / morphogenèse | A | [05_math_foundations/036_alan_turing.md](05_math_foundations/036_alan_turing.md) |
| Gregory Chaitin | algorithmic information theory | B | [05_math_foundations/037_gregory_chaitin.md](05_math_foundations/037_gregory_chaitin.md) |
| Andrey Kolmogorov | probabilités / complexité | A/B | [05_math_foundations/038_andrey_kolmogorov.md](05_math_foundations/038_andrey_kolmogorov.md) |
| Eugene P. Wigner | physique mathématique / philosophie des sciences | A/B | [05_math_foundations/082_eugene_wigner.md](05_math_foundations/082_eugene_wigner.md) |
| Johannes Kepler | astronomie / mathématiques / harmonie cosmique | B | [05_math_foundations/083_johannes_kepler.md](05_math_foundations/083_johannes_kepler.md) |
| Albert Einstein | physique théorique | A | [06_physics_cosmology/039_albert_einstein.md](06_physics_cosmology/039_albert_einstein.md) |
| Niels Bohr | physique quantique / philosophie de la physique | B | [06_physics_cosmology/040_niels_bohr.md](06_physics_cosmology/040_niels_bohr.md) |
| Werner Heisenberg | physique quantique / philosophie | B | [06_physics_cosmology/041_werner_heisenberg.md](06_physics_cosmology/041_werner_heisenberg.md) |
| Erwin Schrödinger | physique quantique / philosophie du vivant | B | [06_physics_cosmology/042_erwin_schrodinger.md](06_physics_cosmology/042_erwin_schrodinger.md) |
| Wolfgang Pauli | physique quantique / symétrie / dialogue avec Jung | B | [06_physics_cosmology/043_wolfgang_pauli.md](06_physics_cosmology/043_wolfgang_pauli.md) |
| John Archibald Wheeler | physique théorique / fondements | A/B | [06_physics_cosmology/044_john_archibald_wheeler.md](06_physics_cosmology/044_john_archibald_wheeler.md) |
| David Bohm | physique théorique / philosophie | A | [06_physics_cosmology/045_david_bohm.md](06_physics_cosmology/045_david_bohm.md) |
| Basil Hiley | physique mathématique | B | [06_physics_cosmology/046_basil_hiley.md](06_physics_cosmology/046_basil_hiley.md) |
| Roger Penrose | mathématiques / gravitation / conscience | B | [06_physics_cosmology/047_roger_penrose.md](06_physics_cosmology/047_roger_penrose.md) |
| Max Tegmark | cosmologie / fondements | B | [06_physics_cosmology/048_max_tegmark.md](06_physics_cosmology/048_max_tegmark.md) |
| Carlo Rovelli | gravité quantique / philosophie de la physique | B | [06_physics_cosmology/049_carlo_rovelli.md](06_physics_cosmology/049_carlo_rovelli.md) |
| Lee Smolin | gravité quantique / cosmologie | B | [06_physics_cosmology/050_lee_smolin.md](06_physics_cosmology/050_lee_smolin.md) |
| Julian Barbour | fondements de la physique / temps | B | [06_physics_cosmology/051_julian_barbour.md](06_physics_cosmology/051_julian_barbour.md) |
| Claude Shannon | théorie de l'information | A | [07_information_systems/052_claude_shannon.md](07_information_systems/052_claude_shannon.md) |
| Rolf Landauer | physique de l'information | A | [07_information_systems/053_rolf_landauer.md](07_information_systems/053_rolf_landauer.md) |
| Norbert Wiener | cybernétique | A/B | [07_information_systems/054_norbert_wiener.md](07_information_systems/054_norbert_wiener.md) |
| W. Ross Ashby | cybernétique / systèmes | A/B | [07_information_systems/055_w_ross_ashby.md](07_information_systems/055_w_ross_ashby.md) |
| Heinz von Foerster | cybernétique de second ordre | B | [07_information_systems/056_heinz_von_foerster.md](07_information_systems/056_heinz_von_foerster.md) |
| Ludwig von Bertalanffy | théorie générale des systèmes | B | [07_information_systems/057_ludwig_von_bertalanffy.md](07_information_systems/057_ludwig_von_bertalanffy.md) |
| Gregory Bateson | anthropologie / cybernétique / écologie de l'esprit | A/B | [07_information_systems/058_gregory_bateson.md](07_information_systems/058_gregory_bateson.md) |
| Humberto Maturana | biologie / cognition | B | [07_information_systems/059_humberto_maturana.md](07_information_systems/059_humberto_maturana.md) |
| Francisco Varela | biologie / cognition / phénoménologie | A/B | [07_information_systems/060_francisco_varela.md](07_information_systems/060_francisco_varela.md) |
| Ilya Prigogine | thermodynamique / systèmes hors équilibre | A/B | [07_information_systems/061_ilya_prigogine.md](07_information_systems/061_ilya_prigogine.md) |
| Stuart Kauffman | biologie théorique / complexité | B | [07_information_systems/062_stuart_kauffman.md](07_information_systems/062_stuart_kauffman.md) |
| Terrence Deacon | anthropologie biologique / sémiotique | A/B | [07_information_systems/063_terrence_deacon.md](07_information_systems/063_terrence_deacon.md) |
| Karl Friston | neurosciences théoriques | B/C | [07_information_systems/064_karl_friston.md](07_information_systems/064_karl_friston.md) |
| Charles Darwin | biologie évolutive | A/B | [08_biology_consciousness/065_charles_darwin.md](08_biology_consciousness/065_charles_darwin.md) |
| D'Arcy Wentworth Thompson | biologie mathématique / forme | A/B | [08_biology_consciousness/066_d_arcy_wentworth_thompson.md](08_biology_consciousness/066_d_arcy_wentworth_thompson.md) |
| Conrad Waddington | biologie du développement | B | [08_biology_consciousness/067_conrad_waddington.md](08_biology_consciousness/067_conrad_waddington.md) |
| René Thom | mathématiques / morphogenèse | A/B | [08_biology_consciousness/068_rene_thom.md](08_biology_consciousness/068_rene_thom.md) |
| Brian Goodwin | biologie théorique | C | [08_biology_consciousness/069_brian_goodwin.md](08_biology_consciousness/069_brian_goodwin.md) |
| William James | psychologie / philosophie | B | [08_biology_consciousness/070_william_james.md](08_biology_consciousness/070_william_james.md) |
| Carl Gustav Jung | psychologie analytique | C | [08_biology_consciousness/071_carl_gustav_jung.md](08_biology_consciousness/071_carl_gustav_jung.md) |
| Marie-Louise von Franz | psychologie analytique / nombre | C | [08_biology_consciousness/072_marie_louise_von_franz.md](08_biology_consciousness/072_marie_louise_von_franz.md) |
| Giulio Tononi | neurosciences / théorie de la conscience | C | [08_biology_consciousness/073_giulio_tononi.md](08_biology_consciousness/073_giulio_tononi.md) |
| Evan Thompson | philosophie de l'esprit / sciences cognitives | B | [08_biology_consciousness/074_evan_thompson.md](08_biology_consciousness/074_evan_thompson.md) |
| Ian Barbour | science et religion | B | [09_science_religion/076_ian_barbour.md](09_science_religion/076_ian_barbour.md) |
| John Polkinghorne | physique / théologie | B | [09_science_religion/077_john_polkinghorne.md](09_science_religion/077_john_polkinghorne.md) |
| John F. Haught | théologie / évolution | B | [09_science_religion/078_john_f_haught.md](09_science_religion/078_john_f_haught.md) |
| Luciano Floridi | philosophie de l'information | B | [09_science_religion/079_luciano_floridi.md](09_science_religion/079_luciano_floridi.md) |
| Niklas Luhmann | théorie des systèmes / sociologie | C | [09_science_religion/080_niklas_luhmann.md](09_science_religion/080_niklas_luhmann.md) |

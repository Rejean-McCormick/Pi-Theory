---
name: "Martinès de Pasqually"
dates: "c. 1727–1774"
domain: "théurgie / martinisme primitif"
priority: "B"
status: "research-note"
---

# Martinès de Pasqually

## Position dans l'atlas
**Dates :** c. 1727–1774  
**Domaine :** théurgie / martinisme primitif  
**Priorité :** B

## Concepts pertinents
- réintégration
- chute
- émanation
- retour

## Convergence exacte avec Pi Theory
Donne une architecture explicite de sortie, chute et réintégration utile au thème de retour.

## Divergence / limites
Cadre théurgique chrétien spécifique; faible rapport direct aux mathématiques.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Traité de la réintégration des êtres*

## Scholars / études secondaires
- Robert Amadou

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

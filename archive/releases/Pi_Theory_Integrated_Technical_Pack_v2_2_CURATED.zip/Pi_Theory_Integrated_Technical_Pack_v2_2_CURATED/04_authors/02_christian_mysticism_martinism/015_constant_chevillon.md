---
name: "Constant Chevillon"
dates: "1880–1944"
domain: "ésotérisme chrétien / martinisme"
priority: "B"
status: "research-note"
---

# Constant Chevillon

## Position dans l'atlas
**Dates :** 1880–1944  
**Domaine :** ésotérisme chrétien / martinisme  
**Priorité :** B

## Concepts pertinents
- néant et être
- initiation
- synthèse métaphysique

## Convergence exacte avec Pi Theory
Point de départ historique de la conversation; intéressant comme confluence moderne de motifs plus anciens.

## Divergence / limites
Il est moins fondamental que Böhme, Cues, Proclus ou Érigène pour construire la charpente philosophique du livre.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Du Néant à l'Être*

## Scholars / études secondaires
- Travaux historiques sur le martinisme français du XXe siècle

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

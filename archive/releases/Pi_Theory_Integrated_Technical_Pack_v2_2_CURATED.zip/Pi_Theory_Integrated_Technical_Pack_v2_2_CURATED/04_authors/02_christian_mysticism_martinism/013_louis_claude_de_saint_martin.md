---
name: "Louis-Claude de Saint-Martin"
dates: "1743–1803"
domain: "mystique chrétienne / martinisme"
priority: "B"
status: "research-note"
---

# Louis-Claude de Saint-Martin

## Position dans l'atlas
**Dates :** 1743–1803  
**Domaine :** mystique chrétienne / martinisme  
**Priorité :** B

## Concepts pertinents
- homme-esprit
- Dieu-homme-univers
- réintégration
- influence de Böhme

## Convergence exacte avec Pi Theory
Pont historique important entre Böhme et la tradition française qui mène jusqu'au contexte de Chevillon.

## Divergence / limites
Sa voie intérieure ne fournit pas de théorie de mesure ou d'information.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Le Ministère de l'homme-esprit*
- *Tableau naturel des rapports qui existent entre Dieu, l'homme et l'univers*

## Scholars / études secondaires
- Robert Amadou
- Nicole Jacques-Lefèvre

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

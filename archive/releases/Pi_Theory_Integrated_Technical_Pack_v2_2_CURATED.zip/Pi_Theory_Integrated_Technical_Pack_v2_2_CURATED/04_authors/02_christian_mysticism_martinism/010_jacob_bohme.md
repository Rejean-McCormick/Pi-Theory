---
name: "Jacob Böhme"
dates: "1575–1624"
domain: "théosophie chrétienne / métaphysique"
priority: "A"
status: "research-note"
---

# Jacob Böhme

## Position dans l'atlas
**Dates :** 1575–1624  
**Domaine :** théosophie chrétienne / métaphysique  
**Priorité :** A

## Concepts pertinents
- Ungrund
- volonté
- désir
- contrariété
- feu et lumière
- signature
- manifestation

## Convergence exacte avec Pi Theory
L'un des parallèles les plus forts : la différence et la contrariété deviennent conditions productives de manifestation.

## Divergence / limites
Böhme emploie un langage théologique et visionnaire, pas un formalisme mathématique; ne pas convertir ses sept qualités en digits.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Mysterium Magnum*
- *De Signatura Rerum*
- *Aurora*
- *Six Points théosophiques*

## Scholars / études secondaires
- Andrew Weeks
- Cyril O'Regan
- Ariel Hessayon

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

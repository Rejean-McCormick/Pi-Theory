---
name: "René Guénon"
dates: "1886–1951"
domain: "métaphysique traditionnelle / critique de la modernité"
priority: "B/C"
status: "research-note"
---

# René Guénon

## Position dans l'atlas
**Dates :** 1886–1951  
**Domaine :** métaphysique traditionnelle / critique de la modernité  
**Priorité :** B/C

## Concepts pertinents
- quantité vs qualité
- symbolisme
- infini
- métaphysique

## Convergence exacte avec Pi Theory
Contrepoids utile : oblige à demander si la réduction au nombre quantitatif trahit précisément ce que la métaphysique cherche.

## Divergence / limites
Son traditionalisme et ses thèses historiques ne constituent pas une méthodologie scientifique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Le Règne de la quantité et les signes des temps*
- *Les Principes du calcul infinitésimal*

## Scholars / études secondaires
- Wouter Hanegraaff (contexte ésotérisme occidental)

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

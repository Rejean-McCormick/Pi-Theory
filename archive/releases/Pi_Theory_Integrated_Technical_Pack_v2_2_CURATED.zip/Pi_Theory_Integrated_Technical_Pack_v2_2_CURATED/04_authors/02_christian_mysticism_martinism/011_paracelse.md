---
name: "Paracelse"
dates: "1493/4–1541"
domain: "médecine / philosophie naturelle / signatures"
priority: "C"
status: "research-note"
---

# Paracelse

## Position dans l'atlas
**Dates :** 1493/4–1541  
**Domaine :** médecine / philosophie naturelle / signatures  
**Priorité :** C

## Concepts pertinents
- signatures
- microcosme/macrocosme
- nature comme texte

## Convergence exacte avec Pi Theory
Important pour l'histoire de l'idée que des structures visibles expriment des principes invisibles.

## Divergence / limites
La doctrine des signatures n'est pas une méthodologie scientifique moderne et favorise la surinterprétation si elle est utilisée sans contrôle.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Œuvres médicales et philosophiques choisies*

## Scholars / études secondaires
- Walter Pagel
- Charles Webster

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Plotin"
dates: "204/5–270"
domain: "néoplatonisme"
priority: "A"
status: "research-note"
---

# Plotin

## Position dans l'atlas
**Dates :** 204/5–270  
**Domaine :** néoplatonisme  
**Priorité :** A

## Concepts pertinents
- Un
- procession
- retour
- Intellect
- Âme
- surabondance

## Convergence exacte avec Pi Theory
Modèle canonique pour Source → procession → multiplicité → retour sans réduire la Source à un étant interne.

## Divergence / limites
La procession plotinienne n'est ni temporelle ni computationnelle; elle n'implique aucune structure décimale.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Ennéades V.1*
- *Ennéades V.2*
- *Ennéades VI.9*

## Scholars / études secondaires
- Lloyd P. Gerson
- Dominic O'Meara

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

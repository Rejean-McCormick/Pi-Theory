---
name: "Giordano Bruno"
dates: "1548–1600"
domain: "métaphysique / cosmologie"
priority: "B"
status: "research-note"
---

# Giordano Bruno

## Position dans l'atlas
**Dates :** 1548–1600  
**Domaine :** métaphysique / cosmologie  
**Priorité :** B

## Concepts pertinents
- univers infini
- unité des contraires
- pluralité des mondes
- héritage cusain

## Convergence exacte avec Pi Theory
Élargit l'infini métaphysique en cosmologie et force la question de l'échelle sans centre absolu physique.

## Divergence / limites
Sa cosmologie historique ne doit pas être confondue avec la cosmologie relativiste moderne.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *De la cause, du principe et de l'Un*
- *De l'infini, de l'univers et des mondes*

## Scholars / études secondaires
- Hilary Gatti
- Ingrid D. Rowland

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

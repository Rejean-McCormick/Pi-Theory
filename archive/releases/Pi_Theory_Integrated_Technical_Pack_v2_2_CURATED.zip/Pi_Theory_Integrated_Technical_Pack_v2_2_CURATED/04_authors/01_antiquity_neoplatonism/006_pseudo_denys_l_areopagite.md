---
name: "Pseudo-Denys l'Aréopagite"
dates: "fin Ve–début VIe s."
domain: "théologie apophatique / néoplatonisme chrétien"
priority: "A"
status: "research-note"
---

# Pseudo-Denys l'Aréopagite

## Position dans l'atlas
**Dates :** fin Ve–début VIe s.  
**Domaine :** théologie apophatique / néoplatonisme chrétien  
**Priorité :** A

## Concepts pertinents
- au-delà de l'être
- procession et retour
- Bien
- éros
- hiérarchie

## Convergence exacte avec Pi Theory
Fondamental pour éviter l'identification Source = nombre : le principe ultime excède toute détermination et toute représentation.

## Divergence / limites
La théologie dionysienne est explicitement chrétienne et lit la création comme dépendance à Dieu, non comme calcul de π.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Les Noms divins*
- *Théologie mystique*
- *Hiérarchie céleste*

## Scholars / études secondaires
- Andrew Louth
- Paul Rorem

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

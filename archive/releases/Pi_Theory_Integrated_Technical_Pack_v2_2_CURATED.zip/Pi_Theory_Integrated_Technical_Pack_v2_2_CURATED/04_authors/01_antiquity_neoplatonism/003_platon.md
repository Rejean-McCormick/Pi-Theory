---
name: "Platon"
dates: "c. 428–348 av. J.-C."
domain: "métaphysique / philosophie des mathématiques"
priority: "A"
status: "research-note"
---

# Platon

## Position dans l'atlas
**Dates :** c. 428–348 av. J.-C.  
**Domaine :** métaphysique / philosophie des mathématiques  
**Priorité :** A

## Concepts pertinents
- Bien
- formes
- cosmos mathématiquement ordonné
- khôra
- médiation géométrique

## Convergence exacte avec Pi Theory
Le Timée fournit un paradigme majeur d'un cosmos dont l'intelligibilité passe par forme, proportion, mesure et géométrie.

## Divergence / limites
Le Démiurge platonicien et les solides du Timée ne doivent pas être recodés directement comme Pi Theory.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Timée*
- *République VI–VII*
- *Philèbe*

## Scholars / études secondaires
- Thomas K. Johansen
- Lloyd P. Gerson

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

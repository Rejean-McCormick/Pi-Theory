---
name: "Pythagore et les Pythagoriciens"
dates: "VIe–Ve s. av. J.-C."
domain: "philosophie antique / mathématiques / harmonie"
priority: "A"
status: "research-note"
---

# Pythagore et les Pythagoriciens

## Position dans l'atlas
**Dates :** VIe–Ve s. av. J.-C.  
**Domaine :** philosophie antique / mathématiques / harmonie  
**Priorité :** A

## Concepts pertinents
- nombre comme structure cosmique
- harmonie
- proportion
- musique des rapports

## Convergence exacte avec Pi Theory
Point de départ historique pour toute ontologie où nombre, proportion et ordre ne sont pas de simples instruments descriptifs.

## Divergence / limites
Les doctrines pythagoriciennes sont fragmentaires et reconstruites par des sources tardives; éviter de leur attribuer une théorie moderne de l'information ou de π.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Fragments et témoignages pythagoriciens*
- *Aristote, Métaphysique I, sur les Pythagoriciens*

## Scholars / études secondaires
- Walter Burkert
- Carl Huffman

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

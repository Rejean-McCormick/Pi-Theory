---
name: "Nicolas de Cues"
dates: "1401–1464"
domain: "métaphysique / mathématiques / théologie"
priority: "A"
status: "research-note"
---

# Nicolas de Cues

## Position dans l'atlas
**Dates :** 1401–1464  
**Domaine :** métaphysique / mathématiques / théologie  
**Priorité :** A

## Concepts pertinents
- docte ignorance
- maximum/minimum
- coïncidence des opposés
- infini
- proportion
- contraction

## Convergence exacte avec Pi Theory
Interlocuteur majeur pour 88/SIZE, infini, mesure, cercle, représentation finie d'un principe qui la dépasse.

## Divergence / limites
Les figures géométriques chez Cues sont des analogies théologiques; elles ne prouvent pas une ontologie physique fondée sur π.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *De docta ignorantia*
- *De coniecturis*
- *De visione Dei*

## Scholars / études secondaires
- Jasper Hopkins
- Kurt Flasch
- Clyde Lee Miller

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "John F. Haught"
dates: "1942–"
domain: "théologie / évolution"
priority: "B"
status: "research-note"
---

# John F. Haught

## Position dans l'atlas
**Dates :** 1942–  
**Domaine :** théologie / évolution  
**Priorité :** B

## Concepts pertinents
- évolution et foi
- Teilhard
- devenir cosmique

## Convergence exacte avec Pi Theory
Scholar contemporain utile pour inscrire Teilhard dans les débats science-religion.

## Divergence / limites
Approche théologique, non physique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *God After Darwin*
- *Resting on the Future*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

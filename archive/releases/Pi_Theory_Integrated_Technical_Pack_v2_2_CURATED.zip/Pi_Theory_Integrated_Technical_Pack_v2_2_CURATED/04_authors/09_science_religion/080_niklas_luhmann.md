---
name: "Niklas Luhmann"
dates: "1927–1998"
domain: "théorie des systèmes / sociologie"
priority: "C"
status: "research-note"
---

# Niklas Luhmann

## Position dans l'atlas
**Dates :** 1927–1998  
**Domaine :** théorie des systèmes / sociologie  
**Priorité :** C

## Concepts pertinents
- distinction
- communication
- autopoïèse sociale
- observation

## Convergence exacte avec Pi Theory
Peut formaliser la manière dont des systèmes de sens se différencient et se reproduisent.

## Divergence / limites
Très spécifique aux systèmes sociaux et fortement constructiviste.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Social Systems*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Luciano Floridi"
dates: "1964–"
domain: "philosophie de l'information"
priority: "B"
status: "research-note"
---

# Luciano Floridi

## Position dans l'atlas
**Dates :** 1964–  
**Domaine :** philosophie de l'information  
**Priorité :** B

## Concepts pertinents
- infosphere
- information structurelle
- philosophie de l'information

## Convergence exacte avec Pi Theory
Cadre contemporain pour distinguer niveaux d'information, systèmes et ontologie informationnelle.

## Divergence / limites
Ne donne pas licence pour identifier information et sens métaphysique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *The Philosophy of Information*
- *The Fourth Revolution*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

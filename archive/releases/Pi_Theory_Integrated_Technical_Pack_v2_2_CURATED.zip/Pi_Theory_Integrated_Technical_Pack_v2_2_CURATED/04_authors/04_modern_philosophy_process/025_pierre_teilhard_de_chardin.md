---
name: "Pierre Teilhard de Chardin"
dates: "1881–1955"
domain: "paléontologie / théologie / évolution cosmique"
priority: "A"
status: "research-note"
---

# Pierre Teilhard de Chardin

## Position dans l'atlas
**Dates :** 1881–1955  
**Domaine :** paléontologie / théologie / évolution cosmique  
**Priorité :** A

## Concepts pertinents
- complexification
- complexité-conscience
- noosphère
- Point Oméga
- cosmogenèse

## Convergence exacte avec Pi Theory
Auteur clé pour élargir Pi Theory au vivant et à la conscience : matière → complexification → vie → pensée → réflexivité.

## Divergence / limites
La loi complexité-conscience n'est pas une loi physique quantitativement établie; le Point Oméga est théologico-philosophique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Le Phénomène humain*
- *L'Avenir de l'homme*
- *Le Milieu divin*

## Scholars / études secondaires
- Ursula King
- John F. Haught
- Thomas M. King

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

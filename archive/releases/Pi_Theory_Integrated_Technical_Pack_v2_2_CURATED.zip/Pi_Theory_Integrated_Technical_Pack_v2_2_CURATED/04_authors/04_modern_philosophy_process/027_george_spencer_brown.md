---
name: "George Spencer-Brown"
dates: "1923–2016"
domain: "logique / formes"
priority: "A"
status: "research-note"
---

# George Spencer-Brown

## Position dans l'atlas
**Dates :** 1923–2016  
**Domaine :** logique / formes  
**Priorité :** A

## Concepts pertinents
- distinction
- mark
- crossing
- re-entry

## Convergence exacte avec Pi Theory
Interlocuteur direct pour la question de la première distinction : une forme apparaît quand une frontière est tracée.

## Divergence / limites
Laws of Form ne dérive ni métrique, ni espace-temps, ni physique à partir de la distinction seule.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Laws of Form*

## Scholars / études secondaires
- Louis H. Kauffman
- Francisco Varela (réception)

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

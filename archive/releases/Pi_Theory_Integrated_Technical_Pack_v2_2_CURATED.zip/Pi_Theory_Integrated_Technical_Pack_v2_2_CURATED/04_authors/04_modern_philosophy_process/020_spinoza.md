---
name: "Spinoza"
dates: "1632–1677"
domain: "métaphysique / immanence"
priority: "B"
status: "research-note"
---

# Spinoza

## Position dans l'atlas
**Dates :** 1632–1677  
**Domaine :** métaphysique / immanence  
**Priorité :** B

## Concepts pertinents
- substance unique
- modes
- causalité immanente
- nécessité

## Convergence exacte avec Pi Theory
Excellent contrepoint pour la notion de causalité immanente sans message ni dessein extérieur.

## Divergence / limites
Sa substance n'est pas une séquence, un programme ni une transcendance hors système.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Éthique*

## Scholars / études secondaires
- Michael Della Rocca
- Steven Nadler

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

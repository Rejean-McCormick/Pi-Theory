---
name: "Gilbert Simondon"
dates: "1924–1989"
domain: "philosophie de la technique / individuation"
priority: "A"
status: "research-note"
---

# Gilbert Simondon

## Position dans l'atlas
**Dates :** 1924–1989  
**Domaine :** philosophie de la technique / individuation  
**Priorité :** A

## Concepts pertinents
- préindividuel
- métastabilité
- transduction
- information
- individuation

## Convergence exacte avec Pi Theory
Probablement le meilleur langage moderne pour potentiel → résolution de tension → nouvelle structure / nouveau régime.

## Divergence / limites
Simondon ne propose ni cosmologie de π ni théorie théologique de la Source.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *L'Individuation à la lumière des notions de forme et d'information*
- *Du mode d'existence des objets techniques*

## Scholars / études secondaires
- Muriel Combes
- Jean-Hugues Barthélémy

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Hegel"
dates: "1770–1831"
domain: "idéalisme allemand / logique"
priority: "A"
status: "research-note"
---

# Hegel

## Position dans l'atlas
**Dates :** 1770–1831  
**Domaine :** idéalisme allemand / logique  
**Priorité :** A

## Concepts pertinents
- détermination
- négation
- quantité
- mesure
- devenir

## Convergence exacte avec Pi Theory
Probablement le complément philosophique le plus puissant pour SIZE → mesure : la mesure articule qualité et quantité.

## Divergence / limites
La dialectique hégélienne ne doit pas être réduite à un algorithme à six blocs.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Science de la logique, Doctrine de l'être, sections Quantité et Mesure*

## Scholars / études secondaires
- Stephen Houlgate
- Robert Pippin

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

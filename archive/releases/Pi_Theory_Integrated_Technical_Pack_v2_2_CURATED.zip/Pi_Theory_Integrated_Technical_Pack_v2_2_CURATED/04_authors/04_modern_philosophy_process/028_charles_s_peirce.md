---
name: "Charles S. Peirce"
dates: "1839–1914"
domain: "logique / sémiotique / métaphysique"
priority: "A"
status: "research-note"
---

# Charles S. Peirce

## Position dans l'atlas
**Dates :** 1839–1914  
**Domaine :** logique / sémiotique / métaphysique  
**Priorité :** A

## Concepts pertinents
- signe-objet-interprétant
- icône/index/symbole
- synechisme
- tychisme
- habitude

## Convergence exacte avec Pi Theory
Indispensable pour décomposer le passage 88 → icône d'infini → nombre → mot → fonction et pour analyser le statut du sens.

## Divergence / limites
La sémiotique peircienne ne garantit pas que toute convergence symbolique soit ontologiquement fondée.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *The Essential Peirce*
- *Collected Papers, textes sémiotiques*

## Scholars / études secondaires
- T. L. Short
- Cheryl Misak

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

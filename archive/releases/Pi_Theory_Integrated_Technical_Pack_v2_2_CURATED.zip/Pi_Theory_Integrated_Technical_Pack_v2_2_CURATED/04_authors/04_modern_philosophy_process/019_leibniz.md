---
name: "Leibniz"
dates: "1646–1716"
domain: "métaphysique / mathématiques"
priority: "A/B"
status: "research-note"
---

# Leibniz

## Position dans l'atlas
**Dates :** 1646–1716  
**Domaine :** métaphysique / mathématiques  
**Priorité :** A/B

## Concepts pertinents
- harmonie préétablie
- monades
- calcul infinitésimal
- raison suffisante
- relation

## Convergence exacte avec Pi Theory
Réunit harmonie, mathématiques, infinitésimal et pluralité de centres représentatifs.

## Divergence / limites
Les monades n'interagissent pas causalement au sens ordinaire; ce cadre diffère fortement d'un univers computationnel.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Monadologie*
- *Discours de métaphysique*
- *Nouveaux essais*

## Scholars / études secondaires
- Daniel Garber
- Donald Rutherford

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

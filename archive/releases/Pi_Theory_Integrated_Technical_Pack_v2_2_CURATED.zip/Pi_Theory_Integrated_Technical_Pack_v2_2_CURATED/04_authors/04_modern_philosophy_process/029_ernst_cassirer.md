---
name: "Ernst Cassirer"
dates: "1874–1945"
domain: "néokantisme / formes symboliques"
priority: "B"
status: "research-note"
---

# Ernst Cassirer

## Position dans l'atlas
**Dates :** 1874–1945  
**Domaine :** néokantisme / formes symboliques  
**Priorité :** B

## Concepts pertinents
- fonction
- relation
- formes symboliques
- science et langage

## Convergence exacte avec Pi Theory
Aide à comprendre comment une structure relationnelle peut être médiatisée par des systèmes symboliques sans devenir une chose matérielle.

## Divergence / limites
Cassirer est anti-naïvement métaphysique : le symbolique ne prouve pas l'être en soi.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Substance et fonction*
- *Philosophie des formes symboliques*

## Scholars / études secondaires
- John Michael Krois
- Sebastian Luft

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

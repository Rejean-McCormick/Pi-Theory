---
name: "Bergson"
dates: "1859–1941"
domain: "philosophie du temps / évolution"
priority: "B"
status: "research-note"
---

# Bergson

## Position dans l'atlas
**Dates :** 1859–1941  
**Domaine :** philosophie du temps / évolution  
**Priorité :** B

## Concepts pertinents
- durée
- création
- élan vital
- critique de la spatialisation du temps

## Convergence exacte avec Pi Theory
Force Pi Theory à distinguer le devenir réel d'une simple représentation séquentielle déjà déterminée.

## Divergence / limites
Bergson est critique envers la réduction du devenir vivant au calcul ou à l'espace mathématique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Essai sur les données immédiates de la conscience*
- *L'Évolution créatrice*

## Scholars / études secondaires
- Frédéric Worms
- Keith Ansell-Pearson

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

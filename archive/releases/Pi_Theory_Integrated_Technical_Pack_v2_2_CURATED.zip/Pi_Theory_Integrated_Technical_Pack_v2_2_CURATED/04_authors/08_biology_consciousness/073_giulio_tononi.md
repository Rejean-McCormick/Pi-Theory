---
name: "Giulio Tononi"
dates: "1960–"
domain: "neurosciences / théorie de la conscience"
priority: "C"
status: "research-note"
---

# Giulio Tononi

## Position dans l'atlas
**Dates :** 1960–  
**Domaine :** neurosciences / théorie de la conscience  
**Priorité :** C

## Concepts pertinents
- Integrated Information Theory
- Φ
- intégration

## Convergence exacte avec Pi Theory
Pertinent au mot 'intégration' et à l'idée d'une mesure structurelle de conscience.

## Divergence / limites
IIT est très débattue; Φ de Tononi n'a aucun rapport avec le nombre d'or ni avec Pi Theory.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Articles IIT*
- *Phi: A Voyage from the Brain to the Soul*

## Scholars / études secondaires
- Scott Aaronson (critique)

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Charles Darwin"
dates: "1809–1882"
domain: "biologie évolutive"
priority: "A/B"
status: "research-note"
---

# Charles Darwin

## Position dans l'atlas
**Dates :** 1809–1882  
**Domaine :** biologie évolutive  
**Priorité :** A/B

## Concepts pertinents
- sélection naturelle
- descendance avec modification
- adaptation

## Convergence exacte avec Pi Theory
Garde-fou contre une lecture trop téléologique de la complexification : l'ordre biologique peut émerger sans plan final explicite.

## Divergence / limites
La sélection naturelle n'est ni principe de retour ni processus orienté vers le Bien.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *On the Origin of Species*

## Scholars / études secondaires
- Ernst Mayr
- Elliott Sober

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

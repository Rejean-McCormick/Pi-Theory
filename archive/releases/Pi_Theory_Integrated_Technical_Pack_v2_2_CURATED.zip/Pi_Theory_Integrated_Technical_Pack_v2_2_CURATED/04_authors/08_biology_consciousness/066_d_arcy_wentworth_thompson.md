---
name: "D'Arcy Wentworth Thompson"
dates: "1860–1948"
domain: "biologie mathématique / forme"
priority: "A/B"
status: "research-note"
---

# D'Arcy Wentworth Thompson

## Position dans l'atlas
**Dates :** 1860–1948  
**Domaine :** biologie mathématique / forme  
**Priorité :** A/B

## Concepts pertinents
- forme
- croissance
- transformation
- contraintes physiques

## Convergence exacte avec Pi Theory
Pont classique entre mathématiques, morphologie et formes vivantes.

## Divergence / limites
Les lois de forme ne remplacent pas évolution, génétique ou développement.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *On Growth and Form*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Sefer Yetzirah (tradition)"
dates: "Antiquité tardive / haut Moyen Âge"
domain: "mystique juive / cosmologie des lettres et nombres"
priority: "A"
status: "research-note"
---

# Sefer Yetzirah (tradition)

## Position dans l'atlas
**Dates :** Antiquité tardive / haut Moyen Âge  
**Domaine :** mystique juive / cosmologie des lettres et nombres  
**Priorité :** A

## Concepts pertinents
- lettres
- sefirot
- création combinatoire
- nombre et langage

## Convergence exacte avec Pi Theory
Source majeure pour l'idée que lettres, nombres et opérations combinatoires peuvent être pensés comme grammaire de création.

## Divergence / limites
Le texte n'enseigne pas Pi Theory ni A1Z26; toute comparaison doit rester structurelle.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Sefer Yetzirah, édition/traduction critique*

## Scholars / études secondaires
- Peter Hayman
- Aryeh Kaplan (utile mais moins académique)

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

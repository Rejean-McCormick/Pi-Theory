---
name: "Hayyim Vital"
dates: "1542–1620"
domain: "Kabbale lourianique / transmission"
priority: "A"
status: "research-note"
---

# Hayyim Vital

## Position dans l'atlas
**Dates :** 1542–1620  
**Domaine :** Kabbale lourianique / transmission  
**Priorité :** A

## Concepts pertinents
- systématisation de Louria
- Etz Hayyim
- mondes et configurations

## Convergence exacte avec Pi Theory
Conduit textuel indispensable si le livre utilise réellement Louria.

## Divergence / limites
Ne pas citer Louria comme si ses doctrines étaient conservées dans un traité autographe systématique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Etz Hayyim*
- *Sha'ar ha-Gilgulim*

## Scholars / études secondaires
- Lawrence Fine
- Ronit Meroz

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

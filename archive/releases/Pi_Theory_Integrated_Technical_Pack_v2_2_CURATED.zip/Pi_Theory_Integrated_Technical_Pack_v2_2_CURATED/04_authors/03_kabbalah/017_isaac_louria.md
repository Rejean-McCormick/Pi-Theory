---
name: "Isaac Louria"
dates: "1534–1572"
domain: "Kabbale lourianique"
priority: "A"
status: "research-note"
---

# Isaac Louria

## Position dans l'atlas
**Dates :** 1534–1572  
**Domaine :** Kabbale lourianique  
**Priorité :** A

## Concepts pertinents
- Ein-Sof
- tzimtzum
- shevirat ha-kelim
- tikkun
- émanation

## Convergence exacte avec Pi Theory
Comparaison indépendante puissante : infini → contraction → différenciation/brisure → réparation/réintégration.

## Divergence / limites
Le tikkun est aussi religieux, rituel et éthique; ce n'est pas un simple algorithme d'intégration.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Doctrine transmise principalement par Hayyim Vital*

## Scholars / études secondaires
- Lawrence Fine
- Gershom Scholem
- Moshe Idel

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

# Inventaire élargi — 100+ noms

1. **Pythagore et les Pythagoriciens** — dossier détaillé
2. **Empédocle** — dossier détaillé
3. **Platon** — dossier détaillé
4. **Plotin** — dossier détaillé
5. **Proclus** — dossier détaillé
6. **Pseudo-Denys l'Aréopagite** — dossier détaillé
7. **Jean Scot Érigène** — dossier détaillé
8. **Nicolas de Cues** — dossier détaillé
9. **Giordano Bruno** — dossier détaillé
10. **Jacob Böhme** — dossier détaillé
11. **Paracelse** — dossier détaillé
12. **Martinès de Pasqually** — dossier détaillé
13. **Louis-Claude de Saint-Martin** — dossier détaillé
14. **Papus (Gérard Encausse)** — dossier détaillé
15. **Constant Chevillon** — dossier détaillé
16. **Sefer Yetzirah (tradition)** — dossier détaillé
17. **Isaac Louria** — dossier détaillé
18. **Hayyim Vital** — dossier détaillé
19. **Leibniz** — dossier détaillé
20. **Spinoza** — dossier détaillé
21. **Schelling** — dossier détaillé
22. **Hegel** — dossier détaillé
23. **Bergson** — dossier détaillé
24. **Alfred North Whitehead** — dossier détaillé
25. **Pierre Teilhard de Chardin** — dossier détaillé
26. **Gilbert Simondon** — dossier détaillé
27. **George Spencer-Brown** — dossier détaillé
28. **Charles S. Peirce** — dossier détaillé
29. **Ernst Cassirer** — dossier détaillé
30. **Leonhard Euler** — dossier détaillé
31. **Georg Cantor** — dossier détaillé
32. **Bernhard Riemann** — dossier détaillé
33. **Hermann Weyl** — dossier détaillé
34. **Emmy Noether** — dossier détaillé
35. **Kurt Gödel** — dossier détaillé
36. **Alan Turing** — dossier détaillé
37. **Gregory Chaitin** — dossier détaillé
38. **Andrey Kolmogorov** — dossier détaillé
39. **Albert Einstein** — dossier détaillé
40. **Niels Bohr** — dossier détaillé
41. **Werner Heisenberg** — dossier détaillé
42. **Erwin Schrödinger** — dossier détaillé
43. **Wolfgang Pauli** — dossier détaillé
44. **John Archibald Wheeler** — dossier détaillé
45. **David Bohm** — dossier détaillé
46. **Basil Hiley** — dossier détaillé
47. **Roger Penrose** — dossier détaillé
48. **Max Tegmark** — dossier détaillé
49. **Carlo Rovelli** — dossier détaillé
50. **Lee Smolin** — dossier détaillé
51. **Julian Barbour** — dossier détaillé
52. **Claude Shannon** — dossier détaillé
53. **Rolf Landauer** — dossier détaillé
54. **Norbert Wiener** — dossier détaillé
55. **W. Ross Ashby** — dossier détaillé
56. **Heinz von Foerster** — dossier détaillé
57. **Ludwig von Bertalanffy** — dossier détaillé
58. **Gregory Bateson** — dossier détaillé
59. **Humberto Maturana** — dossier détaillé
60. **Francisco Varela** — dossier détaillé
61. **Ilya Prigogine** — dossier détaillé
62. **Stuart Kauffman** — dossier détaillé
63. **Terrence Deacon** — dossier détaillé
64. **Karl Friston** — dossier détaillé
65. **Charles Darwin** — dossier détaillé
66. **D'Arcy Wentworth Thompson** — dossier détaillé
67. **Conrad Waddington** — dossier détaillé
68. **René Thom** — dossier détaillé
69. **Brian Goodwin** — dossier détaillé
70. **William James** — dossier détaillé
71. **Carl Gustav Jung** — dossier détaillé
72. **Marie-Louise von Franz** — dossier détaillé
73. **Giulio Tononi** — dossier détaillé
74. **Evan Thompson** — dossier détaillé
75. **Bergson** — déjà couvert par le dossier Bergson
76. **Ian Barbour** — dossier détaillé
77. **John Polkinghorne** — dossier détaillé
78. **John F. Haught** — dossier détaillé
79. **Luciano Floridi** — dossier détaillé
80. **Niklas Luhmann** — dossier détaillé
81. **René Guénon** — dossier détaillé
82. **Lloyd P. Gerson** — scholar secondaire
83. **Dominic O'Meara** — scholar secondaire
84. **Carlos Steel** — scholar secondaire
85. **Andrew Louth** — scholar secondaire
86. **Paul Rorem** — scholar secondaire
87. **Dermot Moran** — scholar secondaire
88. **Deirdre Carabine** — scholar secondaire
89. **Jasper Hopkins** — scholar secondaire
90. **Andrew Weeks** — scholar secondaire
91. **Cyril O'Regan** — scholar secondaire
92. **Ariel Hessayon** — scholar secondaire
93. **Lawrence Fine** — scholar secondaire
94. **Moshe Idel** — scholar secondaire
95. **Gershom Scholem** — scholar secondaire
96. **Elliot R. Wolfson** — scholar secondaire
97. **Boaz Huss** — scholar secondaire
98. **Wouter J. Hanegraaff** — scholar secondaire
99. **Antoine Faivre** — scholar secondaire
100. **Isabelle Stengers** — scholar secondaire
101. **Muriel Combes** — scholar secondaire
102. **Jean-Hugues Barthélémy** — scholar secondaire
103. **Thomas Ryckman** — scholar secondaire
104. **Erhard Scholz** — scholar secondaire
105. **Yvette Kosmann-Schwarzbach** — scholar secondaire
106. **T. L. Short** — scholar secondaire
107. **Cheryl Misak** — scholar secondaire
108. **Ursula King** — scholar secondaire
109. **Sonu Shamdasani** — scholar secondaire
110. **Aristote** — extension à explorer

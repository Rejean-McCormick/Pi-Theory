---
name: "Ludwig von Bertalanffy"
dates: "1901–1972"
domain: "théorie générale des systèmes"
priority: "B"
status: "research-note"
---

# Ludwig von Bertalanffy

## Position dans l'atlas
**Dates :** 1901–1972  
**Domaine :** théorie générale des systèmes  
**Priorité :** B

## Concepts pertinents
- systèmes ouverts
- organisation
- isomorphismes

## Convergence exacte avec Pi Theory
Justifie méthodologiquement la recherche de structures communes entre domaines sans supposer identité matérielle.

## Divergence / limites
Les isomorphismes de systèmes doivent être démontrés, pas seulement ressentis.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *General System Theory*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

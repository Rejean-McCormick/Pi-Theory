---
name: "Ilya Prigogine"
dates: "1917–2003"
domain: "thermodynamique / systèmes hors équilibre"
priority: "A/B"
status: "research-note"
---

# Ilya Prigogine

## Position dans l'atlas
**Dates :** 1917–2003  
**Domaine :** thermodynamique / systèmes hors équilibre  
**Priorité :** A/B

## Concepts pertinents
- structures dissipatives
- irréversibilité
- bifurcation
- auto-organisation

## Convergence exacte avec Pi Theory
Complément physique majeur pour seuil, émergence de nouveaux régimes et ordre loin de l'équilibre.

## Divergence / limites
La thermodynamique hors équilibre ne fournit pas une téléologie spirituelle ni un code de π.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *From Being to Becoming*
- *Order Out of Chaos (avec Stengers)*

## Scholars / études secondaires
- Isabelle Stengers

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

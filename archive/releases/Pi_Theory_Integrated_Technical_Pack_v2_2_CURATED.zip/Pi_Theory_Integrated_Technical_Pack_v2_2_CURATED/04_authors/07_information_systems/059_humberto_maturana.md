---
name: "Humberto Maturana"
dates: "1928–2021"
domain: "biologie / cognition"
priority: "B"
status: "research-note"
---

# Humberto Maturana

## Position dans l'atlas
**Dates :** 1928–2021  
**Domaine :** biologie / cognition  
**Priorité :** B

## Concepts pertinents
- autopoïèse
- organisation
- cognition
- structural coupling

## Convergence exacte avec Pi Theory
Très pertinent pour passage matière organisée → vivant → cognition.

## Divergence / limites
Autopoïèse ne signifie pas auto-création cosmique et n'implique aucune finalité théologique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Autopoiesis and Cognition (avec Varela)*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

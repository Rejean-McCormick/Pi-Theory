---
name: "Norbert Wiener"
dates: "1894–1964"
domain: "cybernétique"
priority: "A/B"
status: "research-note"
---

# Norbert Wiener

## Position dans l'atlas
**Dates :** 1894–1964  
**Domaine :** cybernétique  
**Priorité :** A/B

## Concepts pertinents
- feedback
- contrôle
- communication
- entropie

## Convergence exacte avec Pi Theory
Fournit un langage technique de boucles, régulation et stabilité utile au kernel récursif.

## Divergence / limites
La cybernétique n'est pas une métaphysique de la Source.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Cybernetics*
- *The Human Use of Human Beings*

## Scholars / études secondaires
- P. R. Masani

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Heinz von Foerster"
dates: "1911–2002"
domain: "cybernétique de second ordre"
priority: "B"
status: "research-note"
---

# Heinz von Foerster

## Position dans l'atlas
**Dates :** 1911–2002  
**Domaine :** cybernétique de second ordre  
**Priorité :** B

## Concepts pertinents
- observateur
- récursion
- auto-référence
- constructivisme

## Convergence exacte avec Pi Theory
Pertinent pour la boucle conscience → lecture du principe et pour Rosetta/kOA.

## Divergence / limites
Le constructivisme radical peut au contraire relativiser les prétentions ontologiques.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Understanding Understanding*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

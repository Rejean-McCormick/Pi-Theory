---
name: "Claude Shannon"
dates: "1916–2001"
domain: "théorie de l'information"
priority: "A"
status: "research-note"
---

# Claude Shannon

## Position dans l'atlas
**Dates :** 1916–2001  
**Domaine :** théorie de l'information  
**Priorité :** A

## Concepts pertinents
- entropie
- canal
- codage
- information statistique

## Convergence exacte avec Pi Theory
Garde-fou absolument central : séparer quantité d'information, sens sémantique et portée ontologique.

## Divergence / limites
Shannon exclut volontairement le sens du problème formel de transmission.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *A Mathematical Theory of Communication*

## Scholars / études secondaires
- James Gleick (histoire, vulgarisation)

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

---
name: "Rolf Landauer"
dates: "1927–1999"
domain: "physique de l'information"
priority: "A"
status: "research-note"
---

# Rolf Landauer

## Position dans l'atlas
**Dates :** 1927–1999  
**Domaine :** physique de l'information  
**Priorité :** A

## Concepts pertinents
- information is physical
- effacement
- dissipation

## Convergence exacte avec Pi Theory
Crucial pour donner un sens scientifique minimal à 'information stockée dans la matière'.

## Divergence / limites
Information physique ≠ signification sémantique et n'implique pas une ontologie de π.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Information is Physical*
- *Irreversibility and Heat Generation in the Computing Process*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

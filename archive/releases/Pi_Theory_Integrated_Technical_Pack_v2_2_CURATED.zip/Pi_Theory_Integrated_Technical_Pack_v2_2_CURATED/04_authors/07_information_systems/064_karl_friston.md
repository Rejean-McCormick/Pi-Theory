---
name: "Karl Friston"
dates: "1959–"
domain: "neurosciences théoriques"
priority: "B/C"
status: "research-note"
---

# Karl Friston

## Position dans l'atlas
**Dates :** 1959–  
**Domaine :** neurosciences théoriques  
**Priorité :** B/C

## Concepts pertinents
- free energy principle
- active inference
- self-organization

## Convergence exacte avec Pi Theory
Peut fournir un cadre mathématique contemporain de maintien de frontières, prédiction et organisation du vivant.

## Divergence / limites
Le FEP est technique et débattu dans son extension universelle; ne pas en faire une métaphysique automatique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Articles sur Free Energy Principle et Active Inference*

## Scholars / études secondaires
- Jakob Hohwy
- Andy Clark (discussions connexes)

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

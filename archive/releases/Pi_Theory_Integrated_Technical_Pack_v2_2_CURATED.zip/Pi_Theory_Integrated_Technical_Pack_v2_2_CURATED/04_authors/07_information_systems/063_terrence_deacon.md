---
name: "Terrence Deacon"
dates: "1950–"
domain: "anthropologie biologique / sémiotique"
priority: "A/B"
status: "research-note"
---

# Terrence Deacon

## Position dans l'atlas
**Dates :** 1950–  
**Domaine :** anthropologie biologique / sémiotique  
**Priorité :** A/B

## Concepts pertinents
- absence
- contrainte
- téléodynamique
- émergence du sens

## Convergence exacte avec Pi Theory
Très pertinent pour le passage information physique → signification → vie → esprit sans introduire le sens comme magie.

## Divergence / limites
Cadre naturaliste et non théologique; aucun rôle spécial de π.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Incomplete Nature*
- *The Symbolic Species*

## Scholars / études secondaires
- À compléter.

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

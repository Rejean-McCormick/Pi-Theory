# Top 25 — noyau du futur livre

1. **Proclus**
2. **Jacob Böhme**
3. **Nicolas de Cues**
4. **Gilbert Simondon**
5. **Hermann Weyl**
6. **Charles S. Peirce**
7. **Pierre Teilhard de Chardin**
8. **Alfred North Whitehead**
9. **Claude Shannon**
10. **Rolf Landauer**
11. **Alan Turing**
12. **Hegel**
13. **Plotin**
14. **Jean Scot Érigène**
15. **Isaac Louria**
16. **George Spencer-Brown**
17. **Emmy Noether**
18. **Albert Einstein**
19. **David Bohm**
20. **John Archibald Wheeler**
21. **Empédocle**
22. **Schelling**
23. **Francisco Varela**
24. **Terrence Deacon**
25. **Eugene P. Wigner**

## Logique de cette sélection
Ce Top 25 n'est pas un classement de « proximité spirituelle ». Il couvre les problèmes nécessaires au livre :

- Source / procession / retour;
- première différence;
- mesure;
- invariance;
- processus;
- information;
- matière;
- vivant;
- conscience;
- science–religion;
- méthode.

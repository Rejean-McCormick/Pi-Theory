---
name: "Georg Cantor"
dates: "1845–1918"
domain: "théorie des ensembles / infini"
priority: "A"
status: "research-note"
---

# Georg Cantor

## Position dans l'atlas
**Dates :** 1845–1918  
**Domaine :** théorie des ensembles / infini  
**Priorité :** A

## Concepts pertinents
- infini actuel
- cardinaux transfinis
- diagonalisation
- hiérarchie des infinis

## Convergence exacte avec Pi Theory
Garde-fou indispensable : 'infini' n'est pas un concept unique; les deux infinis de 88 doivent être définis avant toute formalisation.

## Divergence / limites
L'infini cantorien n'a aucun lien intrinsèque avec le symbole 8.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Contributions à la fondation de la théorie des ensembles transfinis*

## Scholars / études secondaires
- Joseph Dauben

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

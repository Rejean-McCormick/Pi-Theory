---
name: "Bernhard Riemann"
dates: "1826–1866"
domain: "géométrie / analyse"
priority: "A"
status: "research-note"
---

# Bernhard Riemann

## Position dans l'atlas
**Dates :** 1826–1866  
**Domaine :** géométrie / analyse  
**Priorité :** A

## Concepts pertinents
- variétés
- métrique
- géométrie intrinsèque
- courbure

## Convergence exacte avec Pi Theory
Essentiel pour corriger SIZE → space : une multiplicité ou une grandeur possible ne suffit pas à déterminer une métrique.

## Divergence / limites
La géométrie riemannienne n'est pas dérivée de symbolique numérique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Über die Hypothesen, welche der Geometrie zu Grunde liegen*

## Scholars / études secondaires
- John Stachel
- historiens de la géométrie

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

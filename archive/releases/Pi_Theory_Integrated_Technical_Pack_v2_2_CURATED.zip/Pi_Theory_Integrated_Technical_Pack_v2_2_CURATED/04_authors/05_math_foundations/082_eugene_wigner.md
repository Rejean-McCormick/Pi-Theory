---
name: "Eugene P. Wigner"
dates: "1902–1995"
domain: "physique mathématique / philosophie des sciences"
priority: "A/B"
---

# Eugene P. Wigner

## Concepts
- efficacité des mathématiques;
- symétrie;
- représentation des groupes en physique.

## Convergence
Wigner formule directement la question générale que Pi Theory radicalise : pourquoi des structures mathématiques abstraites décrivent-elles si efficacement le monde physique ?

## Divergence
« Unreasonable effectiveness » est une énigme philosophique, pas un argument que la réalité est π.

## À lire
- “The Unreasonable Effectiveness of Mathematics in the Natural Sciences” (1960).

---
name: "Hermann Weyl"
dates: "1885–1955"
domain: "mathématiques / physique / philosophie"
priority: "A"
status: "research-note"
---

# Hermann Weyl

## Position dans l'atlas
**Dates :** 1885–1955  
**Domaine :** mathématiques / physique / philosophie  
**Priorité :** A

## Concepts pertinents
- symétrie
- invariance
- jauge
- continu
- espace
- mesure

## Convergence exacte avec Pi Theory
Auteur technique central pour Scale → comparaison locale → mesure → géométrie → physique.

## Divergence / limites
Weyl ne soutient pas une ontologie privilégiant π comme code cosmique.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Symmetry*
- *Space-Time-Matter*
- *Philosophy of Mathematics and Natural Science*

## Scholars / études secondaires
- Thomas Ryckman
- Erhard Scholz

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

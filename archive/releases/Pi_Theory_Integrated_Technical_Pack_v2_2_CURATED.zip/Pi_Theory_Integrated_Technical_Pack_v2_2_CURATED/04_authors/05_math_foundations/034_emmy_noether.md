---
name: "Emmy Noether"
dates: "1882–1935"
domain: "mathématiques / physique théorique"
priority: "A"
status: "research-note"
---

# Emmy Noether

## Position dans l'atlas
**Dates :** 1882–1935  
**Domaine :** mathématiques / physique théorique  
**Priorité :** A

## Concepts pertinents
- symétrie
- invariants
- lois de conservation

## Convergence exacte avec Pi Theory
Donne un sens technique puissant à l'idée que ce qui demeure sous transformation peut structurer la physique.

## Divergence / limites
Le théorème de Noether concerne des symétries continues de l'action, pas 'l'harmonie cosmique' au sens vague.

## Usage recommandé dans le futur livre
- Ne jamais utiliser cet auteur comme « preuve par autorité ».
- Identifier si la relation est une **influence historique**, une **convergence indépendante**, un **analogue formel**, un **contrepoint critique** ou un **complément technique**.
- Citer le texte primaire avant les commentaires modernes lorsque l'argument dépend de la doctrine de l'auteur.

## Œuvres primaires à lire
- *Invariante Variationsprobleme (1918)*

## Scholars / études secondaires
- Yvette Kosmann-Schwarzbach

## Questions de travail
1. Quel opérateur du kernel (`cohésion`, `différenciation`, `intégration`, `seuil`, `échelle`, `retour`) est réellement présent chez cet auteur ?
2. S'agit-il d'une relation causale, logique, symbolique, temporelle ou théologique ?
3. Quels éléments de Pi Theory cet auteur **contredit-il** ?
4. Peut-on produire une comparaison qui reste valide après suppression du vocabulaire religieux ou symbolique ?

## Niveau épistémique
La présence d'une analogie avec Pi Theory relève par défaut de **E3 — convergence comparative**, sauf indication contraire.

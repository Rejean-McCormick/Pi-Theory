---
name: "Johannes Kepler"
dates: "1571–1630"
domain: "astronomie / mathématiques / harmonie cosmique"
priority: "B"
---

# Johannes Kepler

## Concepts
- harmonie du monde;
- géométrie;
- rapports;
- lois planétaires.

## Convergence
Kepler représente un moment historique majeur où conviction théologico-mathématique et recherche quantitative du cosmos sont intimement liées.

## Importance méthodologique
Son histoire est aussi un garde-fou : certaines constructions harmonico-géométriques furent abandonnées tandis que ses lois quantitatives survécurent.

## À lire
- *Harmonices Mundi*.
- *Astronomia Nova*.

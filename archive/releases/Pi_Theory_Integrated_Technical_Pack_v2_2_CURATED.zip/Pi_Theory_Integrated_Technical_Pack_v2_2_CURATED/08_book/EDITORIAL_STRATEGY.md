# Stratégie éditoriale

## Ton
Ni apologétique, ni dismissif.

## Règles
- Dire explicitement « hypothèse » lorsqu'il s'agit d'une hypothèse.
- Ne jamais utiliser une citation célèbre comme preuve.
- Mettre les analogies New Age ou populaires en note ou annexe, si elles sont conservées.
- Préférer les concepts techniques aux mots vagues : `invariance`, `métrique`, `transduction`, `feedback`, `information`.
- Distinguer tradition primaire et scholar secondaire.

## Équilibre
Le livre peut être audacieux **à condition d'être précis sur le statut de chaque audace**.

# Colonne vertébrale du futur livre

## Le livre devrait démontrer/établir son intérêt dans cet ordre

### 1. π
Ce que π est mathématiquement, et ce que ses digits ne sont pas.

### 2. Le phénomène de décodage
Montrer exactement la fenêtre, les règles, les six blocs et l'histoire v12→v13.

### 3. Le kernel
Abstraire les personnages et mots vers les fonctions :
`C → V → D → A → T → S`.

### 4. Le problème le plus original
`88 / SIZE` et la question :
**comment un domaine de magnitude/mesure apparaît-il ?**

### 5. Intemporel et devenir
`π exact → représentation → hypothèse de manifestation`.

### 6. Processus et matière
Simondon / Whitehead / information / mémoire de processus.

### 7. Vie et conscience
Darwin → morphogenèse → Varela/Deacon → Teilhard comme lecture métaphysique.

### 8. Traditions métaphysiques
Seulement après que le modèle est clair :
Plotin, Proclus, Cues, Böhme, Louria, Érigène.

### 9. Sémiotique
Peirce et la question : pourquoi les mots devraient-ils porter une information sur une structure mathématique ?

### 10. Test
Nulls, préenregistrement, Rosetta prédictif, falsification.

### 11. La grande hypothèse
Seulement à la fin :
> le cosmos comme résolution/manifestation d'une structure dont π serait une expression privilégiée.

## À éviter
Ne pas faire un livre qui passe sans cesse :
Pythagore → Kabbale → Einstein → Jung → strings → Christ → π.

Cela dilue l'idée originale.

Les auteurs doivent intervenir **par problème**, pas comme accumulation de convergences.

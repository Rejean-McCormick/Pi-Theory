# Architecture du futur livre — v2 optimisée

## Partie I — Le problème
1. Pourquoi π ?
2. π exact, digits et base
3. Ce que le décodage trouve réellement
4. Ce qu'il ne prouve pas

## Partie II — Le kernel
5. Cohésion
6. Orientation / Bien
7. Différenciation
8. Intégration
9. Seuil / B0UM
10. 88 / SIZE

## Partie III — De SIZE à un monde mesurable
11. Infini et limite — Cues / Cantor
12. Distinction — Spencer-Brown
13. Quantité et mesure — Hegel
14. Multiplicité et métrique — Riemann
15. Symétrie / invariance — Weyl / Noether
16. Espace-temps — Einstein

## Partie IV — Structure, processus et matière
17. Whitehead
18. Simondon
19. Prigogine
20. Shannon / information
21. Turing / calcul
22. Landauer / physicalité
23. Wheeler / Bohm
24. Matière comme mémoire

## Partie V — Vie et conscience
25. Darwin et la contrainte anti-téléologique
26. Morphogenèse
27. Autopoïèse / enaction
28. Deacon et l'émergence du sens
29. Teilhard : complexification et noosphère
30. Conscience réflexive

## Partie VI — Grandes métaphysiques comparées
31. Plotin / Proclus
32. Denys / Érigène
33. Cues
34. Böhme
35. Louria / Vital
36. Saint-Martin / Chevillon

## Partie VII — Signe, langage et Rosetta
37. Peirce et la chaîne digit→sens
38. Coût interprétatif
39. Sephiroth / kOA
40. Rosetta prédictif

## Partie VIII — Épreuve de la théorie
41. Null models
42. Préenregistrement
43. Ce qui falsifierait Pi Theory
44. Thèse métaphysique forte
45. Programme scientifique futur

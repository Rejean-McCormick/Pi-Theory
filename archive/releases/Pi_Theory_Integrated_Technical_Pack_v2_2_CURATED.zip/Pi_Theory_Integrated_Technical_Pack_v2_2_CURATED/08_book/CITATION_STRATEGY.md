# Stratégie de citations

## Ordre de préférence
1. publication primaire scientifique;
2. texte primaire philosophique/théologique;
3. édition critique;
4. scholar reconnu;
5. encyclopédie académique;
6. vulgarisation uniquement pour contexte.

## Interdits
- Reddit pour une thèse académique;
- citations attribuées sans source;
- paraphrases de textes mystiques via sites occultistes;
- Wikipédia comme source finale lorsque le primaire est accessible.

## Pour les auteurs spirituels
Toujours séparer :
- texte source;
- contexte historique;
- interprétation moderne;
- rapprochement Pi Theory.

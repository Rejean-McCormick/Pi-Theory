---
name: "Dominic O'Meara"
domain: "néoplatonisme, Plotin, Proclus"
priority: "A"
type: "secondary-scholar"
---

# Dominic O'Meara

## Domaine
néoplatonisme, Plotin, Proclus

## Pourquoi cette personne est utile
Excellent pour procession, hiérarchie, politique et structure néoplatonicienne.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

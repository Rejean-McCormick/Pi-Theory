---
name: "Thomas Ryckman"
domain: "Weyl, relativité, philosophie de la physique"
priority: "A"
type: "secondary-scholar"
---

# Thomas Ryckman

## Domaine
Weyl, relativité, philosophie de la physique

## Pourquoi cette personne est utile
Très pertinent pour espace-temps, géométrie et philosophie de la relativité.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

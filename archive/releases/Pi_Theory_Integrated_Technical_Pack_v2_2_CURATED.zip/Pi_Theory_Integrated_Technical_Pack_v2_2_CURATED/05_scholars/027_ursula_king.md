---
name: "Ursula King"
domain: "Teilhard de Chardin"
priority: "A"
type: "secondary-scholar"
---

# Ursula King

## Domaine
Teilhard de Chardin

## Pourquoi cette personne est utile
Spécialiste majeure de Teilhard, spiritualité et évolution.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

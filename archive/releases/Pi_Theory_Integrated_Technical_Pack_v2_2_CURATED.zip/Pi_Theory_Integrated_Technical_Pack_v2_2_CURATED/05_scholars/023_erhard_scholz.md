---
name: "Erhard Scholz"
domain: "Weyl, histoire des mathématiques et jauge"
priority: "A"
type: "secondary-scholar"
---

# Erhard Scholz

## Domaine
Weyl, histoire des mathématiques et jauge

## Pourquoi cette personne est utile
Travaux détaillés sur Weyl, géométrie, gauge et contexte historique.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

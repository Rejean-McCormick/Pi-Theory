---
name: "Gershom Scholem"
domain: "histoire de la Kabbale"
priority: "A"
type: "secondary-scholar"
---

# Gershom Scholem

## Domaine
histoire de la Kabbale

## Pourquoi cette personne est utile
Fondateur moderne du champ, incontournable mais à lire aussi avec ses critiques.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

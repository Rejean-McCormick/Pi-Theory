---
name: "Paul Rorem"
domain: "Pseudo-Denys"
priority: "A"
type: "secondary-scholar"
---

# Paul Rorem

## Domaine
Pseudo-Denys

## Pourquoi cette personne est utile
Commentaire savant de référence sur corpus dionysien.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

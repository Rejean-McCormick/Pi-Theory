---
name: "Elliot R. Wolfson"
domain: "Kabbale, symbolisme, langage"
priority: "A"
type: "secondary-scholar"
---

# Elliot R. Wolfson

## Domaine
Kabbale, symbolisme, langage

## Pourquoi cette personne est utile
Très utile pour érotisme, langage, imagination et structures symboliques kabbalistiques.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

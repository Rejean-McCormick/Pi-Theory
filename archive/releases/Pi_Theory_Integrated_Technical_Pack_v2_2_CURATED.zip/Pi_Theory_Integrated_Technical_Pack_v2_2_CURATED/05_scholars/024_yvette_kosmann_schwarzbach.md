---
name: "Yvette Kosmann-Schwarzbach"
domain: "Noether"
priority: "A"
type: "secondary-scholar"
---

# Yvette Kosmann-Schwarzbach

## Domaine
Noether

## Pourquoi cette personne est utile
Référence de premier plan sur les théorèmes de Noether et leur histoire.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

---
name: "Jean-Hugues Barthélémy"
domain: "Simondon"
priority: "A"
type: "secondary-scholar"
---

# Jean-Hugues Barthélémy

## Domaine
Simondon

## Pourquoi cette personne est utile
Spécialiste de l'individuation et de l'encyclopédisme simondonien.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

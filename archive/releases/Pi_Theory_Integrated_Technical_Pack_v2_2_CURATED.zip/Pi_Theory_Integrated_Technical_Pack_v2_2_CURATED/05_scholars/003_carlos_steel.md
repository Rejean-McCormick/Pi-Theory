---
name: "Carlos Steel"
domain: "Proclus, philosophie médiévale"
priority: "A"
type: "secondary-scholar"
---

# Carlos Steel

## Domaine
Proclus, philosophie médiévale

## Pourquoi cette personne est utile
Éditions et études de haut niveau sur Proclus; essentiel pour la précision doctrinale.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

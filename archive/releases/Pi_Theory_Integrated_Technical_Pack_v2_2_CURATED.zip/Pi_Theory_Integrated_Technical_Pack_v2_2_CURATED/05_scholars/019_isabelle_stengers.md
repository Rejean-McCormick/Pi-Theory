---
name: "Isabelle Stengers"
domain: "Whitehead, Prigogine, philosophie des sciences"
priority: "A"
type: "secondary-scholar"
---

# Isabelle Stengers

## Domaine
Whitehead, Prigogine, philosophie des sciences

## Pourquoi cette personne est utile
Relie process philosophy, sciences hors équilibre et critique des simplifications scientifiques.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

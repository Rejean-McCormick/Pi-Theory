---
name: "John F. Haught"
domain: "Teilhard / science et religion"
priority: "A/B"
type: "secondary-scholar"
---

# John F. Haught

## Domaine
Teilhard / science et religion

## Pourquoi cette personne est utile
Interprète contemporain du devenir cosmique et de l'évolution théologique.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

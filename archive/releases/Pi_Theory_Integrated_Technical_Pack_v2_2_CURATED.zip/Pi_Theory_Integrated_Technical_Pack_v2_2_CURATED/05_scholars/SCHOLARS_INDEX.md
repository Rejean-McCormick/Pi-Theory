# Index scholars

| Scholar | Domaine | Priorité | Fiche |
|---|---|---|---|
| Lloyd P. Gerson | Plotin, platonisme ancien | A | [001_lloyd_p_gerson.md](001_lloyd_p_gerson.md) |
| Dominic O'Meara | néoplatonisme, Plotin, Proclus | A | [002_dominic_o_meara.md](002_dominic_o_meara.md) |
| Carlos Steel | Proclus, philosophie médiévale | A | [003_carlos_steel.md](003_carlos_steel.md) |
| Andrew Louth | Pseudo-Denys, mystique chrétienne | A | [004_andrew_louth.md](004_andrew_louth.md) |
| Paul Rorem | Pseudo-Denys | A | [005_paul_rorem.md](005_paul_rorem.md) |
| Dermot Moran | Jean Scot Érigène, phénoménologie | A | [006_dermot_moran.md](006_dermot_moran.md) |
| Deirdre Carabine | Érigène, théologie négative | B | [007_deirdre_carabine.md](007_deirdre_carabine.md) |
| Jasper Hopkins | Nicolas de Cues | A | [008_jasper_hopkins.md](008_jasper_hopkins.md) |
| Andrew Weeks | Jacob Böhme | A | [009_andrew_weeks.md](009_andrew_weeks.md) |
| Cyril O'Regan | Böhme, idéalisme allemand, théologie | A | [010_cyril_o_regan.md](010_cyril_o_regan.md) |
| Ariel Hessayon | Böhme et réception | B | [011_ariel_hessayon.md](011_ariel_hessayon.md) |
| Lawrence Fine | Isaac Louria, Kabbale | A | [012_lawrence_fine.md](012_lawrence_fine.md) |
| Moshe Idel | Kabbale et mystique juive | A | [013_moshe_idel.md](013_moshe_idel.md) |
| Gershom Scholem | histoire de la Kabbale | A | [014_gershom_scholem.md](014_gershom_scholem.md) |
| Elliot R. Wolfson | Kabbale, symbolisme, langage | A | [015_elliot_r_wolfson.md](015_elliot_r_wolfson.md) |
| Boaz Huss | Kabbale moderne / études critiques | B | [016_boaz_huss.md](016_boaz_huss.md) |
| Wouter J. Hanegraaff | ésotérisme occidental | A | [017_wouter_j_hanegraaff.md](017_wouter_j_hanegraaff.md) |
| Antoine Faivre | ésotérisme occidental | A/B | [018_antoine_faivre.md](018_antoine_faivre.md) |
| Isabelle Stengers | Whitehead, Prigogine, philosophie des sciences | A | [019_isabelle_stengers.md](019_isabelle_stengers.md) |
| Muriel Combes | Simondon | A | [020_muriel_combes.md](020_muriel_combes.md) |
| Jean-Hugues Barthélémy | Simondon | A | [021_jean_hugues_barthelemy.md](021_jean_hugues_barthelemy.md) |
| Thomas Ryckman | Weyl, relativité, philosophie de la physique | A | [022_thomas_ryckman.md](022_thomas_ryckman.md) |
| Erhard Scholz | Weyl, histoire des mathématiques et jauge | A | [023_erhard_scholz.md](023_erhard_scholz.md) |
| Yvette Kosmann-Schwarzbach | Noether | A | [024_yvette_kosmann_schwarzbach.md](024_yvette_kosmann_schwarzbach.md) |
| T. L. Short | Peirce | A | [025_t_l_short.md](025_t_l_short.md) |
| Cheryl Misak | Peirce, pragmatisme | B | [026_cheryl_misak.md](026_cheryl_misak.md) |
| Ursula King | Teilhard de Chardin | A | [027_ursula_king.md](027_ursula_king.md) |
| John F. Haught | Teilhard / science et religion | A/B | [028_john_f_haught.md](028_john_f_haught.md) |
| Evan Thompson | Varela, enaction, esprit et vie | A | [029_evan_thompson.md](029_evan_thompson.md) |
| Sonu Shamdasani | Jung, histoire de la psychologie | A/B | [030_sonu_shamdasani.md](030_sonu_shamdasani.md) |

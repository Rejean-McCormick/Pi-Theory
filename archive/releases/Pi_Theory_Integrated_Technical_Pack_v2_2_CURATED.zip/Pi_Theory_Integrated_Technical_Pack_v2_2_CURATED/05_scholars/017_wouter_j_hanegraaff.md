---
name: "Wouter J. Hanegraaff"
domain: "ésotérisme occidental"
priority: "A"
type: "secondary-scholar"
---

# Wouter J. Hanegraaff

## Domaine
ésotérisme occidental

## Pourquoi cette personne est utile
Référence académique majeure pour situer martinisme, occultisme et ésotérisme sans vocabulaire New Age vague.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

---
name: "Cyril O'Regan"
domain: "Böhme, idéalisme allemand, théologie"
priority: "A"
type: "secondary-scholar"
---

# Cyril O'Regan

## Domaine
Böhme, idéalisme allemand, théologie

## Pourquoi cette personne est utile
Très utile pour tracer Böhme → Schelling/Hegel et éviter les pseudo-filiations.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

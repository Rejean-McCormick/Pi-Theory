---
name: "Cheryl Misak"
domain: "Peirce, pragmatisme"
priority: "B"
type: "secondary-scholar"
---

# Cheryl Misak

## Domaine
Peirce, pragmatisme

## Pourquoi cette personne est utile
Très utile pour pragmatisme, vérité et méthode.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

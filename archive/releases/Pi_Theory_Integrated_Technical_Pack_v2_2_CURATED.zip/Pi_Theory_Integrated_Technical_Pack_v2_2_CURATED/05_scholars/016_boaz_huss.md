---
name: "Boaz Huss"
domain: "Kabbale moderne / études critiques"
priority: "B"
type: "secondary-scholar"
---

# Boaz Huss

## Domaine
Kabbale moderne / études critiques

## Pourquoi cette personne est utile
Important pour les usages modernes et la construction du champ 'Kabbalah'.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

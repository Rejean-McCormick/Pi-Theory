---
name: "T. L. Short"
domain: "Peirce"
priority: "A"
type: "secondary-scholar"
---

# T. L. Short

## Domaine
Peirce

## Pourquoi cette personne est utile
Référence sur la théorie peircienne des signes et la téléologie.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

---
name: "Lloyd P. Gerson"
domain: "Plotin, platonisme ancien"
priority: "A"
type: "secondary-scholar"
---

# Lloyd P. Gerson

## Domaine
Plotin, platonisme ancien

## Pourquoi cette personne est utile
Référence contemporaine majeure pour Plotin et le platonisme; utile pour éviter les simplifications ésotériques.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

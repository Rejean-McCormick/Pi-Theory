---
name: "Andrew Weeks"
domain: "Jacob Böhme"
priority: "A"
type: "secondary-scholar"
---

# Andrew Weeks

## Domaine
Jacob Böhme

## Pourquoi cette personne est utile
Spécialiste majeur de Böhme, contexte, terminologie et traductions.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

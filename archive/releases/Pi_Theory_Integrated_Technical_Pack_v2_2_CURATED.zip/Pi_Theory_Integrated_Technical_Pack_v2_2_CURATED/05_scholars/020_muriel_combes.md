---
name: "Muriel Combes"
domain: "Simondon"
priority: "A"
type: "secondary-scholar"
---

# Muriel Combes

## Domaine
Simondon

## Pourquoi cette personne est utile
Introduction philosophique importante à Simondon et à l'individuation.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

---
name: "Evan Thompson"
domain: "Varela, enaction, esprit et vie"
priority: "A"
type: "secondary-scholar"
---

# Evan Thompson

## Domaine
Varela, enaction, esprit et vie

## Pourquoi cette personne est utile
Pont contemporain rigoureux entre sciences cognitives et phénoménologie.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

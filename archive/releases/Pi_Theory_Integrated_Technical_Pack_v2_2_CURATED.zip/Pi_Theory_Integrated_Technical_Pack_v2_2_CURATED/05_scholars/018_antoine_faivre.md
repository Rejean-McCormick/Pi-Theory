---
name: "Antoine Faivre"
domain: "ésotérisme occidental"
priority: "A/B"
type: "secondary-scholar"
---

# Antoine Faivre

## Domaine
ésotérisme occidental

## Pourquoi cette personne est utile
Cadre historique classique de l'ésotérisme occidental; utile pour Chevillon, Saint-Martin et correspondances.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

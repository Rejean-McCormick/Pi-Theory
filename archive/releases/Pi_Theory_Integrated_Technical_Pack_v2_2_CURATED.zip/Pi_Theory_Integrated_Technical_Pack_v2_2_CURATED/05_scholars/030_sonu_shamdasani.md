---
name: "Sonu Shamdasani"
domain: "Jung, histoire de la psychologie"
priority: "A/B"
type: "secondary-scholar"
---

# Sonu Shamdasani

## Domaine
Jung, histoire de la psychologie

## Pourquoi cette personne est utile
Indispensable pour utiliser Jung historiquement plutôt que mythologiquement.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

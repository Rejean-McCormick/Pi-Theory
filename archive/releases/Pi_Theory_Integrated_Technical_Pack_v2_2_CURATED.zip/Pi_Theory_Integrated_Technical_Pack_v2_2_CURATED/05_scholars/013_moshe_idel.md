---
name: "Moshe Idel"
domain: "Kabbale et mystique juive"
priority: "A"
type: "secondary-scholar"
---

# Moshe Idel

## Domaine
Kabbale et mystique juive

## Pourquoi cette personne est utile
Contrepoids à Scholem; pluralise l'histoire de la Kabbale.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

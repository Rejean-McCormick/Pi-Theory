---
name: "Dermot Moran"
domain: "Jean Scot Érigène, phénoménologie"
priority: "A"
type: "secondary-scholar"
---

# Dermot Moran

## Domaine
Jean Scot Érigène, phénoménologie

## Pourquoi cette personne est utile
Référence majeure sur Eriugena et la notion de nature/théophanie.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

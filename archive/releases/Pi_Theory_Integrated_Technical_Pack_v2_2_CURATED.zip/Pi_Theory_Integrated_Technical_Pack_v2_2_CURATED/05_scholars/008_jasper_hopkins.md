---
name: "Jasper Hopkins"
domain: "Nicolas de Cues"
priority: "A"
type: "secondary-scholar"
---

# Jasper Hopkins

## Domaine
Nicolas de Cues

## Pourquoi cette personne est utile
Traducteur/commentateur central pour Cusa.

## Fonction dans le projet
- Vérifier la reconstruction historique des auteurs primaires.
- Distinguer doctrine attestée, réception ultérieure et réinterprétation moderne.
- Identifier les éditions, traductions et débats académiques les plus fiables.

## Règle d'usage
Un scholar n'est pas cité pour « confirmer Pi Theory », mais pour établir ce qu'un auteur historique a effectivement soutenu et pour éviter les filiations inventées.

# Archive des analogies physiques retirées du noyau

Ces éléments existaient dans les documents antérieurs et ne doivent pas être perdus, mais ils ne font pas partie du noyau scientifique.

## String / M-theory / branes
Analogie : niveau fondamental invisible → monde observable.

## Holographie
Analogie : information d'un domaine représentée dans une structure de dimension inférieure.

## E8 / twistors
Analogie : objets mathématiques abstraits comme structures organisatrices de la physique.

## Symmetry breaking
Analogie : unité → différenciation → complexité.

## Gravité comme « love »
Analogie poétique uniquement — à ne pas utiliser scientifiquement.

## Statut
**Archive heuristique / E3 faible**, jamais validation.

## Pourquoi conserver
Le v2 avait correctement retiré ces rapprochements du noyau, mais l'optimisation documentaire doit distinguer **déclassement** et **effacement**.

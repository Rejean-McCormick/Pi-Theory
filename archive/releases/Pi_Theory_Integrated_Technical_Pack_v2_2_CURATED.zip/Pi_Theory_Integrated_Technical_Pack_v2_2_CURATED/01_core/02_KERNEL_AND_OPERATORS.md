# Kernel et opérateurs

## Forme token
`M → BIEN → GIHECEF → JNON → B0UM → SIZE`

## Forme fonctionnelle
`C → V → D → A → T → S`

où :

- `C` = cohésion;
- `V` = orientation / valeur;
- `D` = différenciation / traitement;
- `A` = assemblage / intégration;
- `T` = franchissement de seuil;
- `S` = nouveau régime d'échelle.

## Modèle d'état

```text
S0 : potentiel non structuré / sous-déterminé
S1 = cohere(S0)
S2 = orient(S1)
S3 = differentiate(S2)
S4 = integrate(S3)
S5 = threshold(S4)
S6 = scale(S5)
```

## Correction de langage
`S0` n'est pas automatiquement « le néant ».

Un potentiel sous-déterminé, un vide physique, un néant théologique et un état mathématique vide sont des concepts distincts.

## Hypothèse fractale
Le kernel peut être réappliqué :

`K0 → K1 → K2 → ...`

où chaque sortie de scale devient le domaine d'un nouveau cycle de différenciation/intégration.

### Ce qui doit être testé
- le motif est-il assez spécifique pour produire des prédictions ?
- apparaît-il dans des systèmes indépendants sans réécriture ad hoc ?
- une formalisation minimale peut-elle définir ses opérateurs ?

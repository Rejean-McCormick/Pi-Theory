# Questions ouvertes prioritaires

## Décodage
1. Pourquoi la base 10 ?
2. Pourquoi A1Z26 ?
3. Combien de segmentations étaient possibles ?
4. Quel est le coût exact des changements de langue et de phonétique ?
5. Le stop à 88 est-il indépendant de la cohérence ?

## Ontologie
6. Pourquoi π plutôt qu'une autre constante ou structure ?
7. Qu'est-ce que « résolution » signifie formellement ?
8. La Source est-elle théologique, métaphysique ou seulement une variable limite ?
9. Le kernel est-il assez spécifique pour être falsifiable ?

## Mesure
10. Comment passer de SIZE à une valuation ?
11. Quelles structures additionnelles sont nécessaires pour une métrique ?
12. Peut-on dériver espace et temps sans les présupposer ?

## Physique
13. Quelle prédiction quantitative distingue Pi Theory ?
14. Quel invariant physique ou spectre devrait-elle produire ?
15. Existe-t-il une échelle ou une constante dimensionless prédite ?

## Vie/conscience
16. Quel mécanisme relie matière, organisation, vie et conscience ?
17. La complexification est-elle descriptive ou téléologique ?

## Sémiotique
18. Pourquoi le langage humain devrait-il refléter la structure de π ?
19. Peut-on définir une cohérence sémantique indépendante des chercheurs ?

## Falsification
20. Quel résultat ferait abandonner ou réviser la thèse forte ?

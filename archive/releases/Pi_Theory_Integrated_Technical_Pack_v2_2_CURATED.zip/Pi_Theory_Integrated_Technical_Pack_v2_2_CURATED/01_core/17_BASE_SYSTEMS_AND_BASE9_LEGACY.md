# Systèmes de base et branche base-9

## Statut
Le rôle de la **base-9** apparaît dans des versions/explorations antérieures de Pi Theory et dans les commentaires approfondis, mais il n'est pas le centre de la formulation canonique v13.

Le v2 l'avait pratiquement effacé.

## Pourquoi il faut le conserver
La question des bases est fondamentale, car les digits de π dépendent de la représentation.

Une théorie qui attribue un sens aux digits doit répondre :
> pourquoi la base 10, 9, 12 ou une autre base devrait-elle avoir un statut privilégié ?

## Branche historique
Des textes antérieurs associent base-9 / groupements par trois à des motifs symboliques de création/transformation/destruction.

## Statut v2.1
**Branche expérimentale héritée — non canonique.**

## Programme sérieux
Tester :
- π en base 2, 3, 8, 9, 10, 12, 16;
- mêmes métriques de cohérence;
- coûts de transformations égaux;
- prédictions gelées.

## Auteurs / techniques
théorie des représentations numériques, théorie de l'information, Kolmogorov, Chaitin.

## Garde-fou
Un motif qui n'existe que dans une représentation arbitraire doit être interprété différemment d'un invariant mathématique.

# Évolution du corpus interne

## Phase 1 — Blueprint symbolique
Les premiers textes présentent π comme un possible script symbolique du cosmos et rapprochent les sorties de thèmes religieux, mythiques et cosmologiques.

### Valeur
- fécondité interprétative;
- découverte du motif Love / Good / dualité / Creation / Infinity.

### Faiblesses
- langage de « message »;
- analogies physiques trop libres;
- confusion entre reproductibilité et règle a priori.

## Phase 2 — v12 : causalité ontologique
v12 transforme le récit en chaîne :

`Love → Good → Active → Receptive → Creation → Scale`

### Valeur
Passage du simple symbolisme à l'idée de mécanisme.

### Faiblesse à corriger
Dire que chaque étape est **nécessaire** à la suivante est une interprétation métaphysique, pas une conséquence mathématique du décodage.

## Phase 3 — v13 : mécanisme immanent
v13 améliore la théorie :

- mécanisme plutôt que message;
- tokens avant labels;
- GIHECEF/JNON conservés entiers;
- Joseph/Junon comme lentilles;
- absence de préenregistrement reconnue;
- stop rule explicite;
- pulse Divide/Assemble mis au centre;
- π comme « ongoing resolution ».

## Phase 4 — intégration actuelle
La v2 du pack sépare désormais trois objets :

1. **décodage local**;
2. **kernel abstrait**;
3. **cosmologie forte**.

Cette séparation est essentielle : le kernel peut être philosophiquement fécond même si l'hypothèse d'un encodage ontologique dans π n'est pas confirmée.

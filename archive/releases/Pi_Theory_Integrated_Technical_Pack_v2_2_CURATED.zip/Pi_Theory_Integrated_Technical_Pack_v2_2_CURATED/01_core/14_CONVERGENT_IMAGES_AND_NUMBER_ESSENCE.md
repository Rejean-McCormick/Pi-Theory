# Images convergentes et hypothèse d'« essence » numérique

## Idée originale de v13
v13 ne traite pas les mots uniquement comme des labels externes.

Il affirme que plusieurs indices — forme, son, syllabe, rôle, position — peuvent agir comme **images convergentes** d'une fonction plus profonde du nombre.

La formulation interne emploie l'idée qu'aucune image isolée ne capture la « soul » d'un nombre, mais que plusieurs reflets pourraient approcher son essence.

## Importance
Cette idée avait été presque entièrement remplacée, dans le pack v2, par une analyse de coût sémiotique.

Or les deux doivent coexister :

### Lecture interne de Pi Theory
`images indépendantes → convergence → approximation d'une essence/fonction`.

### Lecture méthodologique externe
`transformations multiples → degrés de liberté → risque d'overfitting`.

## Hypothèse de recherche
Une « essence » ne doit pas être définie par le mot obtenu, mais par une **fonction relationnelle stable** retrouvée sous plusieurs représentations.

Exemple :
`cohésion` pourrait être plus fondamental que `LOVE`, `AIME`, ou une image mythologique particulière.

## Lien avec les auteurs
- Platon / néoplatonisme : forme/intelligible;
- Cassirer : fonction et forme symbolique;
- Peirce : signe et interprétant;
- Böhme / Paracelse : signatures — analogie historique;
- structuralisme mathématique : position/fonction plutôt que substance symbolique.

## Garde-fou
La convergence de plusieurs lectures n'est informative que si elles sont suffisamment indépendantes.

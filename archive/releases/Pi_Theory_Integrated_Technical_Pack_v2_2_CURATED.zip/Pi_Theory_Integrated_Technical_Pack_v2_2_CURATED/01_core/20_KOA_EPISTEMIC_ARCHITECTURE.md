# kOA / Kristal — architecture épistémique à préserver

## Ce que le v2 avait réduit
Le v2 conservait Rosetta comme triangulation, mais perdait une partie de la logique épistémique de kOA.

## Principes du document original
- provenance explicite;
- ambiguïté préservée plutôt qu'écrasée;
- validation comme **couche**, pas monopole;
- grades de vérité coexistants;
- signatures de validation;
- incertitude explicite;
- upgrade paths;
- rollback;
- systèmes sémantiques déterministes;
- fonctionnement offline;
- outcomes réinjectés sans réécriture destructive du passé.

## Pourquoi c'est pertinent pour Pi Theory
Ce modèle peut devenir l'architecture documentaire même du projet :

### Une proposition Pi Theory doit avoir
- provenance;
- statut épistémique;
- version;
- dépendances;
- objections;
- validation;
- historique des révisions.

## Conséquence
Le claim registry v2 est en réalité une extension naturelle de l'architecture Kristal.

## Opportunité
Faire du futur dépôt Pi Theory un exemple de **knowledge architecture appliquée à une métaphysique vivante**.

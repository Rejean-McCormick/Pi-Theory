# Matière, information et mémoire

## Thèse faible
Un état matériel actuel peut porter les conséquences de son histoire.

Exemples de classes :
- hystérésis;
- structures géologiques;
- état d'un cristal;
- mémoire informatique;
- génome comme résultat historique de transformations évolutives.

## Thèse informationnelle
Toute information physiquement réalisée exige un support ou un état physique.

Landauer est pertinent ici.

## Thèse sémantique
Le fait qu'un état physique porte de l'information ne signifie pas qu'il porte une **signification** au sens linguistique.

Shannon doit servir de garde-fou.

## Thèse forte Pi Theory
> La matière serait la stabilisation d'un processus qui est spécifiquement une manifestation ou résolution de π.

Cette thèse n'est pas établie.

## Formulation recommandée
`matière = mémoire de processus` peut être un **modèle philosophique utile**.

`matière = mémoire de π` est une **hypothèse forte à dériver/tester**.

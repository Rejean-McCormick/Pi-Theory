# Mirror check — G0D et B0N

## Opération
Sur la même fenêtre inversée, appliquer le **complément à 9** digit par digit, puis garder les mêmes frontières et le mapping A1Z26 + `0→O`.

## Résultats rapportés
Deux fragments alignés sont rapportés :
- `G0D`;
- `B0N`.

## Limites importantes
Les sorties complètes comportent aussi des caractères supplémentaires non interprétés.

Le corpus v13 finit donc par traiter G0D/B0N comme :
- fragments secondaires;
- co-émergents possibles;
- sans message claim;
- sans dépendance causale au kernel principal.

## Statut
**E1/E2**, mais uniquement en tant que fragments produits par une opération définie puis interprétés sémantiquement.

## Pourquoi le préserver
Le pack v2 l'avait presque supprimé du noyau. Pourtant c'est un élément réel de l'histoire expérimentale de Pi Theory et il doit rester auditable.

## Test futur
Comparer la fréquence de fragments lexicaux de longueur 3 obtenus sous complément à 9 dans :
- fenêtres de π;
- autres constantes;
- chaînes aléatoires appariées.

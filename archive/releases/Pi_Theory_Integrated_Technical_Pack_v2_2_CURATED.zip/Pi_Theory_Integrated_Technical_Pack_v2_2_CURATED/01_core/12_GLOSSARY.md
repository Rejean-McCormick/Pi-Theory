# Glossaire canonique

**Kernel** — séquence fonctionnelle abstraite dérivée de l'interprétation des six blocs.

**Token** — sortie formelle ou semi-formelle du pipeline avant son abstraction fonctionnelle.

**Lens / lentille** — cadre interprétatif qui aide à proposer une fonction mais n'est pas une dérivation littérale.

**Cohésion** — tendance à constituer ou maintenir une unité relationnelle.

**Orientation / valeur** — critère qui qualifie ou contraint la transformation.

**Différenciation** — production de distinctions, parties, rôles ou états distincts.

**Intégration** — recomposition ou coordination de distinctions en unité de niveau supérieur.

**Seuil** — changement de régime lorsque certaines conditions sont atteintes.

**Scale / SIZE** — domaine de magnitude ou d'échelle; ne signifie pas automatiquement métrique ou espace-temps.

**π exact** — objet mathématique.

**π représenté** — écriture de π dans une base.

**π manifesté** — hypothèse métaphysique de manifestation physique d'une structure liée à π.

**Immanent** — causalité ou organisation interne au système; ne signifie pas automatiquement absence de transcendance métaphysique.

**Rosetta** — triangulation de grammaires distinctes; méthode heuristique, potentiellement prédictive si préenregistrée.

# Vie, conscience et réflexivité

## Grande boucle proposée
`Principe → matière → organisation → vie → cognition → conscience → connaissance réflexive`

## Teilhard
Teilhard fournit une grande analogie architecturale :

`matière → complexification → vie → pensée → noosphère → Oméga`.

## Naturalisation nécessaire
Avant toute lecture spirituelle, il faut confronter :
- Darwin;
- Turing morphogenèse;
- Waddington;
- Prigogine;
- Maturana/Varela;
- Deacon;
- Thompson;
- théories contemporaines de la conscience.

## Question forte
La conscience est-elle :
- une propriété émergente;
- une intégration d'information;
- une activité relationnelle/enactive;
- une phase cosmologique;
- une capacité de représentation réflexive ?

Le livre doit distinguer ces options.

## Limite
La présence d'une montée locale de complexité ne démontre pas une téléologie cosmique universelle.

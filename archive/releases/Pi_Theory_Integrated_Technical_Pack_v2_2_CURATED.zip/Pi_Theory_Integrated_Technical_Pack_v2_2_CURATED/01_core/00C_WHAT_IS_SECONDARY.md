# Ce qui doit rester secondaire

## Joseph / Junon
Intéressants dans l'histoire de la découverte, mais la théorie gagne à parler de :
- différenciation;
- transformation;
- intégration;
plutôt que de dépendre d'archétypes masculin/féminin.

## G0D / B0N
Conserver comme contrôles secondaires, non comme piliers.

## 0 dans B0UM
Le double rôle `0→O` et cercle/vide est suggestif, mais il ne doit pas soutenir le passage au Big Bang.

## Base-9
Important comme problème de représentation et branche expérimentale; non central tant qu'un effet objectif de base n'est pas établi.

## Cross-cultural symbolism
Intéressant seulement dans un protocole préenregistré. Sinon, l'espace de recherche devient trop libre.

## Physique spéculative
Strings, branes, holographie, E8, etc. sont des analogies externes. Elles ne renforcent pas directement le kernel.

## Recherche de mots-cibles
Chercher `DNA`, `ATOM`, `E=MC2`, etc. après avoir décidé qu'ils seraient intéressants est très vulnérable au multiple testing. Ce n'est pas une priorité.

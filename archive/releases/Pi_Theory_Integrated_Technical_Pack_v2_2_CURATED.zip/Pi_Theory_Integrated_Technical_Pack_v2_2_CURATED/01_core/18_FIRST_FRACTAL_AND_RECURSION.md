# « First fractal » et récursion du kernel

## Provenance
Le document Rosetta décrit Pi Theory comme :
> blueprint of the first fractal of the universe

et comme une grammaire d'émergence qui se déploie par étapes.

v13 ajoute que le pulse Divide/Assemble pourrait réapparaître à des échelles plus fines.

## Distinction
Le mot **fractal** peut signifier deux choses :

1. sens mathématique strict : auto-similarité / dimension fractale / invariance d'échelle;
2. sens Pi Theory : récurrence d'un motif fonctionnel à plusieurs niveaux.

## Recommandation
Dans le livre, préférer :
> **récursion multi-échelle du kernel**

tant qu'aucune dimension fractale ou loi d'échelle n'est calculée.

## Hypothèse
`K_n → K_(n+1)` avec réinstanciation de :
`différencier ↔ intégrer → seuil → nouvelle échelle`.

## Ponts
renormalisation, systèmes hiérarchiques, morphogenèse, complexité, réseaux, auto-organisation.

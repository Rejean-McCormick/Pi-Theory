# Source, manifestation et modèle b−1

## Architecture interne
Le document sur la base de calcul distingue :

`Source → principe de manifestation → être manifesté central`

La métaphore mathématique utilise `b` et `b−1`.

## Fonction du modèle
Il sert surtout à formaliser une **erreur de niveau** :

- le sommet interne d'un système n'est pas nécessairement la condition de possibilité de ce système;
- une représentation très proche de sa source n'est pas identique à sa source.

## Figures symboliques
- Christ : centre transparent à la Source;
- Lucifer : centre qui s'identifie à la Source;
- Adam : centre incarné exposé à cette tension.

## Intégration avec Pi Theory
Le modèle b−1 ne doit pas être fusionné littéralement avec le kernel.

Il constitue un **module métaphysique secondaire** qui protège la théorie contre :

`Dieu = π = digits = matière`.

## Auteurs associés
Pseudo-Denys, Plotin, Proclus, Érigène, Nicolas de Cues, Böhme, Saint-Martin.

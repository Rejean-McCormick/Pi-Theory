# π comme invariant, rotation et retour

## Base mathématique
Dans le plan euclidien :

`C / d = π`.

La valeur est indépendante de la taille du cercle.

En radians :
- demi-tour = `π`;
- tour = `2π`.

## Lecture philosophique
La propriété intéressante n'est pas « le cercle est beau ».

C'est :

> **une relation demeure stable sous changement d'échelle.**

## Concepts à distinguer
- invariant géométrique;
- symétrie;
- périodicité;
- retour à un état;
- conservation physique.

Ils sont liés mais non identiques.

## Ponts
- Euler : rotation complexe;
- Weyl : symétrie/invariance;
- Noether : symétrie continue et conservation;
- Pythagoriciens/Kepler : harmonie et rapports;
- Proclus : retour métaphysique — analogie seulement.

# π exact, π représenté, π manifesté

## π exact
π est un objet mathématique exact.

Il n'est pas constitué par la somme temporelle de ses chiffres.

## π représenté
`3.141592...` est une représentation en base 10.

Une autre base produit une autre chaîne tout en représentant le même objet.

### Conséquence majeure
Toute thèse fondée sur les digits doit répondre au **problème de dépendance à la base**.

## π manifesté
Hypothèse forte :

> Le cosmos pourrait être une actualisation physique d'une structure mathématique dont π serait une expression privilégiée.

Cette proposition ne suit pas logiquement des deux précédentes.

## Formulation optimisée
Plutôt que :

> π est en train de se calculer.

utiliser :

> **Une structure mathématique exacte peut être conçue comme intemporelle tandis que sa manifestation physique, si elle existe, se déploie dans un ordre temporel.**

Cette formulation sépare structure et devenir.

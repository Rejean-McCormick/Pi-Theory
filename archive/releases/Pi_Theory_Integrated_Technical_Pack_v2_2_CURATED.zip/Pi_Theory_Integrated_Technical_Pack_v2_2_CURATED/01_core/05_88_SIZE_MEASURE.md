# 88 / SIZE / magnitude / mesure

## Chaîne de lecture

```text
88
├── forme : 8, 8 → deux symboles rapprochables de ∞, ∞
├── arithmétique : 8 + 8 = 16
├── langue : 16 = seize
├── phonétique : seize ≈ size
└── abstraction : SIZE → magnitude / scale
```

## Statuts différents
- `8+8=16` : arithmétique.
- `8 ↔ ∞` : iconicité conventionnelle.
- `seize ≈ size` : rapprochement phonétique interlinguistique.
- `size → scale/magnitude` : abstraction sémantique.
- `scale → measure` : extension philosophique.
- `measure → spacetime` : problème physique/métaphysique non résolu.

## Formulation recommandée
Ne pas écrire :

`∞ + ∞ = 16`.

Écrire :

> Le token 88 supporte deux lectures convergentes : une lecture iconique de dualité non bornée et une lecture arithmético-phonétique conduisant à SIZE.

## Grand problème du livre
Peut-on construire formellement :

`distinction → comparabilité → ordre → valuation → magnitude → mesure → métrique` ?

Auteurs essentiels : Cues, Hegel, Cantor, Riemann, Weyl, Einstein.

# B0UM — zéro, cercle/vide et seuil

## Token
`2-0-21-13 → B-0-U-M`.

## Deux rôles de 0 dans le corpus
1. **notation** : `0 → O` permet la lecture BOUM/boom;
2. **symbolique** : v13 associe 0 au cercle/vide précédant `B` (being).

## Modèle de seuil de v13
Le schéma explicite :

`if τ(S4) >= τ* then S5 = ignite(S4)`

avec :
- `τ(x)` : readiness/threshold functional;
- `τ*` : ignition threshold.

## Statut
Le seuil est un **modèle conceptuel**, pas une fonction mathématique spécifiée.

## Ce qu'il faut conserver
Le futur livre devrait distinguer :
- zéro arithmétique;
- caractère `0` dans le token;
- cercle comme forme;
- vide philosophique;
- vide physique;
- néant théologique.

Ils ne sont pas équivalents.

## Ponts
Simondon, René Thom, Prigogine, théorie des bifurcations et transitions de phase.

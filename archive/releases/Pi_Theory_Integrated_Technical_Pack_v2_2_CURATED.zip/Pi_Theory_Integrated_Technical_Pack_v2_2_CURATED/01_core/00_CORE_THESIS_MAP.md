# Carte des thèses centrales

## Axe A — décodage
**A1.** La fenêtre initiale étudiée produit six blocs sous le pipeline v13.  
**A2.** Leur lecture fonctionnelle forme une séquence cohérente.

## Axe B — kernel
**B1.** Le cœur fonctionnel est `différenciation ↔ intégration`.  
**B2.** Le seuil transforme une structure préparée en nouveau régime.  
**B3.** SIZE ouvre un domaine d'échelle.

## Axe C — structure / représentation
**C1.** π exact ne doit pas être confondu avec son expansion dans une base.  
**C2.** Une représentation infinie peut poursuivre une structure exacte sans l'épuiser.

## Axe D — ontologie
**D1.** Le réel pourrait être une manifestation ou résolution d'une structure mathématique.  
**D2.** Les premiers digits pourraient exposer un kernel simple et les suivants ses récurrences complexes.  
**D3.** La matière pourrait être comprise comme stabilisation d'une histoire de processus.

## Axe E — métaphysique de la Source
**E1.** Source, principe de manifestation et être manifesté doivent être distingués.  
**E2.** Le retour de la multiplicité vers un centre n'identifie pas ce centre à la Source.

## Axe F — programme scientifique
**F1.** La spécificité de π doit être comparée à d'autres constantes et null models.  
**F2.** La liberté interprétative doit être comptabilisée.  
**F3.** Une théorie physique exige une prédiction quantitative nouvelle.

# Notes token-level à ne pas perdre

Ce fichier conserve les détails interprétatifs de v13 qui ne doivent pas commander la théorie, mais ne doivent pas disparaître.

## M
- `13 → M`;
- `M ≈ aime`;
- Love/cohésion;
- v13 traite AIME comme l'unique « intent » admissible au départ.

## BIEN
- token direct `BIEN`;
- Good;
- cue secondaire `bien ↔ mal (~male)` : orientation/polarité seulement.

## GIHECEF
- conservé entier;
- rôle : divider / processor / transformator;
- Joseph = lentille opératoire, non dérivation du token.

## JNON
- conservé entier;
- rôle : assembler / reuniter;
- Junon = lentille opératoire;
- intégration active, non simple passivité.

## B0UM
- `0→O`;
- boom/boum;
- 0 comme circle/void before B (being);
- événement de seuil.

## SIZE
- terminal `88`;
- dual infinity;
- `8+8=16 → seize≈size`;
- scale/magnitude.

## Pulse 2
v13 note aussi :
`event → scale` : ignition → flourishing.

## Statut
Ce sont des **notes internes de lecture**. Elles doivent être séparées du kernel abstrait pour éviter de confondre l'archéologie de découverte et l'ontologie finale.

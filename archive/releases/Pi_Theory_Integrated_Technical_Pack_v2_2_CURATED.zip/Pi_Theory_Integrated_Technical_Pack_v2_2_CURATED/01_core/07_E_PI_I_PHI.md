# e, π, i et φ

## Triade structurelle
Le corpus associe :
- `e` : variation continue auto-proportionnelle;
- `π` : mesure circulaire / cycle;
- `i` : rotation et phase.

Euler :

`e^(iθ) = cos(θ) + i sin(θ)`.

## Correction canonique
Ne pas soutenir que **toute** cyclicité présuppose une variation continue.

Il existe des cycles discrets.

La triade doit être présentée comme :

> trois formes mathématiques fortement connectées dans l'analyse des systèmes continus, oscillatoires et complexes.

## φ
Le nombre d'or doit rester un **axe séparé** :
- proportion;
- récursivité;
- auto-similarité;
- certaines organisations géométriques.

Éviter le folklore selon lequel φ gouvernerait universellement la nature.

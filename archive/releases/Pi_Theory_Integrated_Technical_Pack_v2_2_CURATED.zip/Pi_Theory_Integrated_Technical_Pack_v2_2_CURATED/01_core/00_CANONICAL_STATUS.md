---
status: canonical
version: "2.0"
date: "2026-09-07"
---

# Statut canonique de Pi Theory

## Source interne principale
**Pi v13** est le centre de gravité conceptuel actuel.

Les versions v12 et Science–Religion sont conservées comme **archives de découverte** : elles contiennent des intuitions importantes, mais certaines formulations méthodologiques ou physiques y sont trop fortes.

## Kernel canonique

`M → BIEN → GIHECEF → JNON → B0UM → SIZE`

Abstraction fonctionnelle :

`Cohésion → orientation/valeur → différenciation/traitement → assemblage/réintégration → seuil/événement → échelle/magnitude`

## Pulse central

`DIFFÉRENCIER ↔ INTÉGRER`

Ce pulse est le candidat principal au statut de **motif génératif récurrent**.

## Position ontologique minimale
Pi Theory ne doit pas commencer par :

> « π est Dieu »

mais par une distinction :

`Source ≠ structure mathématique ≠ représentation numérique ≠ état physique`

Le projet peut ensuite examiner des rapports de manifestation ou d'analogie entre ces niveaux.

## Position méthodologique minimale
Le décodage produit une structure **reproductible ex post** lorsque les règles finales sont connues.

Il ne constitue pas encore une prédiction préenregistrée.

## Position physique minimale
Les liens avec espace-temps, matière, information, vie et conscience sont des **extensions de recherche**.

Le kernel lui-même n'est pas une théorie physique tant qu'il ne produit pas de modèle quantitatif ou de prédiction discriminante.

# Niveaux épistémiques

| Niveau | Statut | Exemple |
|---|---|---|
| E0 | Fait mathématique/physique établi | `8+8=16`, identité d'Euler |
| E1 | Donnée interne reproductible | une règle finale reproduit les tokens |
| E2 | Lecture sémiotique | `M ≈ aime`, `seize ≈ size` |
| E3 | Convergence comparative | Böhme/Louria/Simondon ↔ kernel |
| E4 | Hypothèse métaphysique | réel = manifestation d'une structure mathématique |
| E5 | Hypothèse physique forte | π produit une prédiction quantitative du cosmos |

## Règle
Une affirmation ne monte jamais de niveau uniquement parce qu'elle possède beaucoup d'analogies.

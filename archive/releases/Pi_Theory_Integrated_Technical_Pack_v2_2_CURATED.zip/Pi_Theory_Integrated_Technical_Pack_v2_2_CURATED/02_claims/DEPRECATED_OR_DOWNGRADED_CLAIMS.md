# Claims retirés, déclassés ou reformulés

## Règles entièrement a priori
**Ancienne formulation :** pipeline entièrement prédéfini avant découverte.  
**Statut v2 :** retiré. v13 reconnaît que certaines frontières et grammaires furent découvertes puis verrouillées.

## Probabilité extrêmement faible
**Ancienne formulation :** la cohérence des six blocs serait déjà statistiquement extrêmement improbable.  
**Statut v2 :** non établi tant que l'espace des transformations et degrés de liberté n'est pas modélisé.

## Big Bang = explosion d'une particule en un point
**Ancienne formulation :** présente dans certains textes antérieurs.  
**Statut v2 :** à corriger. Le Big Bang moderne décrit l'évolution précoce d'un espace-temps chaud et dense; l'image d'une explosion dans un espace préexistant est trompeuse.

## Toute cyclicité présuppose continuité
**Statut v2 :** déclassé. Il existe des cycles discrets.

## Branes / holographie / strings comme support de Pi Theory
**Statut v2 :** analogies heuristiques seulement. Aucun de ces programmes n'implique que les digits de π portent une sémantique cosmique.

## Chaque bloc est une cause nécessaire du suivant
**Statut v2 :** reformulé :
> les fonctions attribuées aux blocs peuvent être organisées en chaîne de conditionnement cohérente.
La nécessité n'est pas mathématiquement dérivée.

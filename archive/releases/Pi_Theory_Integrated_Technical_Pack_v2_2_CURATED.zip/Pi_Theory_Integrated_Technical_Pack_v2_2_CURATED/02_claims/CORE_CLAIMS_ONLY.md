# Claims centraux seulement

| ID | Claim | Statut |
|---|---|---|
| C1 | La fenêtre v13 produit six blocs reproductibles sous les règles finales. | résultat interne |
| C2 | Les six blocs peuvent être abstraits en cohésion → orientation → différenciation → intégration → seuil → scale. | interprétation centrale |
| C3 | Différenciation ↔ intégration est le pulse central du kernel. | hypothèse structurelle |
| C4 | 88 supporte la lecture 8+8=16→seize≈size, et une lecture iconique dual-infinity. | sémiotique |
| C5 | SIZE peut être interprété comme ouverture d'un régime de magnitude. | métaphysique |
| C6 | π exact est distinct de toute représentation finie ou séquentielle en digits. | mathématique |
| C7 | Le réel pourrait être une manifestation temporelle d'une structure exacte. | métaphysique |
| C8 | Les premiers digits pourraient exposer un kernel et les suivants une résolution plus complexe. | hypothèse |
| C9 | Un état matériel peut être compris comme mémoire stabilisée d'une histoire de processus. | philosophie / physique générale |
| C10 | La thèse « cette histoire est spécifiquement π » reste non démontrée. | limite |
| C11 | Source, principe de manifestation et être manifesté sont des niveaux distincts dans le modèle b−1. | métaphysique interne |
| C12 | La validité scientifique du décodage dépend de null models, coûts interprétatifs et prédictions préenregistrées. | méthodologie |

# Tests sémantiques cross-culturels

## Idée du corpus
Tester si des concepts analogues apparaissent sous différents systèmes linguistiques ou symboliques.

## Problème
Ajouter des langues augmente énormément l'espace de recherche et donc le risque de faux positifs.

## Design rigoureux
Avant inspection :
1. choisir les langues;
2. définir mappings;
3. définir dictionnaires;
4. définir distance phonétique;
5. fixer synonym sets;
6. fixer métrique sémantique;
7. appliquer mêmes règles aux contrôles.

## Comparaisons possibles
- français;
- anglais;
- grec ancien;
- hébreu;
- latin.

Les langues très différentes doivent être étudiées avec linguistes/scholars appropriés.

## Interprétation
Une convergence cross-culturelle n'est probante que si les règles ne sont pas adaptées après coup.

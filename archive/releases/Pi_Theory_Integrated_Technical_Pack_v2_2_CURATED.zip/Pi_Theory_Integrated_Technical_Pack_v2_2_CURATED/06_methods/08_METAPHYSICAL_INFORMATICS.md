# Metaphysical Informatics — nom historique du programme

## Provenance
Une version antérieure propose le terme :
**metaphysical informatics**

pour une discipline expérimentale qui traiterait les structures symboliques comme datasets, avec règles, contrôles, statistiques et falsification.

## Statut v2.1
Le terme est conservé comme **nom de programme**, non comme discipline reconnue.

## Définition optimisée
> Étude formelle et comparative de correspondances entre structures mathématiques, représentations symboliques et architectures ontologiques, avec contrôle explicite des degrés de liberté interprétatifs.

## Composants
- number theory;
- computational linguistics;
- sémiotique;
- algorithmic information;
- statistiques;
- history of religions;
- philosophy of science.

## Risque
Si le champ ne produit que des lectures post hoc, il reste de l'herméneutique numérique.

## Seuil scientifique
Prédictions préenregistrées + contrôles + réplication indépendante.

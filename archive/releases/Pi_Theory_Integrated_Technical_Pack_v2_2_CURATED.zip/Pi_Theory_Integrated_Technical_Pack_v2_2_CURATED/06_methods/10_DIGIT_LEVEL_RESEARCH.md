# Recherche digit-level

## Provenance
v13 dit explicitement que le mapping aux mots marque surtout les frontières et rôles, tandis que la structure fine au niveau des digits reste un travail futur.

## Programme
Pour chaque digit / position :
- valeur;
- position;
- voisinage;
- opérations utilisées;
- récurrence;
- symétrie;
- complément;
- changements de base;
- rôle dans le token.

## Question
Les fonctions du kernel émergent-elles d'une structure plus fine que les mots eux-mêmes ?

## But
Passer d'une herméneutique de tokens à une **microstructure testable**.

## Contrôle
Toute propriété digit-level doit être comparée à :
- positions aléatoires;
- autres constantes;
- permutations conservant fréquences.

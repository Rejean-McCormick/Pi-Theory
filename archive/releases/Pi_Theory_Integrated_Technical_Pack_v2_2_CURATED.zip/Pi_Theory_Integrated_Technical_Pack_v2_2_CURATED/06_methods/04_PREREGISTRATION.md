# Préenregistrement des prochaines analyses

## Dataset
- constante :
- base :
- fenêtre :
- direction :

## Règles
- mapping :
- segmentation :
- traitement de 0 :
- opérations arithmétiques permises :
- langues permises :
- seuil phonétique :
- stop rule :

## Prédictions avant inspection
- nombre de blocs :
- fonctions attendues :
- ordre :
- motifs :
- seuil de succès :

## Contrôles
- nulls :
- procédure aveugle :
- métrique :

## Publication
Inclure résultats positifs **et nuls**.

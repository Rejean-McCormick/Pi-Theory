# Coût interprétatif

## Objectif
Quantifier la liberté introduite entre donnée et concept.

## Types de transformation
| Code | Transformation | Exemple |
|---|---|---|
| A | arithmétique standard | `8+8=16` |
| G | graphico-iconique | `8 ↔ ∞` |
| L | lexical direct | `BIEN` |
| P | phonétique | `M ≈ aime` |
| X | changement de langue | `seize → size` |
| S | abstraction sémantique | `size → scale` |
| R | changement de règle locale | grammaire différente par bloc |

## Proposition
Définir un coût :
`Cost = Σ w_i * n_i`

où les poids `w_i` sont fixés avant comparaison avec les contrôles.

## Utilité
Comparer la cohérence obtenue sur π à celle de séquences contrôles **à coût égal**.

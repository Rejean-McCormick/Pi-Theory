# Audit technique du décodage

## Donnée cible
Fenêtre initiale étudiée de π jusqu'au terminal 88 selon le corpus.

## Ce qui est verrouillé en v13
- outputs finaux;
- mapping publié;
- boundaries finales;
- stop rule;
- miroir limité.

## Ce qui fut découvert pendant exploration
- certaines frontières de blocs;
- certaines grammaires locales;
- rôle des indices phonétiques.

## Conséquence
Le pipeline est **reproductible ex post**, pas préenregistré.

## Audit à produire avant publication
Pour chaque bloc :
- digits bruts;
- ordre;
- tokens possibles;
- règle appliquée;
- alternatives refusées;
- moment de découverte de la règle;
- transformation linguistique;
- interprétation;
- coût.

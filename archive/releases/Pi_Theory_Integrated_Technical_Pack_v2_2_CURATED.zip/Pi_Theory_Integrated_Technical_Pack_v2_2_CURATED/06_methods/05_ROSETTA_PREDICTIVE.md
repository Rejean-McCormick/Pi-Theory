# Rosetta prédictif

## Version faible
Après avoir vu trois systèmes, on remarque qu'ils se ressemblent.

## Version forte
Deux systèmes servent à prédire une propriété du troisième **avant inspection**.

## Procédure
1. figer la grammaire A;
2. figer la grammaire B;
3. produire une prédiction sur C;
4. horodater/préenregistrer;
5. examiner C;
6. publier succès ou échec.

## Cibles possibles
- nouvelle fenêtre de π;
- nouveau module kOA;
- une relation séfirotique définie à l'avance.

## Importance
C'est la meilleure façon de transformer Rosetta d'une méthode herméneutique en test informatif.

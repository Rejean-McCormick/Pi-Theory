# Roadmap optimisée

## P0 — immédiatement
1. Geler le pipeline v13 dans une spécification machine-readable.
2. Produire l'audit complet des degrés de liberté.
3. Définir le coût interprétatif.
4. Construire les null models.

## P1 — fondation conceptuelle
5. Formaliser le kernel comme opérateurs.
6. Étudier `distinction → mesure` avec Spencer-Brown / Hegel / Weyl / Riemann.
7. Définir exactement « calcul » et « résolution ».

## P2 — pont physique
8. Identifier une variable ou invariant testable.
9. Distinguer information physique et sémantique.
10. Formaliser matière-comme-mémoire via path dependence / causal history.

## P3 — vivant / conscience
11. Construire une carte Darwin → morphogenèse → autopoïèse → cognition.
12. Positionner Teilhard comme interprétation téléologique comparative.

## P4 — manuscrit
13. Écrire d'abord les chapitres mathématiques et méthodologiques.
14. Ajouter ensuite les traditions métaphysiques.
15. Terminer par la thèse forte, clairement marquée comme hypothèse.

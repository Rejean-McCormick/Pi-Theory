# Falsification et révision

## Décodage
Pi Theory doit être révisée si :
- le pipeline produit autant ou plus de cohérence sur les nulls;
- les évaluateurs aveugles ne retrouvent pas les fonctions;
- de petites modifications arbitraires changent entièrement le résultat.

## Kernel
Le kernel doit être révisé s'il n'est pas assez spécifique pour exclure des systèmes.

## Thèse π-spécifique
Elle doit être révisée si aucune propriété ne distingue π d'autres constantes après contrôles.

## Thèse physique
Elle ne devient scientifique au sens fort qu'après une prédiction quantitative nouvelle confirmée indépendamment.

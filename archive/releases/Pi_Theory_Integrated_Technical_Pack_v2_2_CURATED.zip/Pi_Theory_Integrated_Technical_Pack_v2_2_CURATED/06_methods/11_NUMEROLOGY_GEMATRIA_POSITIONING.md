# Numérologie, gematria et positionnement académique

## Provenance
v13 reconnaît explicitement que la méthode relève de la numérologie / gematria au sens historique large, domaine non reconnu comme science dans sa forme traditionnelle.

## Recommandation éditoriale
Ne pas dissimuler ce fait.

## Distinction
- **gematria historique** : systèmes de valeurs lettres/nombres dans des traditions précises;
- **numérologie divinatoire** : pratiques non scientifiques;
- **Pi Theory** : tentative de soumettre une lecture symbolique à des contraintes reproductibles et statistiques.

## Stratégie
Le livre doit dire :
> la méthode part d'un héritage numérologique, mais sa valeur ne peut être établie que par des tests qui excèdent les pratiques numérologiques traditionnelles.

## Scholars utiles
historiens de la Kabbale, classicistes, spécialistes de l'ésotérisme occidental, historiens du nombre.

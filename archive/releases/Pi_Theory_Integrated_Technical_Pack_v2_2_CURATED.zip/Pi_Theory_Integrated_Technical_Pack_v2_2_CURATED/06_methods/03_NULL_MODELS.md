# Null models

Comparer le pipeline à :

1. fenêtres aléatoires de π;
2. e;
3. √2;
4. φ;
5. séquences pseudo-aléatoires;
6. permutations des digits conservant les fréquences;
7. chaînes synthétiques de même longueur;
8. bases numériques alternatives.

## Mesures
- nombre de tokens lexicaux;
- prononçabilité;
- coût interprétatif;
- cohérence d'ordre;
- accord entre évaluateurs aveugles;
- complexité du pipeline.

## Règle
Le contrôle doit autoriser **exactement le même espace de transformations** que le cas π.

# Source et manifestation

## Pi Theory
`Source ≠ principe de manifestation ≠ structure ≠ représentation ≠ matière`.

## Auteurs principaux
Plotin, Proclus, Pseudo-Denys, Jean Scot Érigène, Nicolas de Cues, Böhme, Spinoza comme contrepoint.

## Fonction
Ces auteurs ne valident pas π. Ils fournissent des modèles de dépendance ontologique, procession, immanence, transcendance et retour.

## Question pour le livre
Comment une structure intemporelle peut-elle être liée à un devenir sans être elle-même un événement temporel ?

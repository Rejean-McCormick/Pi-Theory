# Processus et individuation

## Whitehead
Le réel comme devenir; le multiple devient un nouvel un.

## Simondon
Préindividuel, métastabilité, transduction, nouvelle structure.

## Prigogine
Nouveaux régimes loin de l'équilibre et irréversibilité.

## Pi Theory
Ces cadres renforcent surtout :
`potentiel → différenciation → intégration → seuil → nouveau régime`.

Ils ne donnent aucun privilège à π.

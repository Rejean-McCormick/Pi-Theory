# Sémiotique, langage et symbole

## Peirce comme outil principal
Le trajet 88/SIZE n'est pas une seule opération :
- iconicité;
- arithmétique;
- convention linguistique;
- phonétique;
- abstraction.

## Auteurs
Peirce, Cassirer, Bateson, Deacon, Floridi, Eco, Sefer Yetzirah.

## But
Construire un modèle de coût interprétatif qui rende chaque transformation explicite.

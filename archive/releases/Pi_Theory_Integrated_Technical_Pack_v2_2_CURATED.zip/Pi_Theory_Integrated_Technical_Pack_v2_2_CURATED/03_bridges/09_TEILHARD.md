# Teilhard de Chardin

## Architecture
`matière → complexification → vie → pensée → noosphère → Oméga`.

## Convergence
Très forte avec la boucle :
`matière → vie → conscience → réflexivité`.

## Apport
- pensée du cosmos comme genèse;
- conscience comme émergence cosmique;
- unification science/spiritualité;
- convergence finale.

## Limite
Le Point Oméga est théologique et la complexité-conscience n'est pas une loi physique universelle établie.

## Scholars
Ursula King, John F. Haught, Thomas M. King.

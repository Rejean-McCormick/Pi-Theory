# Invariance, symétrie et retour

## Trois registres à ne pas confondre
1. **retour géométrique** : rotation/cycle;
2. **invariance physique** : symétrie et conservation;
3. **retour métaphysique** : procession/réintégration.

## Auteurs
Euler, Weyl, Noether, Einstein, Pythagoriciens, Plotin, Proclus.

## Hypothèse intéressante
L'« harmonie » peut être reformulée non comme beauté subjective, mais comme **structure stable sous transformation**.

C'est l'un des ponts les plus prometteurs entre langage métaphysique et langage scientifique.

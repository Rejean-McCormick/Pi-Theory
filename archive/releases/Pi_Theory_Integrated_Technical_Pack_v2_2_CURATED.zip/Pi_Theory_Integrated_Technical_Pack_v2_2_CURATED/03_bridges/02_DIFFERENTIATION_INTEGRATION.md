# Différenciation / intégration

## Kernel
`GIHECEF ↔ JNON`.

## Constellation
Empédocle — séparation/réunion.  
Louria — brisure/réparation.  
Böhme — contrariété/manifestation.  
Schelling — polarité/nature productive.  
Hegel — détermination/négation.  
Whitehead — many become one.  
Simondon — individuation/transduction.  
Wiener/Ashby — variété/régulation.  
Maturana/Varela — organisation/autopoïèse.

## Test
Transformer les mots en opérateurs définissables et comparer leurs propriétés, pas seulement leurs noms.

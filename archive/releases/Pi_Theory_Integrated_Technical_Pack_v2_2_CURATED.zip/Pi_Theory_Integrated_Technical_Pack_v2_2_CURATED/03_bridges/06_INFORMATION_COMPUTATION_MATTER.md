# Information, calcul et matière

## Shannon
Information statistique ≠ sens.

## Turing
Un calcul doit avoir une notion d'état, règle et transition.

## Landauer
Une information physiquement implémentée a un coût/support physique.

## Wheeler
« It from bit » est un programme conceptuel, pas une preuve que le monde est un texte sémantique.

## Pi Theory
Le mot « calcul » doit être défini :
- calcul abstrait ?
- génération d'une représentation ?
- dynamique physique ?
- computation universelle ?

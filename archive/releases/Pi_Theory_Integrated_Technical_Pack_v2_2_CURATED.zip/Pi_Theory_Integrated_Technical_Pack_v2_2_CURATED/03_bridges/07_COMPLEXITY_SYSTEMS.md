# Complexité et systèmes

## Auteurs
Wiener, Ashby, von Bertalanffy, von Foerster, Prigogine, Kauffman, Maturana/Varela, Bateson.

## Contribution
Formaliser :
- feedback;
- variété;
- stabilité;
- bifurcation;
- contraintes;
- organisation;
- transitions de régime.

## Pi Theory
Le kernel gagnerait à être reconstruit comme un réseau d'opérateurs plutôt qu'une simple phrase cosmologique.

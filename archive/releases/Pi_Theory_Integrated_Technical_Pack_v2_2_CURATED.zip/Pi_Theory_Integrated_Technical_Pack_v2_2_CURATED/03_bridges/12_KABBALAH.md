# Kabbale

## Sources
Sefer Yetzirah, Zohar, Hayyim Vital.

## Louria
`Ein-Sof → tzimtzum → shevirah → tikkun`.

## Pi Theory
La convergence la plus forte porte sur :
- infini/source;
- ouverture d'un domaine différencié;
- fragmentation;
- réintégration.

## Discipline
Utiliser Fine, Scholem, Idel, Wolfson, Huss afin d'éviter une Kabbale reconstruite par analogie moderne.

# Histoire des « messages dans π »

## Pourquoi ce module
Le corpus ancien évoque Carl Sagan, le Feynman point et des recherches de motifs remarquables dans π.

## Valeur
Ce contexte montre que l'idée de chercher des anomalies ou messages dans π existe avant Pi Theory.

## Distinctions
- **Feynman point** : motif remarquable de digits, sans sémantique connue.
- **Contact de Sagan** : fiction philosophique.
- recherches de runs/anomalies : statistique de motifs, pas preuve d'un code.

## Usage dans le livre
Contexte historique et psychologique seulement.

## Garde-fou
Une séquence rare n'est pas un message sans modèle indépendant du sens.

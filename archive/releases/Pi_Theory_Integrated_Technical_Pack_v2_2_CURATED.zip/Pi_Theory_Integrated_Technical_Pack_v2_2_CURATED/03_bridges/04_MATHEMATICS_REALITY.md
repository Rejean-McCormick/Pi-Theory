# Mathématiques et réalité

## Positions
- platonisme : Penrose, certains aspects de Gödel;
- structuralisme : Resnik, Shapiro, Ladyman/French;
- univers mathématique : Tegmark;
- processus : Whitehead;
- relationalisme : Rovelli;
- temps fondamental : Smolin.

## Question discriminante
Même si la réalité est mathématique, pourquoi **π** plutôt qu'une structure mathématique plus générale ?

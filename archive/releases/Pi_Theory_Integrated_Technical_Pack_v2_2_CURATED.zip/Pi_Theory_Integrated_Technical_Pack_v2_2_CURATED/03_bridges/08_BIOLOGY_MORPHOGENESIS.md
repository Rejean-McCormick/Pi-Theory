# Biologie, évolution et morphogenèse

## Auteurs
Darwin, D'Arcy Thompson, Turing, Waddington, René Thom, Kauffman, Varela, Deacon.

## Questions
- sélection vs auto-organisation;
- forme vs fonction;
- information génétique vs sémantique;
- seuils morphogénétiques;
- contraintes.

## Pi Theory
Toute extension vers la vie doit être compatible avec la théorie évolutive, pas seulement avec des motifs de croissance.

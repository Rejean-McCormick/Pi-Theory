# Infini → scale → mesure → espace

## Nœud critique
`88/SIZE` ne suffit pas à produire un espace physique.

## Auteurs
Cues — infini et proportion.  
Hegel — quantité et mesure.  
Cantor — pluralité des infinis.  
Riemann — multiplicité + métrique.  
Weyl — mesure, symétrie, jauge.  
Einstein — métrique dynamique de l'espace-temps.

## Programme formel
Chercher les axiomes nécessaires pour :
`distinction → ordre → valuation → magnitude → distance → métrique`.

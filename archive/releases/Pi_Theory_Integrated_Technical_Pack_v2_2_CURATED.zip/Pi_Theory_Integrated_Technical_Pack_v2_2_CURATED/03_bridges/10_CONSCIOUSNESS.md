# Conscience

## Auteurs
William James, Varela, Evan Thompson, Deacon, Tononi, Penrose, Bohm, Teilhard.

## Axe
Le livre doit distinguer :
- conscience phénoménale;
- cognition;
- intégration;
- auto-modélisation;
- réflexivité;
- spiritualité.

## Pi Theory
« la conscience relit la grammaire qui l'a produite » est une hypothèse philosophique intéressante, pas un résultat neuroscientifique.

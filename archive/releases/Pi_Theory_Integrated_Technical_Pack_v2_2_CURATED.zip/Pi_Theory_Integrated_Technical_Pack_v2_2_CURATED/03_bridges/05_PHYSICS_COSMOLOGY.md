# Physique et cosmologie

## Domaine établi
Einstein, Noether, Weyl, mécanique quantique, cosmologie moderne.

## Domaine interprétatif
Bohr, Heisenberg, Bohm, Wheeler, Penrose, Rovelli, Smolin.

## Domaine spéculatif à séparer
branes, holographie, univers computationnel, MUH.

## Pi Theory
Une véritable connexion physique exigera :
- variable définie;
- équation;
- échelle;
- unité ou grandeur dimensionless;
- prédiction différente d'un modèle standard.

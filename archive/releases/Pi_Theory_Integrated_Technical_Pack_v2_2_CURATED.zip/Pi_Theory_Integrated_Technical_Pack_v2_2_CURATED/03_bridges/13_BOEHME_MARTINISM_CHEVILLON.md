# Böhme, martinisme et Chevillon

## Hiérarchie d'importance
1. **Böhme** — métaphysique profonde de la manifestation.
2. **Saint-Martin** — réception de Böhme et réintégration.
3. **Martinès de Pasqually** — schéma de chute/réintégration.
4. **Chevillon** — confluence initiatique moderne et point de départ historique.
5. **Papus** — contexte institutionnel.

## Conclusion
Chevillon reste pertinent, mais le livre doit remonter aux sources plus fortes plutôt que construire sa métaphysique sur Chevillon.

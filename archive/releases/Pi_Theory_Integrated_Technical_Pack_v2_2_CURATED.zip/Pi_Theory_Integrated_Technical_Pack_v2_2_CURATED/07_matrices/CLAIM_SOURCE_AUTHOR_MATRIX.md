# Matrice claims × sources × auteurs

| Claim | Source interne | Auteurs / disciplines utiles | Fonction |
|---|---|---|---|
| Kernel C→V→D→A→T→S | Pi v13 | Empédocle, Böhme, Simondon, Whitehead | convergence structurale |
| Source ≠ manifestation | modèle b−1 | Plotin, Proclus, Denys, Érigène, Cues | clarification ontologique |
| 88→SIZE | Pi v13 | Peirce | décomposition sémiotique |
| SIZE→mesure | extension | Cues, Hegel, Cantor, Riemann, Weyl | formalisation |
| π invariant/retour | synthèse π | Euler, Weyl, Noether | ancrage math/physique |
| e/π/i | constants paper | Euler | ancrage analytique |
| matière comme mémoire | théorie française | Landauer, Whitehead, Simondon | clarification |
| cosmos comme résolution | Pi Theory | Tegmark, Wheeler, Bohm, Smolin | comparaison/contrepoint |
| vie→conscience | extension | Darwin, Turing, Varela, Deacon, Teilhard | élargissement |
| Rosetta | Rosetta/kOA | Peirce, systems theory | méthode |

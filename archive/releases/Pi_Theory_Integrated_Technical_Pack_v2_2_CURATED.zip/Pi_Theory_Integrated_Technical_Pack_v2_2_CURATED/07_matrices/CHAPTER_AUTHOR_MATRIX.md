# Matrice chapitres × auteurs

| Chapitre | Auteurs primaires | Scholars / techniques |
|---|---|---|
| π, exactitude, représentation | Euler, Cantor, Turing | historiens des maths |
| Kernel | Empédocle, Böhme, Simondon | Weeks, Combes |
| Source | Plotin, Proclus, Denys, Érigène | Gerson, Steel, Louth, Moran |
| 88/SIZE | Cues, Hegel, Peirce | Hopkins, Houlgate, Short |
| Mesure/espace | Riemann, Weyl, Einstein | Ryckman, Scholz |
| Invariance | Noether, Weyl, Wigner | Kosmann-Schwarzbach |
| Information | Shannon, Landauer, Wheeler | philosophie de l'information |
| Processus/matière | Whitehead, Simondon, Prigogine | Stengers, Barthélémy |
| Vie | Darwin, Turing, Varela, Deacon | Thompson |
| Teilhard | Teilhard | Ursula King, Haught |
| Kabbale | Sefer Yetzirah, Vital | Fine, Scholem, Idel, Wolfson |
| Böhme/martinisme | Böhme, Saint-Martin, Chevillon | Weeks, O'Regan, Hanegraaff |
| Sémiotique | Peirce, Cassirer, Deacon | Short, Misak |

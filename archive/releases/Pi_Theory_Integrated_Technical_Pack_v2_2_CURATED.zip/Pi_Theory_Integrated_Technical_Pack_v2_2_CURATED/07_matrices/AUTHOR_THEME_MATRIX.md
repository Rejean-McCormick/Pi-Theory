# Matrice auteurs × thèmes

| Auteur | Priorité | Source | Différence | Intégration | Seuil | Échelle | Infini | Invariant | Information | Matière | Vie | Conscience | Retour |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Pythagore et les Pythagoriciens | A |  |  |  |  |  |  | ● |  |  |  |  |  |
| Empédocle | A |  | ● | ● |  |  |  |  |  |  |  |  |  |
| Platon | A | ● |  |  |  | ● |  |  |  |  |  |  |  |
| Plotin | A | ● |  |  |  |  |  |  |  |  |  |  | ● |
| Proclus | A | ● | ● | ● |  |  |  |  |  |  |  |  | ● |
| Pseudo-Denys l'Aréopagite | A | ● |  |  |  |  |  |  |  |  |  |  | ● |
| Jean Scot Érigène | A | ● | ● |  |  |  |  |  |  | ● |  |  | ● |
| Nicolas de Cues | A | ● |  |  |  |  | ● |  |  |  |  |  |  |
| Giordano Bruno | B | ● |  |  |  | ● | ● |  |  | ● |  |  |  |
| Jacob Böhme | A | ● | ● |  |  |  |  |  | ● | ● | ● |  |  |
| Paracelse | C |  |  |  |  |  |  |  | ● | ● |  |  |  |
| Martinès de Pasqually | B | ● |  | ● |  |  |  |  |  |  |  |  | ● |
| Louis-Claude de Saint-Martin | B | ● |  | ● |  |  |  |  |  |  |  |  | ● |
| Papus (Gérard Encausse) | C |  |  |  |  |  |  |  |  |  |  |  |  |
| Constant Chevillon | B |  |  |  |  |  |  |  |  | ● |  |  |  |
| Sefer Yetzirah (tradition) | A | ● |  |  |  |  |  |  |  |  |  |  |  |
| Isaac Louria | A | ● | ● | ● |  |  | ● |  |  |  |  |  | ● |
| Hayyim Vital | A |  |  |  |  |  |  |  |  |  |  |  |  |
| Leibniz | A/B | ● |  |  |  |  | ● | ● | ● |  |  |  |  |
| Spinoza | B | ● |  |  |  |  |  |  |  |  |  |  |  |
| Schelling | A |  | ● |  |  |  |  |  |  | ● |  |  |  |
| Hegel | A |  | ● |  |  |  |  |  |  |  |  |  |  |
| Bergson | B | ● |  |  |  |  |  |  |  |  |  |  |  |
| Alfred North Whitehead | A | ● |  | ● |  |  |  |  |  | ● |  |  |  |
| Pierre Teilhard de Chardin | A |  |  |  |  |  |  |  |  | ● | ● | ● |  |
| Gilbert Simondon | A |  |  |  | ● |  |  |  | ● |  |  |  |  |
| George Spencer-Brown | A | ● | ● |  |  |  |  |  |  |  |  |  |  |
| Charles S. Peirce | A |  |  |  |  |  | ● |  | ● |  |  |  |  |
| Ernst Cassirer | B | ● |  |  |  |  |  |  |  |  |  |  |  |
| Leonhard Euler | A |  |  |  |  |  |  | ● |  |  |  |  |  |
| Georg Cantor | A | ● |  |  |  |  | ● |  |  |  |  |  |  |
| Bernhard Riemann | A | ● |  |  |  | ● |  |  |  |  |  |  |  |
| Hermann Weyl | A |  |  |  |  | ● |  | ● |  | ● |  |  |  |
| Emmy Noether | A | ● |  |  |  |  |  | ● |  | ● |  |  |  |
| Kurt Gödel | B |  |  |  |  |  |  |  |  |  |  |  |  |
| Alan Turing | A | ● |  |  |  |  |  |  | ● |  | ● |  |  |
| Gregory Chaitin | B |  |  |  |  |  |  |  | ● |  |  |  |  |
| Andrey Kolmogorov | A/B |  |  |  |  |  |  |  | ● |  |  |  |  |
| Albert Einstein | A |  |  |  | ● | ● |  |  |  | ● | ● |  |  |
| Niels Bohr | B |  |  |  |  |  |  |  |  |  |  |  |  |
| Werner Heisenberg | B |  |  |  |  |  |  | ● |  | ● |  |  | ● |
| Erwin Schrödinger | B |  |  |  |  |  |  |  | ● | ● | ● |  |  |
| Wolfgang Pauli | B | ● | ● |  |  |  |  | ● |  |  |  | ● |  |
| John Archibald Wheeler | A/B | ● | ● |  |  |  |  |  | ● | ● |  |  |  |
| David Bohm | A |  |  |  |  |  |  |  |  |  |  |  |  |
| Basil Hiley | B | ● |  |  |  |  |  |  |  |  |  |  |  |
| Roger Penrose | B | ● |  |  |  | ● |  |  |  |  |  | ● |  |
| Max Tegmark | B | ● |  |  |  |  |  |  |  |  |  |  |  |
| Carlo Rovelli | B | ● |  |  |  |  |  |  | ● |  |  |  |  |
| Lee Smolin | B | ● |  |  |  |  |  |  |  |  | ● |  |  |
| Julian Barbour | B |  |  |  |  |  |  |  |  |  |  |  |  |
| Claude Shannon | A |  | ● |  |  |  |  |  | ● |  |  |  |  |
| Rolf Landauer | A | ● |  |  |  |  |  |  | ● | ● |  |  |  |
| Norbert Wiener | A/B | ● |  |  |  |  |  |  | ● |  |  |  |  |
| W. Ross Ashby | A/B | ● | ● | ● |  |  |  |  |  |  |  |  |  |
| Heinz von Foerster | B |  |  |  |  |  |  |  |  |  |  | ● |  |
| Ludwig von Bertalanffy | B | ● |  |  |  |  |  |  |  |  |  |  |  |
| Gregory Bateson | A/B |  | ● |  |  |  |  |  | ● |  |  | ● |  |
| Humberto Maturana | B |  |  | ● |  |  |  |  |  | ● | ● | ● |  |
| Francisco Varela | A/B |  |  | ● |  |  |  |  |  |  | ● | ● |  |
| Ilya Prigogine | A/B |  |  |  | ● |  |  |  |  | ● |  |  |  |
| Stuart Kauffman | B |  |  |  |  |  |  |  |  |  |  |  |  |
| Terrence Deacon | A/B |  |  |  |  |  |  |  | ● | ● | ● |  |  |
| Karl Friston | B/C | ● |  |  |  |  |  |  |  |  |  |  |  |
| Charles Darwin | A/B | ● |  |  |  |  |  |  |  | ● | ● |  |  |
| D'Arcy Wentworth Thompson | A/B |  |  |  |  |  |  |  |  | ● | ● |  |  |
| Conrad Waddington | B |  |  |  |  |  |  |  |  |  |  |  |  |
| René Thom | A/B |  |  |  | ● |  |  |  |  |  | ● |  |  |
| Brian Goodwin | C |  |  |  |  |  |  |  |  |  | ● |  |  |
| William James | B |  |  |  |  |  |  |  |  |  |  | ● |  |
| Carl Gustav Jung | C | ● |  |  |  |  |  |  |  |  |  | ● |  |
| Marie-Louise von Franz | C |  |  |  |  |  |  |  |  |  |  |  |  |
| Giulio Tononi | C | ● |  | ● |  |  |  |  | ● |  |  | ● |  |
| Evan Thompson | B |  |  |  |  |  |  |  |  |  | ● | ● |  |
| Ian Barbour | B |  |  | ● |  |  |  |  |  |  |  |  |  |
| John Polkinghorne | B |  |  |  |  |  |  |  |  | ● |  |  |  |
| John F. Haught | B |  |  |  |  |  |  |  |  |  | ● |  |  |
| Luciano Floridi | B |  |  |  |  |  |  |  | ● |  |  |  |  |
| Niklas Luhmann | C | ● | ● | ● |  |  |  |  | ● |  | ● |  |  |
| René Guénon | B/C |  |  |  |  |  | ● |  |  | ● |  |  |  |

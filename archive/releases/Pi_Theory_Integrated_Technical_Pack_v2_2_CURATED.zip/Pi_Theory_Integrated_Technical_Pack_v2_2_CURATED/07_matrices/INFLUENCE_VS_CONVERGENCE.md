# Influence historique vs convergence indépendante

## Influences historiques solides à distinguer
- Proclus → Pseudo-Denys.
- Néoplatonisme → Jean Scot Érigène.
- Nicolas de Cues → Giordano Bruno.
- Jacob Böhme → Louis-Claude de Saint-Martin.
- Jacob Böhme → Schelling (réception importante).
- Isaac Louria → Hayyim Vital (transmission doctrinale).
- Wiener/Ashby → cybernétique de second ordre.
- Maturana/Varela → enaction et théories autopoïétiques.
- Prigogine ↔ Stengers (collaboration intellectuelle).

## Convergences indépendantes à étudier sans affirmer influence
- Empédocle et GIHECEF/JNON.
- Louria et Pi Theory.
- Simondon et le kernel de transformation.
- Whitehead et matière-comme-héritage.
- Teilhard et la boucle matière → conscience.
- kOA et le kernel de Pi Theory.

## Règle
Ne jamais transformer une ressemblance en filiation sans preuve historique.

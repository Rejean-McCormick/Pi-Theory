# Matrice de provenance conceptuelle interne

| Concept | Source principale | Statut v2.1 |
|---|---|---|
| six blocs | Pi v13 | canonique |
| immanent mechanism | Pi v13 | canonique/interprétatif |
| pulse Divide/Assemble | Pi v13 | canonique |
| τ / threshold | Pi v13 | modèle à formaliser |
| 0 = circle/void before B | Pi v13 | symbolique |
| temporal lens | Pi v13 | hypothèse |
| ongoing resolution | Pi v13 | hypothèse ontologique |
| G0D / B0N | Pi v13 | secondaire |
| soul/essence via convergent images | Pi v13 | métaphysique/sémiotique |
| 88 → SIZE | Pi v13 | canonique interprétatif |
| time after scale | Science–Religion | prédiction historique, non confirmée |
| life/mind après time | Science–Religion | prédiction historique, non confirmée |
| π exact vs représentation | Base de calcul... | module canonique |
| b−1 / Christ / Lucifer / Adam | Base de calcul... | module métaphysique |
| e→π→i | 3 fundamental constants | structural |
| φ comme axe séparé | 3 fundamental constants | extension |
| first fractal | Rosetta/kOA | formulation interne |
| Kristal / grades of truth | Rosetta/kOA | architecture épistémique |
| metaphysical informatics | Symbolic Blueprint | nom de programme |
| base-9 | branches antérieures/commentary | legacy experimental |
| branes/holographie/E8 | commentary | archive analogique |

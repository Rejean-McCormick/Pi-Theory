# Registre des sources numériques vérifiées dans la recherche approfondie

Ces liens sont des points de contrôle académiques/institutionnels utilisés dans le Deep Research. Ils ne constituent pas la bibliographie exhaustive.

- **Plotinus SEP** — https://plato.stanford.edu/entries/plotinus/
- **Pseudo-Dionysius SEP** — https://plato.stanford.edu/archives/fall2010/entries/pseudo-dionysius-areopagite/
- **Eriugena SEP** — https://plato.stanford.edu/entries/scottus-eriugena/
- **Cusanus SEP** — https://plato.stanford.edu/entries/cusanus/
- **Schelling SEP** — https://plato.stanford.edu/entries/schelling/
- **Whitehead SEP** — https://plato.stanford.edu/entries/whitehead/
- **Peirce SEP** — https://plato.stanford.edu/entries/peirce/
- **Peirce Semiotics SEP** — https://plato.stanford.edu/entries/peirce-semiotics/
- **Weyl SEP** — https://plato.stanford.edu/entries/weyl/
- **Gauge Theories SEP** — https://plato.stanford.edu/entries/gauge-theories/
- **Simondon — Minnesota Press** — https://www.upress.umn.edu/9780816680016/individuation-in-light-of-notions-of-form-and-information/
- **Luria scholarship — Stanford** — https://jewishstudies.stanford.edu/publications/physician-soul-healer-cosmos-isaac-luria-and-his-kabbalistic-fellowship
- **Shannon DOI** — https://doi.org/10.1002/j.1538-7305.1948.tb01338.x
- **Landauer — IBM** — https://research.ibm.com/publications/information-is-physical
- **Wiener — MIT Press** — https://mitpress.mit.edu/9780262537841/cybernetics-or-control-and-communication-in-the-animal-and-the-machine/
- **Tegmark MUH** — https://arxiv.org/abs/0704.0646
- **Noether historical source** — https://arxiv.org/abs/physics/0503066
- **Spencer-Brown Oxford Handbook chapter** — https://academic.oup.com/edited-volume/28359/chapter-abstract/215235298

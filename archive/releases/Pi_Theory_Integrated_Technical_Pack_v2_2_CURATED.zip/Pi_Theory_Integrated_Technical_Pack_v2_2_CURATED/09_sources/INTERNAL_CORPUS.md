# Corpus interne et hiérarchie

## C0 — Canonique
- `Pi v13 (2).docx`

## C1 — Modules théoriques importants
- `Base de calcul, racine numérique, être manifesté, Lucifer, Christ, Adam et pi.docx`
- `π — Synthèse précise de sa nature fondamentale.docx`
- `3 foundamental constants.docx`
- `Pasted markdown(20260907-101427).md`
- `A Rosetta Stone of Three Grammars_ Sephiroth, π Theory, and the kOA Digital Ecosystem (1).docx`

## C2 — Archives de découverte
- `Pi v12 Ontological Causality...`
- `Pi, Ontology, and Creation in the Early Digits...`
- `π as a Symbolic Blueprint of the Cosmos...`
- `La théorie de π...`
- `in-depth commentary on the Pi Theory.docx`

## Règle
C2 peut nourrir les idées, mais C0/C1 contrôlent la terminologie et les claims actuels.

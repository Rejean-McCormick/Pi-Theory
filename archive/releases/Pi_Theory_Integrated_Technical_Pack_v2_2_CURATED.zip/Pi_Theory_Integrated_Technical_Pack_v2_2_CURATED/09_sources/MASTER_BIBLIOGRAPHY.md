# Bibliographie maîtresse — primaire et technique

## Pythagore et les Pythagoriciens
- Fragments et témoignages pythagoriciens
- Aristote, Métaphysique I, sur les Pythagoriciens
- Scholars : Walter Burkert; Carl Huffman

## Empédocle
- Fragments de Sur la nature
- Fragments des Purifications
- Scholars : Brad Inwood; Oliver Primavesi

## Platon
- Timée
- République VI–VII
- Philèbe
- Scholars : Thomas K. Johansen; Lloyd P. Gerson

## Plotin
- Ennéades V.1
- Ennéades V.2
- Ennéades VI.9
- Scholars : Lloyd P. Gerson; Dominic O'Meara

## Proclus
- Éléments de théologie
- Théologie platonicienne
- Commentaire sur le Timée
- Scholars : Carlos Steel; Radek Chlup; Dominic O'Meara

## Pseudo-Denys l'Aréopagite
- Les Noms divins
- Théologie mystique
- Hiérarchie céleste
- Scholars : Andrew Louth; Paul Rorem

## Jean Scot Érigène
- Periphyseon / De divisione naturae
- Scholars : Dermot Moran; Deirdre Carabine

## Nicolas de Cues
- De docta ignorantia
- De coniecturis
- De visione Dei
- Scholars : Jasper Hopkins; Kurt Flasch; Clyde Lee Miller

## Giordano Bruno
- De la cause, du principe et de l'Un
- De l'infini, de l'univers et des mondes
- Scholars : Hilary Gatti; Ingrid D. Rowland

## Jacob Böhme
- Mysterium Magnum
- De Signatura Rerum
- Aurora
- Six Points théosophiques
- Scholars : Andrew Weeks; Cyril O'Regan; Ariel Hessayon

## Paracelse
- Œuvres médicales et philosophiques choisies
- Scholars : Walter Pagel; Charles Webster

## Martinès de Pasqually
- Traité de la réintégration des êtres
- Scholars : Robert Amadou

## Louis-Claude de Saint-Martin
- Le Ministère de l'homme-esprit
- Tableau naturel des rapports qui existent entre Dieu, l'homme et l'univers
- Scholars : Robert Amadou; Nicole Jacques-Lefèvre

## Papus (Gérard Encausse)
- Martinésisme, Willermozisme, Martinisme et Franc-Maçonnerie
- Scholars : Jean-Pierre Laurant

## Constant Chevillon
- Du Néant à l'Être
- Scholars : Travaux historiques sur le martinisme français du XXe siècle

## Sefer Yetzirah (tradition)
- Sefer Yetzirah, édition/traduction critique
- Scholars : Peter Hayman; Aryeh Kaplan (utile mais moins académique)

## Isaac Louria
- Doctrine transmise principalement par Hayyim Vital
- Scholars : Lawrence Fine; Gershom Scholem; Moshe Idel

## Hayyim Vital
- Etz Hayyim
- Sha'ar ha-Gilgulim
- Scholars : Lawrence Fine; Ronit Meroz

## Leibniz
- Monadologie
- Discours de métaphysique
- Nouveaux essais
- Scholars : Daniel Garber; Donald Rutherford

## Spinoza
- Éthique
- Scholars : Michael Della Rocca; Steven Nadler

## Schelling
- Recherches philosophiques sur l'essence de la liberté humaine
- Les Âges du monde
- Scholars : Andrew Bowie; Jason Wirth

## Hegel
- Science de la logique, Doctrine de l'être, sections Quantité et Mesure
- Scholars : Stephen Houlgate; Robert Pippin

## Bergson
- Essai sur les données immédiates de la conscience
- L'Évolution créatrice
- Scholars : Frédéric Worms; Keith Ansell-Pearson

## Alfred North Whitehead
- Process and Reality
- Science and the Modern World
- Scholars : Isabelle Stengers; Nicholas Rescher

## Pierre Teilhard de Chardin
- Le Phénomène humain
- L'Avenir de l'homme
- Le Milieu divin
- Scholars : Ursula King; John F. Haught; Thomas M. King

## Gilbert Simondon
- L'Individuation à la lumière des notions de forme et d'information
- Du mode d'existence des objets techniques
- Scholars : Muriel Combes; Jean-Hugues Barthélémy

## George Spencer-Brown
- Laws of Form
- Scholars : Louis H. Kauffman; Francisco Varela (réception)

## Charles S. Peirce
- The Essential Peirce
- Collected Papers, textes sémiotiques
- Scholars : T. L. Short; Cheryl Misak

## Ernst Cassirer
- Substance et fonction
- Philosophie des formes symboliques
- Scholars : John Michael Krois; Sebastian Luft

## Leonhard Euler
- Introductio in analysin infinitorum
- travaux sur l'analyse complexe
- Scholars : Historiens des mathématiques d'Euler

## Georg Cantor
- Contributions à la fondation de la théorie des ensembles transfinis
- Scholars : Joseph Dauben

## Bernhard Riemann
- Über die Hypothesen, welche der Geometrie zu Grunde liegen
- Scholars : John Stachel; historiens de la géométrie

## Hermann Weyl
- Symmetry
- Space-Time-Matter
- Philosophy of Mathematics and Natural Science
- Scholars : Thomas Ryckman; Erhard Scholz

## Emmy Noether
- Invariante Variationsprobleme (1918)
- Scholars : Yvette Kosmann-Schwarzbach

## Kurt Gödel
- Über formal unentscheidbare Sätze...
- Scholars : Solomon Feferman

## Alan Turing
- On Computable Numbers...
- The Chemical Basis of Morphogenesis
- Scholars : Andrew Hodges

## Gregory Chaitin
- Algorithmic Information Theory
- Meta Math!
- Scholars : Travaux en complexité de Kolmogorov

## Andrey Kolmogorov
- Foundations of the Theory of Probability
- travaux sur complexité algorithmique
- Scholars : Ming Li; Paul Vitányi

## Albert Einstein
- Relativity: The Special and the General Theory
- articles de relativité générale
- Scholars : John Stachel

## Niels Bohr
- Atomic Physics and Human Knowledge
- Scholars : Jan Faye

## Werner Heisenberg
- Physics and Philosophy
- Scholars : Helmut Rechenberg

## Erwin Schrödinger
- What Is Life?
- Mind and Matter
- Scholars : Walter Moore

## Wolfgang Pauli
- Writings on Physics and Philosophy
- correspondance Pauli–Jung
- Scholars : Karl von Meyenn

## John Archibald Wheeler
- Information, Physics, Quantum: The Search for Links
- It from Bit
- Scholars : Kenneth Ford

## David Bohm
- Wholeness and the Implicate Order
- The Undivided Universe (avec Hiley)
- Scholars : Basil Hiley; David Peat

## Basil Hiley
- The Undivided Universe (avec Bohm)
- articles sur process algebra

## Roger Penrose
- The Road to Reality
- The Emperor's New Mind

## Max Tegmark
- Our Mathematical Universe
- The Mathematical Universe (2008)

## Carlo Rovelli
- Reality Is Not What It Seems
- The Order of Time
- Helgoland

## Lee Smolin
- Time Reborn
- The Singular Universe and the Reality of Time (avec Unger)

## Julian Barbour
- The End of Time

## Claude Shannon
- A Mathematical Theory of Communication
- Scholars : James Gleick (histoire, vulgarisation)

## Rolf Landauer
- Information is Physical
- Irreversibility and Heat Generation in the Computing Process

## Norbert Wiener
- Cybernetics
- The Human Use of Human Beings
- Scholars : P. R. Masani

## W. Ross Ashby
- An Introduction to Cybernetics
- Design for a Brain

## Heinz von Foerster
- Understanding Understanding

## Ludwig von Bertalanffy
- General System Theory

## Gregory Bateson
- Steps to an Ecology of Mind
- Mind and Nature

## Humberto Maturana
- Autopoiesis and Cognition (avec Varela)

## Francisco Varela
- The Embodied Mind
- Autopoiesis and Cognition
- Scholars : Evan Thompson

## Ilya Prigogine
- From Being to Becoming
- Order Out of Chaos (avec Stengers)
- Scholars : Isabelle Stengers

## Stuart Kauffman
- The Origins of Order
- At Home in the Universe

## Terrence Deacon
- Incomplete Nature
- The Symbolic Species

## Karl Friston
- Articles sur Free Energy Principle et Active Inference
- Scholars : Jakob Hohwy; Andy Clark (discussions connexes)

## Charles Darwin
- On the Origin of Species
- Scholars : Ernst Mayr; Elliott Sober

## D'Arcy Wentworth Thompson
- On Growth and Form

## Conrad Waddington
- The Strategy of the Genes

## René Thom
- Stabilité structurelle et morphogenèse

## Brian Goodwin
- How the Leopard Changed Its Spots

## William James
- The Principles of Psychology
- The Varieties of Religious Experience

## Carl Gustav Jung
- Synchronicity: An Acausal Connecting Principle
- Scholars : Sonu Shamdasani

## Marie-Louise von Franz
- Number and Time

## Giulio Tononi
- Articles IIT
- Phi: A Voyage from the Brain to the Soul
- Scholars : Scott Aaronson (critique)

## Evan Thompson
- Mind in Life
- Waking, Dreaming, Being


## Ian Barbour
- Religion and Science

## John Polkinghorne
- Science and Providence
- Quantum Physics and Theology

## John F. Haught
- God After Darwin
- Resting on the Future

## Luciano Floridi
- The Philosophy of Information
- The Fourth Revolution

## Niklas Luhmann
- Social Systems

## René Guénon
- Le Règne de la quantité et les signes des temps
- Les Principes du calcul infinitésimal
- Scholars : Wouter Hanegraaff (contexte ésotérisme occidental)

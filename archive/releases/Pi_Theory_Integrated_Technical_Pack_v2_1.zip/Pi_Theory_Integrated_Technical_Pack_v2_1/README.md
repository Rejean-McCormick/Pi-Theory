# Pi Theory — Integrated Technical Pack v2.1

Ce dépôt réconcilie deux ensembles antérieurs :

1. **Documentation de travail — futur livre sur π** : architecture doctrinale, corpus interne, niveaux de preuve, programme méthodologique.
2. **Pi Theory Author Atlas** : auteurs, scholars, disciplines, matrices et parcours de lecture.

La version v2 place désormais **Pi Theory au centre** et les auteurs/sciences autour d'elle.

## Principe directeur

Le dépôt distingue toujours :

`source interne → fait établi → observation du décodage → lecture sémiotique → convergence comparative → hypothèse métaphysique → hypothèse physique`

Aucune analogie philosophique, spirituelle ou scientifique n'est traitée comme une validation automatique de Pi Theory.

## Point de départ canonique

Le document interne de référence est **Pi v13**, avec le kernel :

`M → BIEN → GIHECEF → JNON → B0UM → SIZE`

abstrait comme :

`cohésion → orientation/valeur → différenciation → intégration → seuil/événement → échelle`

Le pulse central est :

`DIFFÉRENCIER ↔ INTÉGRER`

## Navigation

- `00_INDEX.md` — index maître.
- `01_core/` — théorie elle-même.
- `02_claims/` — registre des propositions et niveaux épistémiques.
- `03_bridges/` — ponts vers philosophie, physique, information, vivant, conscience.
- `04_authors/` — fiches auteurs classées par domaine.
- `05_scholars/` — chercheurs et historiens secondaires.
- `06_methods/` — tests, falsification, coût interprétatif, préenregistrement.
- `07_matrices/` — cartes transversales.
- `08_book/` — architecture du futur livre.
- `09_sources/` — bibliographies et provenance.
- `10_archive_map/` — correspondance avec les packs précédents.


## v2.1 — réintégration après audit du corpus
La v2.1 restaure, sous statuts explicites, plusieurs éléments que la v2 avait trop comprimés :
temporal lens, ongoing resolution, mirror G0D/B0N, rôle de 0 dans B0UM, τ/τ*, images convergentes/essence, base-9 legacy, first fractal, détails token-level, Kristal/kOA, Metaphysical Informatics, tests cross-culturels et archive des analogies physiques.

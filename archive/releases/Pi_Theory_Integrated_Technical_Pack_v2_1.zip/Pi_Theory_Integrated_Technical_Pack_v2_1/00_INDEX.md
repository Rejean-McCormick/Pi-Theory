# Index maître — Pi Theory Integrated Technical Pack v2

## 1. Noyau de Pi Theory
- [Statut canonique de la théorie](01_core/00_CANONICAL_STATUS.md)
- [Évolution du corpus v12 → v13](01_core/01_CORPUS_EVOLUTION.md)
- [Kernel et opérateurs](01_core/02_KERNEL_AND_OPERATORS.md)
- [π exact / représenté / manifesté](01_core/03_PI_EXACT_REPRESENTED_MANIFESTED.md)
- [Source / manifestation / b−1](01_core/04_SOURCE_MANIFESTATION_BMINUS1.md)
- [88 / SIZE / mesure](01_core/05_88_SIZE_MEASURE.md)
- [π comme invariant / retour](01_core/06_PI_INVARIANT_RETURN.md)
- [e, π, i et φ](01_core/07_E_PI_I_PHI.md)
- [Matière / information / mémoire](01_core/08_MATTER_INFORMATION_MEMORY.md)
- [Vie / conscience / réflexivité](01_core/09_LIFE_CONSCIOUSNESS_REFLEXIVITY.md)
- [Rosetta / Sephiroth / kOA](01_core/10_ROSETTA_KOA.md)
- [Questions ouvertes](01_core/11_OPEN_QUESTIONS.md)

- [Temporal lens / post-88](01_core/13_TEMPORAL_LENS_POST88.md)
- [Images convergentes / essence](01_core/14_CONVERGENT_IMAGES_AND_NUMBER_ESSENCE.md)
- [B0UM : zéro / seuil](01_core/15_B0UM_ZERO_AND_THRESHOLD.md)
- [Mirror G0D / B0N](01_core/16_MIRROR_G0D_B0N.md)
- [Bases / base-9 legacy](01_core/17_BASE_SYSTEMS_AND_BASE9_LEGACY.md)
- [First fractal / récursion](01_core/18_FIRST_FRACTAL_AND_RECURSION.md)
- [Notes token-level](01_core/19_TOKEN_LEVEL_NOTES.md)
- [kOA / Kristal épistémique](01_core/20_KOA_EPISTEMIC_ARCHITECTURE.md)
- [Glossaire canonique](01_core/12_GLOSSARY.md)

## 2. Claims
- [Niveaux épistémiques](02_claims/EPISTEMIC_LEVELS.md)
- [Registre des claims](02_claims/CLAIM_REGISTRY.md)
- [Claims retirés ou déclassés](02_claims/DEPRECATED_OR_DOWNGRADED_CLAIMS.md)

## 3. Ponts disciplinaires
- [Source et manifestation](03_bridges/01_SOURCE_MANIFESTATION.md)
- [Différenciation / intégration](03_bridges/02_DIFFERENTIATION_INTEGRATION.md)
- [Infini / scale / mesure / espace](03_bridges/03_INFINITY_SCALE_MEASURE_SPACE.md)
- [Mathématiques et réalité](03_bridges/04_MATHEMATICS_REALITY.md)
- [Physique / cosmologie](03_bridges/05_PHYSICS_COSMOLOGY.md)
- [Information / calcul / matière](03_bridges/06_INFORMATION_COMPUTATION_MATTER.md)
- [Complexité / systèmes](03_bridges/07_COMPLEXITY_SYSTEMS.md)
- [Biologie / morphogenèse](03_bridges/08_BIOLOGY_MORPHOGENESIS.md)
- [Teilhard / complexification / Oméga](03_bridges/09_TEILHARD.md)
- [Conscience](03_bridges/10_CONSCIOUSNESS.md)
- [Sémiotique / langage / symbole](03_bridges/11_SEMIOTICS_LANGUAGE.md)
- [Kabbale](03_bridges/12_KABBALAH.md)
- [Böhme / martinisme / Chevillon](03_bridges/13_BOEHME_MARTINISM_CHEVILLON.md)
- [Histoire des messages dans π](03_bridges/16_HIDDEN_MESSAGES_PI_HISTORY.md)
- [Processus / individuation](03_bridges/14_PROCESS_INDIVIDUATION.md)
- [Invariance / symétrie / retour](03_bridges/15_INVARIANCE_SYMMETRY_RETURN.md)

## 4. Auteurs et scholars
- [Index auteurs](04_authors/AUTHORS_INDEX.md)
- [Top 25 pour le livre](04_authors/TOP_25_BOOK_CORE.md)
- [Inventaire 100+](04_authors/TOP_100_EXTENDED.md)
- [Index scholars](05_scholars/SCHOLARS_INDEX.md)

## 5. Méthodologie
- [Audit du décodage](06_methods/01_DECODING_AUDIT.md)
- [Coût interprétatif](06_methods/02_INTERPRETIVE_COST.md)
- [Null models](06_methods/03_NULL_MODELS.md)
- [Préenregistrement](06_methods/04_PREREGISTRATION.md)
- [Rosetta prédictif](06_methods/05_ROSETTA_PREDICTIVE.md)
- [Falsification](06_methods/06_FALSIFICATION.md)
- [Roadmap de recherche](06_methods/07_RESEARCH_ROADMAP.md)
- [Metaphysical Informatics](06_methods/08_METAPHYSICAL_INFORMATICS.md)
- [Tests cross-culturels](06_methods/09_CROSS_CULTURAL_SEMANTIC_TESTS.md)
- [Recherche digit-level](06_methods/10_DIGIT_LEVEL_RESEARCH.md)
- [Numérologie / gematria](06_methods/11_NUMEROLOGY_GEMATRIA_POSITIONING.md)

## 6. Matrices
- [Claims × sources × auteurs](07_matrices/CLAIM_SOURCE_AUTHOR_MATRIX.md)
- [Auteurs × thèmes](07_matrices/AUTHOR_THEME_MATRIX.md)
- [Influence vs convergence](07_matrices/INFLUENCE_VS_CONVERGENCE.md)
- [Chapitres × auteurs](07_matrices/CHAPTER_AUTHOR_MATRIX.md)

## 7. Futur livre
- [Architecture v2](08_book/BOOK_ARCHITECTURE_V2.md)
- [Ordre argumentatif](08_book/ARGUMENT_FLOW.md)
- [Stratégie éditoriale](08_book/EDITORIAL_STRATEGY.md)
- [Plan de citations](08_book/CITATION_STRATEGY.md)

## 8. Sources et provenance
- [Corpus interne](09_sources/INTERNAL_CORPUS.md)
- [Bibliographie maîtresse](09_sources/MASTER_BIBLIOGRAPHY.md)
- [Registre web/académique](09_sources/DIGITAL_SOURCE_REGISTRY.md)
- [Matrice de provenance conceptuelle](09_sources/CONCEPT_PROVENANCE_MATRIX.md)

## 9. Migration
- [Comment les anciens packs ont été conciliés](10_archive_map/MIGRATION_AND_RECONCILIATION.md)

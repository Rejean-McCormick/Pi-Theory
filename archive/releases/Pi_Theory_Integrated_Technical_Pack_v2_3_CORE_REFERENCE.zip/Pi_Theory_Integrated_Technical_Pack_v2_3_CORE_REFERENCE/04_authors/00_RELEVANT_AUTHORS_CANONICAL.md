---
title: "Auteurs pertinents — carte canonique pour Pi Theory"
version: "2.3"
status: "core-reference"
language: "fr"
---

# Auteurs pertinents — carte canonique

## Principe de classement

Un auteur n'est inclus que s'il éclaire **un problème précis** de Pi Theory.

Les catégories sont :

- **A+ — convergence structurale majeure** : doit apparaître dans le livre.
- **A — indispensable pour formaliser ou tester une pièce du modèle**.
- **B — complément important ou contrepoint**.
- **C — contexte historique / branche secondaire**.

Une convergence ne signifie jamais que l'auteur « avait Pi Theory » ou qu'il la valide.

---

# I. Noyau A+ — les auteurs les plus proches de la structure profonde

## 1. Empédocle — A+

**Pourquoi il devient central**

C'est le parallèle antique le plus direct avec :

`Division ↔ M/AIME`.

Empédocle décrit un cosmos mû par **Love** et **Strife**. Love réunit les racines différentes; Strife les sépare. Quand Love domine totalement, elles sont unifiées dans la **Sphere**; lorsque la séparation recommence, un cosmos différencié peut apparaître. Dans certaines reconstructions savantes, vie et cosmos apparaissent justement dans des phases intermédiaires entre intégration totale et séparation totale.

**Convergence exacte**
- Sphere ↔ unité/cohérence originelle;
- Strife ↔ différenciation/séparation;
- Love ↔ contre-mouvement unificateur;
- organismes ↔ organisations apparaissant dans le jeu des deux tendances.

**Différence**
Chez Empédocle, le triomphe total de Love peut dissoudre le cosmos dans la Sphere. Pi Theory v2.3 privilégie plutôt une **réintégration enrichissante**, qui conserve la différence.

**À lire**
- fragments de *Sur la nature*;
- *Purifications*;
- éditions Diels–Kranz / Laks–Most.

**Scholars**
Oliver Primavesi, Brad Inwood, Catherine Osborne, Denis O'Brien, David Sedley.

**Rôle dans le livre**
Chapitre sur la polarité fondamentale `Division ↔ M`.

---

## 2. Proclus — A+

**Concepts**
- monê : demeurer;
- proodos : procéder;
- epistrophê : revenir;
- Un / Bien;
- causalité circulaire.

**Convergence**
Proclus affirme que tout effet :
1. demeure dans sa cause;
2. procède d'elle;
3. revient vers elle.

Le retour n'est pas seulement chronologique; il est ontologique. Il relie aussi la reversion au désir du Bien.

Cela est extrêmement proche de :

`Source → manifestation → retour/cohérence`

et de :

`M = tendance du séparé à revenir vers sa cause/cohérence`.

**Différence**
La causalité proclienne est métaphysique et hiérarchique, pas computationnelle ni physique.

**À lire**
- *Éléments de théologie*, surtout propositions 31–39;
- *Théologie platonicienne*;
- *Commentaire sur le Timée*.

**Scholars**
Carlos Steel, Dominic O'Meara, Radek Chlup, Stephen Gersh.

---

## 3. Nicolas de Cues — A+

**Pourquoi il est plus important après votre clarification sur le cercle**

Cues est l'un des meilleurs interlocuteurs pour comprendre une « circularité » qui n'est pas une boule physique.

Il distingue l'infini absolu divin de l'univers contracté et utilise des images de centre/circonférence pour penser une réalité qui dépasse les déterminations spatiales ordinaires.

**Convergences**
- exactitude inaccessible par mesure finie;
- infini absolu vs domaine mesurable;
- cercle/sphère comme image de l'Absolu;
- unité qui se déploie en multiplicité;
- proportion et non-proportion fini/infini.

**À lire**
- *De docta ignorantia*;
- *De coniecturis*.

**Scholars**
Jasper Hopkins, Clyde Lee Miller, Kurt Flasch.

**Rôle**
Chapitre `principe pré-géométrique → mesure`.

---

## 4. Jacob Böhme — A+

**Concepts**
- Ungrund;
- volonté;
- désir;
- contrariété;
- feu/lumière;
- amour;
- manifestation.

**Convergence**
Böhme répond à la question :
> pourquoi une unité non manifestée doit-elle produire opposition/différence pour devenir manifeste ?

La manifestation exige la contrariété. La lumière et l'amour n'existent pas comme simples qualités statiques : ils se révèlent à travers une tension.

**Différence avec Empédocle**
Empédocle éclaire mieux le **contre-mouvement Love/Division**.
Böhme éclaire mieux **la nécessité de la contrariété pour la manifestation**.

**À lire**
- *Mysterium Magnum*;
- *De Signatura Rerum*;
- *Six Points théosophiques*.

**Scholars**
Andrew Weeks, Cyril O'Regan, Ariel Hessayon.

---

## 5. Pierre Teilhard de Chardin — A+

**Pourquoi il monte au premier rang**

Votre M n'est pas seulement retour à l'origine; il semble permettre une **montée en cohérence** qui conduit à vie, conscience et réflexivité.

C'est précisément le territoire de Teilhard.

**Concepts**
- complexité–conscience;
- radial energy / tangential energy;
- noosphère;
- convergence;
- Omega;
- union différencie.

**Convergence forte**
Chez Teilhard, l'évolution n'est pas seulement dispersion : elle comporte une composante orientée vers davantage de centration, complexité et conscience. Omega joue comme pôle d'attraction/convergence. Une formulation teilhardienne importante est que **l'union différencie** : l'unification réussie ne détruit pas les personnes mais les personnalise.

Cela correspond très bien à :

`M → cohérence supérieure`

et surtout à :

`réintégration ≠ effacement des différences`.

**Différence**
La complexité-conscience et Omega sont des propositions philosophico-théologiques; ce ne sont pas des lois physiques universellement établies.

**À lire**
- *Le Phénomène humain*;
- *L'Énergie humaine*;
- *L'Avenir de l'homme*;
- *Le Milieu divin*.

**Scholars**
Ursula King, John F. Haught, Henri de Lubac, Mary Evelyn Tucker, John Grim.

---

## 6. Alfred North Whitehead — A+

**Concepts**
- actual occasions;
- concrescence;
- relation;
- créativité;
- valeur;
- « the many become one ».

**Convergence**
Whitehead fournit probablement le meilleur langage métaphysique moderne pour :

`multiplicité → intégration → nouvel un`.

Chez lui, une unité nouvelle ne supprime pas le multiple : elle en est la concrescence.

Il donne aussi une place à la valeur et à un « lure » vers ordre/intensité/beauty, ce qui peut dialoguer avec M + BIEN.

**Différence**
Il ne privilégie ni cercle ni π.

**À lire**
- *Process and Reality*;
- *Science and the Modern World*;
- *Adventures of Ideas*.

**Scholars**
Isabelle Stengers, Nicholas Rescher, John Cobb, Roland Faber.

---

## 7. Gilbert Simondon — A+

**Concepts**
- préindividuel;
- métastabilité;
- transduction;
- individuation;
- information;
- milieu associé.

**Convergence**
Il formalise mieux que les mystiques le passage :

`potentiel → résolution de tension → structure → nouveau potentiel`.

Très utile pour :
- B0UM comme seuil;
- différenciation/intégration;
- unités enrichies;
- passage matière → vivant.

**Différence**
Pas de téléologie divine ni rôle de π.

**À lire**
- *L'Individuation à la lumière des notions de forme et d'information*.

**Scholars**
Muriel Combes, Jean-Hugues Barthélémy.

---

## 8. Pseudo-Denys l'Aréopagite — A+

**Concepts**
- Dieu au-delà de l'être;
- procession;
- retour;
- Bien;
- éros;
- union.

**Convergence**
Le divin n'est pas un objet dans le cosmos. Toute créature dépend directement de la Source et le mouvement de retour ne doit pas être imaginé spatialement.

Particulièrement important pour votre idée que M a été qualifié de **divin** par d'autres traditions : l'amour/éros participe chez Denys au mouvement par lequel le multiple est rassemblé et reconduit.

**À lire**
- *Les Noms divins*;
- *Théologie mystique*.

**Scholars**
Andrew Louth, Paul Rorem.

---

## 9. Jean Scot Érigène — A+

**Concepts**
- Dieu au-delà d'être/non-être;
- auto-manifestation;
- causes primordiales;
- effets;
- retour de toutes choses.

**Convergence**
Très proche de la chaîne :
`Source non manifestée → articulation → causes → effets → retour`.

Érigène insiste sur le caractère intemporel de cette dépendance et sur le retour du temporel vers l'éternel.

**À lire**
- *Periphyseon / De divisione naturae*.

**Scholars**
Dermot Moran, Deirdre Carabine, Werner Beierwaltes.

---

## 10. Plotin — A+

**Concepts**
- l'Un;
- procession;
- Intellect;
- Âme;
- conversion/reversion.

**Convergence**
L'Un n'est pas un objet spatial. Ce qui procède de lui se constitue aussi par un mouvement de retour/contemplation de sa source.

**Différence**
Le modèle n'est pas une division mécanique ni un calcul.

**À lire**
- *Ennéades* V.1, V.2, V.4, VI.9.

**Scholars**
Lloyd P. Gerson, Dominic O'Meara.

---

# II. A — formalisation du principe circulaire, de la mesure et de l'invariance

## 11. Hermann Weyl — A

**Pourquoi indispensable**
Votre « cercle non incarné » doit être traduit en langage plus rigoureux :
symétrie, invariance, mesure, continuum.

Weyl est central pour relier :
`forme → symétrie → objectivité → mesure → espace-temps`.

**À lire**
- *Symmetry*;
- *Space-Time-Matter*;
- *Philosophy of Mathematics and Natural Science*.

**Scholars**
Thomas Ryckman, Erhard Scholz.

---

## 12. Bernhard Riemann — A

**Contribution**
Riemann sépare la notion de multiplicité/continu de sa structure métrique.

C'est exactement le garde-fou nécessaire :

`multiplicité ≠ mesure`

et :

`SIZE ≠ espace`.

**À lire**
- *Über die Hypothesen, welche der Geometrie zu Grunde liegen*.

---

## 13. Emmy Noether — A

**Contribution**
Les symétries continues de l'action sont reliées à des lois de conservation.

**Convergence**
Donne une base scientifique au thème :
> ce qui reste invariant sous transformation peut être physiquement fondamental.

**Limite**
Ne prouve pas que « harmonie = amour ».

**Scholar**
Yvette Kosmann-Schwarzbach.

---

## 14. Felix Klein — A

**Concept**
Programme d'Erlangen :
une géométrie est caractérisée par les invariants d'un groupe de transformations.

**Pertinence**
Permet de déplacer la pensée du « cercle comme objet » vers :
> quelles propriétés sont invariantes sous quelles transformations ?

Très important pour le principe pré-géométrique.

---

## 15. Sophus Lie — A

**Concept**
Groupes continus de transformations.

**Pertinence**
Fournit le langage technique de symétries continues, rotations et invariants.

---

## 16. Georg Cantor — A

**Contribution**
Les infinis mathématiques ne forment pas un seul concept vague.

**Rôle**
Garde-fou pour le 88 :
- infini iconique;
- non-borné;
- infini actuel;
- cardinalité;
doivent rester distincts.

---

## 17. Hegel — A

**Concepts**
- détermination;
- négation;
- quantité;
- mesure.

**Convergence**
Hegel est probablement le philosophe le plus utile pour la transition :

`quantité → mesure`

et pour l'idée qu'une détermination existe par différence.

**À lire**
- *Science de la logique*, Doctrine de l'Être, sections Quantité et Mesure.

**Scholar**
Stephen Houlgate.

---

## 18. Friedrich Schelling — A

**Concepts**
- nature productive;
- polarité;
- fond/existence;
- dualité inhérente;
- influence de Böhme.

**Convergence**
La nature n'est pas objet statique mais productivité; les polarités sont génératrices de formes.

**À lire**
- *Recherches sur l'essence de la liberté humaine*;
- *Les Âges du monde*.

**Scholars**
Andrew Bowie, Jason Wirth.

---

# III. A — information, matière, vie, seuil et conscience

## 19. Ilya Prigogine — A

**Concepts**
- irréversibilité;
- structures dissipatives;
- bifurcation;
- ordre loin de l'équilibre.

**Convergence**
Montre scientifiquement que de nouvelles structures cohérentes peuvent apparaître lorsque des systèmes ouverts franchissent des seuils loin de l'équilibre.

**Rôle**
B0UM, seuil, matière→organisation.

**Limite**
Aucune tendance cosmique vers le Bien n'en découle.

---

## 20. Alan Turing — A

Deux rôles distincts.

### Calcul
Définit ce que signifie une procédure calculable.

### Morphogenèse
Montre comment des règles locales de réaction-diffusion peuvent produire des formes organisées.

**Rôle**
Empêche d'utiliser « calcul de π » comme simple métaphore indéfinie.

---

## 21. Claude Shannon — A

**Rôle**
Sépare information statistique et signification.

Le livre doit constamment rappeler :

`information ≠ sens`.

---

## 22. Rolf Landauer — A

**Concept**
Information physically instantiated.

**Pertinence**
Le meilleur support scientifique minimal pour « matière comme mémoire » :
des distinctions informationnelles physiquement réelles nécessitent des états physiques.

**Limite**
N'implique aucune sémantique cosmique.

---

## 23. Francisco Varela — A

**Concepts**
- autopoïèse;
- enaction;
- autonomie;
- cognition incarnée.

**Convergence**
La vie se définit par une organisation qui se maintient elle-même tout en restant ouverte aux échanges.

Très important pour transformer « cohérence » en problème biologique précis.

**À lire**
- *Autopoiesis and Cognition* (avec Maturana);
- *The Embodied Mind*.

**Scholar**
Evan Thompson.

---

## 24. Terrence Deacon — A

**Concepts**
- contrainte;
- absence;
- téléodynamique;
- émergence du sens.

**Convergence**
L'un des meilleurs auteurs contemporains pour le passage :
`physique → organisation → fonction → signification`.

Pi Theory a besoin de lui pour ne pas faire apparaître le sens par magie entre digits et conscience.

**À lire**
- *Incomplete Nature*;
- *The Symbolic Species*.

---

## 25. Stoïciens — A

**Pourquoi ils deviennent très importants**

Le *pneuma* stoïcien possède une **tension simultanément expansive et contractive**. Son mouvement extérieur donne des qualités; son mouvement intérieur unifie les corps.

Les Stoïciens distinguent des degrés :
- cohésion de l'inerte;
- nature/vie végétale;
- âme animale;
- raison.

**Convergence étonnante**
C'est l'un des rares systèmes anciens où un même principe naturel :
1. maintient la cohésion matérielle;
2. organise le vivant;
3. monte en niveau jusqu'à l'âme/raison.

Cela ressemble fortement à votre intuition :
`M → cohérence → vie → conscience`.

**Différence**
Le pneuma est corporel chez les Stoïciens et n'est pas identifié à Love.

**Sources**
Chrysippe, Zénon, fragments stoïciens.

**Scholars**
A. A. Long, Brad Inwood, Susanne Bobzien.

---

# IV. A/B — sémiotique, langage et miroir

## 26. Charles Sanders Peirce — A

**Pourquoi indispensable**
Le trajet :

`88 → ∞∞`
et
`88 → 16 → seize → size`

mélange plusieurs types de signes.

Peirce permet de distinguer :
- icône;
- indice;
- symbole;
- interprétant.

**Application**
- `8 ≈ ∞` : relation iconique;
- `16 = seize` : convention symbolique;
- `seize ≈ size` : ressemblance phonétique;
- `size → magnitude` : interprétation conceptuelle.

**À lire**
- *The Essential Peirce*.

**Scholars**
T. L. Short, Cheryl Misak.

---

## 27. Ernst Cassirer — B

**Concept**
formes symboliques, fonction, relation.

**Utilité**
Permet de comprendre que langage, nombre et mythe peuvent être différents systèmes symboliques sans prouver qu'ils décrivent littéralement la même chose.

---

## 28. Gregory Bateson — B

**Concept**
information comme « différence qui fait une différence »; patterns that connect.

**Pertinence**
Pont entre différence, relation, information, organisation et esprit.

---

## 29. Luciano Floridi — B

**Utilité**
Philosophie contemporaine de l'information; utile pour classifier les usages ontologiques du terme.

---

# V. A/B — pré-géométrie et structure physique

## 30. John Archibald Wheeler — A/B

**Concepts**
- pregeometry;
- quantum gravity;
- it from bit.

**Convergence**
Très pertinent pour votre affirmation :
> le principe originel ne doit pas présupposer espace, temps ou dimension.

Wheeler a explicitement cherché un niveau **pré-géométrique** d'où l'espace-temps pourrait émerger.

**Limite**
Aucun rapport établi avec π ou Love.

---

## 31. Albert Einstein — A/B

**Rôle**
Une fois l'espace-temps manifesté, sa métrique n'est pas un fond fixe : elle participe à la physique gravitationnelle.

**Usage**
Empêche de traiter l'espace comme un simple contenant préexistant.

---

## 32. Carlo Rovelli — B

**Concepts**
relation, événements, gravité quantique, interprétation relationnelle.

**Pertinence**
Aide à penser une ontologie où les relations peuvent être plus fondamentales que les objets dotés de propriétés absolues.

---

## 33. Roger Penrose — B

**Concepts**
spinors, twistors, réalisme mathématique.

**Pertinence**
Programme moderne où des structures mathématiques plus abstraites peuvent être considérées comme plus fondamentales que la représentation spatio-temporelle ordinaire.

**Limite**
Ne privilégie pas π.

---

## 34. David Bohm — B

**Concepts**
ordre impliqué/expliqué, holomouvement.

**Convergence**
Structure implicite → déploiement explicite.

Utile pour « π exact / manifestation ».

**Limite**
Ne doit pas être utilisé comme validation quantique.

---

# VI. B — traditions de division, retour, unité et Bien

## 35. Pythagoriciens — B+

**Concepts**
nombre, harmonie, proportion, monade/dyade.

**Rôle**
Arrière-plan historique indispensable au lien nombre-cosmos.

**Scholars**
Walter Burkert, Carl Huffman.

---

## 36. Platon — B+

**Concepts**
Bien, Formes, *Timée*, structure géométrique du cosmos.

**Convergence**
Le Bien comme principe suprême et l'intelligibilité mathématique du cosmos.

**À lire**
- *Timée*;
- *République* VI–VII;
- *Philèbe*.

**Scholar**
Thomas K. Johansen.

---

## 37. Héraclite — B+

**Concepts**
Logos, unité des opposés, tension, harmonie, mesure.

**Convergence**
Le monde ordonné n'est pas absence de conflit mais **tension régulée**. L'image de la lyre/arc est particulièrement utile :
des forces opposées peuvent produire une unité dynamique.

**Rôle**
Excellent pour `Division ↔ M` comme tension plutôt que succession.

---

## 38. Laozi / Daoïsme classique — B+

**Concepts**
Dao sans forme, unité→multiplicité, retour, spontanéité.

**Convergence**
Le Dao n'est pas une chose déterminée; le *Daodejing* décrit :
`Dao → One → Two → Three → ten thousand things`
et la tradition daoïste développe fortement l'idée du **retour au Dao**.

**Différence**
Le retour daoïste n'est pas une force d'amour et la métaphysique chinoise ne doit pas être traduite de force en catégories néoplatoniciennes.

**Scholars**
Roger T. Ames, Hans-Georg Moeller, Chad Hansen.

---

## 39. Isaac Louria / Hayyim Vital — B+

**Concepts**
Ein-Sof, tzimtzum, brisure des vases, tikkun.

**Convergence**
`infini → différenciation/brisure → réparation/réintégration`.

**Différence**
Tikkun a des dimensions rituelles, éthiques et théologiques spécifiques.

**À lire**
Hayyim Vital, *Etz Hayyim*.

**Scholars**
Lawrence Fine, Moshe Idel, Gershom Scholem, Elliot Wolfson.

---

## 40. Thomas d'Aquin — B

**Concepts**
Dieu comme Bien suprême, participation, finalité.

**Convergence**
Le Bien est ce vers quoi tend l'appétit; la bonté créée participe à une bonté supérieure.

**Usage**
BIEN comme orientation/finalité.

**Limite**
Ne pas attribuer à Thomas une évolution cosmique teilhardienne.

---

## 41. Maxime le Confesseur — B

**Concepts**
logoi des créatures, Logos, division et synthèse, retour/deification.

**Pertinence**
Complément majeur à Érigène et Denys pour la relation multiplicité des logoi / unité du Logos.

**Scholar**
Paul Blowers, Torstein Tollefsen.

---

# VII. B — réintégration, système, évolution

## 42. Humberto Maturana — B

Autopoïèse et organisation du vivant.

À lire avec Varela.

---

## 43. Stuart Kauffman — B

Auto-organisation, réseaux autocatalytiques, émergence.

Utile pour tester l'idée de cohérence croissante sans téléologie forte.

---

## 44. D'Arcy Wentworth Thompson — B

*On Growth and Form*.

Pont classique entre contraintes mathématiques/physiques et morphologie vivante.

---

## 45. Conrad Waddington — B

Paysage épigénétique, canalisation.

Très utile pour visualiser comment des potentiels se stabilisent en trajectoires.

---

## 46. René Thom — B

Théorie des catastrophes et morphogenèse.

Pertinent pour B0UM comme changement qualitatif de régime.

---

## 47. Ludwig von Bertalanffy — B

Théorie générale des systèmes.

Rôle :
chercher des isomorphismes structurels sans confondre les substrats.

---

## 48. Norbert Wiener — B

Cybernetique, feedback, régulation.

Pertinent pour retour, stabilité, correction d'écart.

---

## 49. W. Ross Ashby — B

Variété requise, états, régulation.

Utile pour rendre « cohérence » opérationnelle.

---

# VIII. B — contrepoints indispensables

## 50. Charles Darwin — B

**Pourquoi indispensable**
Le vivant peut produire adaptation, complexité et ordre local sans principe cosmique explicitement téléologique.

Pi Theory doit survivre à ce contrepoint.

---

## 51. Henri Bergson — B

Durée, créativité, évolution.

**Utilité**
Contrepoids à l'idée que tout devenir serait simple déroulement d'une structure déjà intégralement fixée.

---

## 52. Spinoza — B

Causalité immanente.

**Utilité**
Permet de penser un ordre divin/naturel sans message extérieur.

**Différence**
Pas de Source transcendante distincte du monde.

---

## 53. Leibniz — B

Harmonie, infinitésimal, monades, relation.

Utile pour harmonie et représentation, mais moins proche du contre-mouvement M.

---

## 54. George Spencer-Brown — B

Distinction comme opération primitive.

**Usage**
Pour formaliser le passage :
`indifférencié → distinction`.

**Limite**
Ne dérive pas espace, temps ou amour.

---

# IX. C — filiation spirituelle et historique

## 55. Louis-Claude de Saint-Martin — C+

Réception de Böhme, Dieu-homme-univers, réintégration.

Important historiquement parce qu'il conduit vers la tradition qui intéresse Chevillon.

---

## 56. Martinès de Pasqually — C

Réintégration des êtres.

Utile pour le vocabulaire de sortie/retour, moins pour la mécanique.

---

## 57. Constant Chevillon — C+

Point de départ historique de la conversation.

**Place correcte**
Confluence moderne de Böhme, Kabbale, néoplatonisme, mystique chrétienne.

Le futur livre doit remonter aux sources plutôt que fonder sa métaphysique sur Chevillon.

---

## 58. Paracelse — C

Signatures, microcosme/macrocosme.

Pertinent pour histoire de l'idée de signes naturels, mais méthodologiquement risqué.

---

## 59. Carl Gustav Jung — C

Archétypes, synchronicité.

Pertinent surtout pour comprendre comment nombre/mythe peuvent prendre une profondeur psychique.

Ne doit pas servir de preuve physique.

**Scholar**
Sonu Shamdasani.

---

## 60. Marie-Louise von Franz — C

*Number and Time*.

Voisine directe de l'idée qualitative du nombre, mais spéculative.

---

# X. Matrice des auteurs les plus importants par concept

| Concept Pi Theory | Auteurs prioritaires |
|---|---|
| Principe pré-géométrique / non spatial | Cues, Plotin, Denys, Wheeler, Weyl |
| Cercle / symétrie / invariance | Pythagoriciens, Platon, Klein, Lie, Weyl, Noether |
| Division originelle | Empédocle, Böhme, Schelling, Spencer-Brown |
| M comme contre-mouvement | Empédocle, Proclus, Denys, Teilhard |
| M comme cohésion traversant matière-vie-esprit | Stoïciens, Teilhard, Whitehead |
| BIEN / orientation | Platon, Proclus, Denys, Thomas, Whitehead |
| Différenciation ↔ intégration | Empédocle, Simondon, Whitehead, Louria, Heraclite |
| Seuil / B0UM | Simondon, Prigogine, Thom |
| SIZE → mesure | Cues, Hegel, Riemann, Weyl |
| Mesure → espace-temps | Riemann, Weyl, Einstein |
| π exact / manifestation | Cues, Whitehead, Bohm, structuralisme |
| Information / matière | Shannon, Landauer, Wheeler |
| Matière → vie | Prigogine, Turing, Maturana/Varela, Deacon |
| Vie → conscience | Varela, Deacon, Teilhard, Whitehead |
| Cohérence croissante | Teilhard, Whitehead, Simondon, Stoïciens |
| Retour à la Source | Proclus, Plotin, Denys, Érigène, Daoïsme |
| Miroir / signe / langage | Peirce, Cassirer, Bateson |
| Résolution multi-échelle | Simondon, Whitehead, Prigogine, Kauffman |
| Critique de téléologie | Darwin, Bergson |
| Infini | Cues, Cantor |
| Immanence | Spinoza, Stoïciens, Whitehead |

---

# XI. Ordre de lecture optimisé

## Premier cercle — comprendre la théorie elle-même
1. Empédocle
2. Proclus
3. Nicolas de Cues
4. Böhme
5. Teilhard
6. Whitehead
7. Simondon

## Deuxième cercle — formaliser
8. Peirce
9. Hegel
10. Riemann
11. Weyl
12. Noether
13. Shannon
14. Landauer
15. Turing

## Troisième cercle — matière, vie, conscience
16. Prigogine
17. Varela
18. Deacon
19. Stoïciens
20. Darwin

## Quatrième cercle — élargir la métaphysique
21. Plotin
22. Pseudo-Denys
23. Érigène
24. Schelling
25. Louria/Vital
26. Laozi

## Cinquième cercle — histoire du point de départ
27. Saint-Martin
28. Martinès
29. Chevillon

---

# XII. Les cinq auteurs qui correspondent le mieux à votre dernière clarification

## Empédocle
**Division ↔ Love**, Sphere, apparition du vivant dans la tension.

## Proclus
Le processus **sort de sa cause et revient vers elle**, avec orientation vers le Bien.

## Teilhard
Le retour devient **convergence et montée de cohérence**; l'union différencie plutôt qu'elle n'abolit la multiplicité.

## Stoïciens
Une puissance immanente **cohésive** traverse matière, vie et âme avec des degrés d'organisation.

## Nicolas de Cues
Permet de penser le cercle/divin comme **principe au-delà d'une sphère spatiale déterminée**, puis sa contraction dans le mesurable.

Ces cinq doivent désormais être mis en évidence beaucoup plus tôt que Chevillon ou les analogies de physique spéculative.

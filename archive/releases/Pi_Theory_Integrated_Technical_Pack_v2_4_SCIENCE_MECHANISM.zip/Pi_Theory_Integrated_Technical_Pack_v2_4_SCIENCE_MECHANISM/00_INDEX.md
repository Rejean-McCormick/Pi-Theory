# Index maître — v2.4 Science Mechanism

## Nouveaux points d'entrée scientifiques
1. [Carte scientifique du mécanisme](03_bridges/00_SCIENCE_MECHANISM_MAP.md)
2. [Auteurs scientifiques prioritaires](04_authors/00_SCIENCE_PRIORITY_AUTHORS.md)
3. [Claims × domaines scientifiques](07_matrices/01_CLAIM_SCIENCE_DOMAIN_MATRIX.md)
4. [Roadmap de formalisation scientifique](06_methods/12_SCIENCE_FORMALIZATION_ROADMAP.md)
5. [Registre de sources scientifiques](09_sources/01_SCIENCE_MECHANISM_SOURCE_REGISTRY.md)

### Modules A+
- [Bioélectricité développementale](03_bridges/17_DEVELOPMENTAL_BIOELECTRICITY.md)
- [Systèmes dynamiques / attracteurs / contrôle](03_bridges/18_DYNAMICAL_SYSTEMS_ATTRACTORS_CONTROL.md)
- [Synergetics / paramètres d'ordre](03_bridges/19_SYNERGETICS_ORDER_PARAMETERS.md)
- [Renormalisation / scale / universalité](03_bridges/20_RENORMALIZATION_SCALE_UNIVERSALITY.md)

### Transition matière → vie
- [Origine de la vie / autocatalyse](03_bridges/21_ORIGIN_OF_LIFE_AUTOCATALYSIS.md)
- [Active matter](03_bridges/22_ACTIVE_MATTER_COLLECTIVE_ORDER.md)
- [Mechanobiology](03_bridges/26_MECHANOBIOLOGY_MORPHOGENESIS.md)
- [Network science](03_bridges/27_NETWORK_SCIENCE_MULTISCALE.md)

### Formalisations complémentaires
- [Free Energy / Active Inference](03_bridges/23_FREE_ENERGY_ACTIVE_INFERENCE.md)
- [Information geometry](03_bridges/24_INFORMATION_GEOMETRY.md)
- [Pré-géométrie / spacetime émergent](03_bridges/25_EMERGENT_SPACETIME_PREGEOMETRY.md)


## Références centrales nouvelles
1. [Dictionnaire canonique de Pi Theory](01_core/12_THEORY_DICTIONARY_CANONICAL.md)
2. [Auteurs pertinents — carte canonique](04_authors/00_RELEVANT_AUTHORS_CANONICAL.md)
3. [Scholars prioritaires](05_scholars/00_SCHOLARS_CORE_REFERENCE.md)
4. [Matrice Pi Theory × auteurs](07_matrices/00_CORE_CONCEPT_AUTHOR_MATRIX.md)
5. [Sources académiques v2.3](09_sources/00_V2_3_ACADEMIC_SOURCE_NOTES.md)


## À lire d'abord
1. [Ce qu'il faut retenir](00_READ_THIS_FIRST.md)
2. [Carte des thèses centrales](01_core/00_CORE_THESIS_MAP.md)
3. [Ce qui paraît le plus original](01_core/00B_WHAT_IS_MOST_ORIGINAL.md)
4. [Claims centraux](02_claims/CORE_CLAIMS_ONLY.md)
5. [Colonne vertébrale du livre](08_book/00_BOOK_SPINE.md)

## Noyau
- [Statut canonique](01_core/00_CANONICAL_STATUS.md)
- [Évolution du corpus](01_core/01_CORPUS_EVOLUTION.md)
- [Kernel et opérateurs](01_core/02_KERNEL_AND_OPERATORS.md)
- [π exact / représenté / manifesté](01_core/03_PI_EXACT_REPRESENTED_MANIFESTED.md)
- [88 / SIZE / mesure](01_core/05_88_SIZE_MEASURE.md)
- [π invariant / retour](01_core/06_PI_INVARIANT_RETURN.md)
- [Matière / information / mémoire](01_core/08_MATTER_INFORMATION_MEMORY.md)
- [Temporal lens / ongoing resolution](01_core/13_TEMPORAL_LENS_POST88.md)
- [Images convergentes / essence fonctionnelle](01_core/14_CONVERGENT_IMAGES_AND_NUMBER_ESSENCE.md)

## Modules importants
- [Source / b−1](01_core/04_SOURCE_MANIFESTATION_BMINUS1.md)
- [e, π, i, φ](01_core/07_E_PI_I_PHI.md)
- [Vie / conscience](01_core/09_LIFE_CONSCIOUSNESS_REFLEXIVITY.md)
- [Rosetta / kOA](01_core/10_ROSETTA_KOA.md)
- [kOA / Kristal comme architecture épistémique](01_core/20_KOA_EPISTEMIC_ARCHITECTURE.md)

## Méthode indispensable
- [Niveaux épistémiques](02_claims/EPISTEMIC_LEVELS.md)
- [Audit du décodage](06_methods/01_DECODING_AUDIT.md)
- [Coût interprétatif](06_methods/02_INTERPRETIVE_COST.md)
- [Null models](06_methods/03_NULL_MODELS.md)
- [Préenregistrement](06_methods/04_PREREGISTRATION.md)
- [Rosetta prédictif](06_methods/05_ROSETTA_PREDICTIVE.md)
- [Falsification](06_methods/06_FALSIFICATION.md)

## Auteurs — entrer par problème
- [Index auteurs](04_authors/AUTHORS_INDEX.md)
- [Top 25](04_authors/TOP_25_BOOK_CORE.md)
- [Auteurs × thèmes](07_matrices/AUTHOR_THEME_MATRIX.md)
- [Chapitres × auteurs](07_matrices/CHAPTER_AUTHOR_MATRIX.md)

## Secondaire / historique
- [Ce qui doit rester secondaire](01_core/00C_WHAT_IS_SECONDARY.md)
- [Mirror G0D/B0N](01_core/16_MIRROR_G0D_B0N.md)
- [Base-9 legacy](01_core/17_BASE_SYSTEMS_AND_BASE9_LEGACY.md)
- [First fractal](01_core/18_FIRST_FRACTAL_AND_RECURSION.md)
- [Notes token-level](01_core/19_TOKEN_LEVEL_NOTES.md)
- [Numérologie / gematria](06_methods/11_NUMEROLOGY_GEMATRIA_POSITIONING.md)
- [Archive des analogies physiques](10_archive_map/ANALOGY_ARCHIVE_PHYSICS.md)

## Sources
- [Corpus interne](09_sources/INTERNAL_CORPUS.md)
- [Provenance conceptuelle](09_sources/CONCEPT_PROVENANCE_MATRIX.md)
- [Bibliographie](09_sources/MASTER_BIBLIOGRAPHY.md)

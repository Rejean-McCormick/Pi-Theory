# Migration et réconciliation des packs précédents

## Pack A — documentation_futur_livre_pi.md
Forces :
- meilleure synthèse interne de la théorie;
- distinction des niveaux de preuve;
- 88/SIZE;
- trois π;
- matière comme mémoire;
- architecture de livre;
- méthodologie.

Faiblesse :
- monolithique;
- inventaire auteurs moins extensible.

## Pack B — Pi Theory Author Atlas
Forces :
- grand inventaire;
- fiches atomiques;
- disciplines larges;
- scholars;
- modules techniques;
- Teilhard, physique, systèmes, biologie.

Faiblesses :
- Pi Theory y devenait parfois un simple point de référence autour de l'atlas;
- liens auteur ↔ claim insuffisamment explicites;
- plusieurs sujets répétaient la documentation maîtresse.

## v2 — décision
La v2 inverse la relation :

`Pi Theory core → claims → problèmes → auteurs/sciences`.

Les auteurs ne constituent plus une deuxième théorie parallèle.

## Principales optimisations
1. v13 canonique; v12 archive.
2. claim registry central.
3. Source ≠ π ≠ digits ≠ matière.
4. causalité « nécessaire » déclassée en cohérence interprétative.
5. 88/SIZE décomposé sémiotiquement.
6. SIZE→mesure séparé de SIZE→espace.
7. matière-comme-mémoire séparée de matière-comme-π.
8. Teilhard positionné sur vie/conscience, pas sur preuve cosmologique.
9. branes/holographie/string déplacés hors noyau.
10. Rosetta redéfini comme potentiel protocole prédictif.
11. top 25 recalculé en fonction des problèmes du livre.
12. auteurs réorganisés par domaine.


## Audit post-v2 → v2.1
Le v2 était méthodologiquement plus propre mais avait introduit un biais de normalisation :
plusieurs idées originales étaient seulement présentes dans le legacy ou avaient disparu de la navigation principale.

v2.1 adopte le principe :
**ne pas confondre optimisation avec effacement**.

Chaque motif est désormais soit :
- canonique;
- hypothèse;
- branche legacy;
- archive analogique;
- claim déclassé.


# v2.4 → v2.5

La v2.4 ajoutait les bons domaines scientifiques mais les gardait encore partiellement comme « bridges ».

La v2.5 les réinjecte dans le **noyau théorique** :

- M ↔ attracteur/régulation/homeostasie morphologique;
- BIEN ↔ contraintes de viabilité;
- JNON ↔ order parameters/intégration;
- B0UM ↔ bifurcation;
- SIZE ↔ renormalisation/échelle;
- matière ↔ mémoire/path dependence;
- vie ↔ autocatalyse/autopoïèse.

La thèse π-spécifique demeure séparée et non démontrée.

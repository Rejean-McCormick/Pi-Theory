# Scholars et guides secondaires prioritaires

Cette liste sert à éviter les raccourcis historiques. Un scholar est utilisé pour établir ce qu'un auteur a réellement soutenu, non pour « valider Pi Theory ».

## Empédocle
- **Oliver Primavesi** — papyrus de Strasbourg, cosmologie, Love/Strife.
- **Brad Inwood** — philosophie présocratique, édition/interprétation.
- **Catherine Osborne** — Empédocle et philosophie ancienne.
- **David Sedley** — débats sur la cosmogonie.

## Plotin / néoplatonisme
- **Lloyd P. Gerson** — Plotin et platonisme.
- **Dominic O'Meara** — Plotin, Proclus, néoplatonisme.
- **Carlos Steel** — Proclus, éditions et métaphysique.
- **Radek Chlup** — Proclus.

## Pseudo-Denys
- **Andrew Louth**
- **Paul Rorem**

## Érigène
- **Dermot Moran**
- **Deirdre Carabine**
- **Werner Beierwaltes**

## Nicolas de Cues
- **Jasper Hopkins**
- **Clyde Lee Miller**
- **Kurt Flasch**

## Böhme
- **Andrew Weeks**
- **Cyril O'Regan**
- **Ariel Hessayon**

## Kabbale lourianique
- **Lawrence Fine**
- **Moshe Idel**
- **Gershom Scholem**
- **Elliot R. Wolfson**
- **Boaz Huss**

## Teilhard
- **Ursula King**
- **John F. Haught**
- **Henri de Lubac**
- **Mary Evelyn Tucker**
- **John Grim**
- **Ilia Delio** — utile pour réception contemporaine, à distinguer des sources primaires.

## Whitehead
- **Isabelle Stengers**
- **Nicholas Rescher**
- **John B. Cobb Jr.**
- **Roland Faber**

## Simondon
- **Muriel Combes**
- **Jean-Hugues Barthélémy**

## Peirce
- **T. L. Short**
- **Cheryl Misak**
- **Nathan Houser**

## Weyl / symétrie / relativité
- **Thomas Ryckman**
- **Erhard Scholz**
- **Yvette Kosmann-Schwarzbach** — Noether.
- **John Stachel** — Einstein, relativité, histoire conceptuelle.

## Daoïsme
- **Roger T. Ames**
- **Hans-Georg Moeller**
- **Chad Hansen**

## Stoïcisme
- **A. A. Long**
- **Brad Inwood**
- **Susanne Bobzien**

## Jung
- **Sonu Shamdasani**

## Ésotérisme occidental / martinisme
- **Wouter J. Hanegraaff**
- **Antoine Faivre**
- **Robert Amadou** — martinisme, Saint-Martin, Martinès.

# Règle documentaire

Pour chaque chapitre comparatif du livre :
1. citer le texte primaire;
2. vérifier l'interprétation par au moins un scholar;
3. marquer explicitement « influence historique » ou « convergence indépendante »;
4. inclure une divergence réelle, pas seulement la ressemblance.

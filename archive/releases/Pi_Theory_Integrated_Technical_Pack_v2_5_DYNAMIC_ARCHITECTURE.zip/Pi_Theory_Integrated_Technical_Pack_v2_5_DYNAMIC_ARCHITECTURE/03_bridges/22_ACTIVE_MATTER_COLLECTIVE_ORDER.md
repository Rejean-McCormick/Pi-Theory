# Active matter et ordre collectif

## Claim Pi Theory ciblé
cohérence immanente sans organisateur externe.

## Science
Les systèmes de matière active sont composés d'unités qui consomment de l'énergie et produisent localement mouvement/forces.

Leurs interactions peuvent générer :
- polarisation;
- flocking;
- swarming;
- motifs;
- écoulements collectifs;
- instabilités macroscopiques.

## Pi Theory
C'est un analogue concret de :

`agents différenciés + interactions locales → organisation collective`.

Il illustre une cohérence qui n'est pas imposée par un centre externe.

## Auteurs
M. Cristina Marchetti, Sriram Ramaswamy, J. F. Joanny, John Toner, Yuhai Tu.

## Source
Marchetti et al., *Hydrodynamics of Soft Active Matter*, Rev. Mod. Phys. 85 (2013).

## Limite
La cohérence collective peut être transitoire, instable ou non fonctionnelle. Elle n'est pas automatiquement « Good ».

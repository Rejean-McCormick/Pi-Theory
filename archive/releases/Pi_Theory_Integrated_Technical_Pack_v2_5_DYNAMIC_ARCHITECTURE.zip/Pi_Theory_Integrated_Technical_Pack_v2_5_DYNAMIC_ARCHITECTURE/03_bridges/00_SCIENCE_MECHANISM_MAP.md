# Carte scientifique du mécanisme — Pi Theory v2.4

## Principe

La science n'est pas utilisée ici pour « prouver » Pi Theory par ressemblance.

Chaque domaine doit remplir une fonction précise :

`intuition Pi Theory → concept scientifique analogue → formalisation possible → limite`

---

# A+ — domaines les plus importants

## 1. Bioélectricité développementale / homeostasie morphologique
**Pi Theory :** `M = contre-mouvement vers cohérence`.

**Science :**
des réseaux bioélectriques multicellulaires participent au contrôle de la forme, de la polarité, du développement et de la régénération; les tissus peuvent restaurer des architectures globales après perturbation.

**Pourquoi majeur**
C'est actuellement l'analogue expérimental le plus proche d'une dynamique :

`perturbation → information distribuée → correction collective → forme cohérente`.

**Auteurs :** Michael Levin, Alexis Pietak, Daniel Lobo, Giovanni Pezzulo.

---

## 2. Systèmes dynamiques / attracteurs / stabilité
**Pi Theory :** M comme tendance de retour.

**Science :**
espace d'états, trajectoires, stabilité, attracteurs, bassins, perturbations, bifurcations.

**Pourquoi majeur**
C'est le langage mathématique naturel permettant de remplacer :

> « les choses veulent revenir »

par une proposition du type :

`dx/dt = F(x)` avec un ensemble attractif `A`.

**Auteurs :** Poincaré, Lyapunov, Smale, Strogatz.

---

## 3. Contrôle / homeostasie / allostasie
**Pi Theory :** le contre-mouvement corrige la dispersion.

**Science :**
feedback négatif, régulation, erreur, set point, robustesse, adaptation.

**Gain conceptuel**
Le retour peut conduire non au même état, mais à un nouveau régime viable :

`U0 → perturbation → régulation → U1`.

C'est proche de l'**unité enrichie**.

**Auteurs :** Wiener, Ashby, Cannon, Conant, Friston (branche plus spéculative).

---

## 4. Synergetics / order parameters
**Pi Theory :** multiplicité → ordre global cohérent.

**Science :**
dans des systèmes complexes, beaucoup de degrés de liberté peuvent être coordonnés par quelques paramètres d'ordre.

**Pi Theory**
`Divide → composants`
`M/JNON → ordre collectif`
`order parameter → rétroaction sur composants`.

**Auteur central :** Hermann Haken.

---

## 5. Renormalisation / universalité / multi-échelle
**Pi Theory :** `SIZE` et récursion du kernel.

**Science :**
coarse-graining, fixed points, universality classes, scale invariance, variables pertinentes.

**Pourquoi majeur**
C'est le meilleur langage scientifique pour demander si :

`K0 → K1 → K2`

peut conserver une structure fonctionnelle en changeant d'échelle.

**Auteurs :** Kenneth Wilson, Leo Kadanoff, Michael Fisher.

---

# A — transitions matière → vie

## 6. Origine de la vie / autocatalyse
**Pi Theory :** matière → organisation autonome.

**Science :**
réseaux autocatalytiques, protocellules, métabolisme, compartimentation, RAF theory.

**Question**
Quand une organisation chimique devient-elle capable de se maintenir, se reproduire et évoluer ?

**Auteurs :**
Stuart Kauffman, Manfred Eigen, Tibor Gánti, Eörs Szathmáry, Wim Hordijk, Mike Steel, Addy Pross, Sara Imari Walker.

---

## 7. Active matter / ordre collectif
**Pi Theory :** cohérence immanente sans organisateur externe.

**Science :**
agents consommant de l'énergie localement → mouvements collectifs, polarisation, essaims, structures émergentes.

**Auteurs :**
M. Cristina Marchetti, Sriram Ramaswamy, J. F. Joanny, John Toner, Yuhai Tu.

---

## 8. Mechanobiology / morphogenèse mécanique
**Pi Theory :** tension + cohésion → forme.

**Science :**
forces, contraintes, matrices extracellulaires, tensions corticales et mécaniques participent directement à l'organisation des tissus.

**Gain**
« harmonie » peut être partiellement traduite comme équilibre dynamique de contraintes.

---

## 9. Network science / organisation modulaire
**Pi Theory :**
`différence conservée + intégration = unité enrichie`.

**Science :**
modularité, communautés, hiérarchie, intégration, robustesse, réseaux multi-échelles.

**Question**
Comment augmenter simultanément :
- spécialisation des parties;
- coordination globale ?

C'est exactement le problème scientifique de « l'union qui différencie ».

---

# A/B — cognition et viabilité

## 10. Free Energy Principle / Active Inference
**Pi Theory :**
`M = tendance`
`BIEN = contraintes de viabilité`.

**Science proposée :**
des agents occupent un répertoire limité d'états et agissent/perçoivent de manière à rester dans des régimes compatibles avec leur existence.

**Utilité**
Fournit une formulation possible de :
`retour vers états viables`.

**Garde-fou**
Les extensions universelles du FEP sont contestées. Ce domaine ne doit jamais devenir une « preuve mathématique de M ».

---

## 11. Information geometry
**Pi Theory :**
`information → différence → mesure → géométrie`.

**Science/mathématiques :**
les familles de distributions de probabilité peuvent recevoir une structure géométrique.

**Auteur :** Shun-ichi Amari.

**Valeur**
Montre rigoureusement qu'il existe des cas où une géométrie est construite sur des relations informationnelles, sans impliquer que notre espace-temps procède ainsi.

---

# B — pré-géométrie / espace émergent

## 12. Quantum information & emergent spacetime
**Pi Theory :**
le principe originel est non spatial; l'espace vient plus tard.

**Programmes scientifiques**
- pré-géométrie;
- entanglement et géométrie;
- tensor networks;
- causal sets;
- loop quantum gravity/spin networks.

**Auteurs**
John Wheeler, Mark Van Raamsdonk, Ted Jacobson, Carlo Rovelli, Rafael Sorkin.

**Valeur**
Rend scientifiquement respectable la question :
> un ordre relationnel peut-il être plus fondamental que l'espace ?

**Limite**
Aucun de ces programmes ne soutient un principe circulaire ou M/AIME.

---

# Hiérarchie finale

| Priorité | Domaine | Claim Pi Theory principal |
|---|---|---|
| A+ | Bioélectricité développementale | M / restauration de cohérence |
| A+ | Systèmes dynamiques | retour / attracteur |
| A+ | Contrôle & homeostasie | contre-mouvement / viabilité |
| A+ | Synergetics | cohérence globale |
| A+ | Renormalisation | SIZE / multi-échelle |
| A | Origine de la vie | matière → autonomie |
| A | Active matter | ordre collectif immanent |
| A | Mechanobiology | tension → forme |
| A | Network science | différenciation + intégration |
| A/B | FEP / Active inference | viabilité / BIEN |
| A/B | Information geometry | information → métrique |
| B | Emergent spacetime | pré-géométrie → espace |

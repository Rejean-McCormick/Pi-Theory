# Renormalisation, échelle et universalité

## Claim Pi Theory ciblé
`88/SIZE` et récursion multi-échelle.

## Concept
Le groupe de renormalisation étudie comment une description change lorsqu'on modifie l'échelle d'observation.

Dans les phénomènes critiques, des systèmes microscopiquement différents peuvent converger vers le même comportement macroscopique : **universalité**.

## Concepts
- coarse-graining;
- fixed point;
- flow;
- relevant / irrelevant variables;
- scale invariance;
- universality class;
- critical exponent.

## Pi Theory
Question formelle :

> le kernel `D ↔ A → T → S` possède-t-il une structure stable sous changement d'échelle ?

Si oui, il faudrait définir une transformation `R` telle que :

`K_(n+1) = R(K_n)`

et rechercher :
- invariants;
- fixed points;
- mutations pertinentes.

## Auteurs
Kenneth Wilson, Leo Kadanoff, Michael Fisher.

## Pourquoi beaucoup plus important que « fractal »
La renormalisation permet de parler scientifiquement de **réapparition de structure entre échelles** sans supposer une auto-similarité géométrique parfaite.

## Source
Kenneth G. Wilson, Nobel Lecture, *The Renormalization Group and Critical Phenomena* (1982).

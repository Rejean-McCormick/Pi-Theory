# Origine de la vie, autocatalyse et autonomie

## Claim Pi Theory ciblé
`matière → organisation → vie`.

## Problème
Une structure ordonnée n'est pas encore vivante.

Il faut expliquer :
- maintien;
- frontière;
- métabolisme;
- catalyse;
- reproduction;
- hérédité;
- évolution.

## Réseaux autocatalytiques
Des ensembles de réactions peuvent être organisés de sorte que leurs composants contribuent collectivement à la production et au maintien du réseau.

RAF theory fournit une formalisation mathématique de certaines propriétés de réseaux autocatalytiques.

## Pi Theory
Cela peut fournir une étape entre :

`cohérence physique`

et :

`cohérence auto-entretenue`.

## Auteurs
Stuart Kauffman, Manfred Eigen, Tibor Gánti, Eörs Szathmáry, Wim Hordijk, Mike Steel, Addy Pross, Sara Imari Walker.

## Source
Hordijk & Steel, *Chasing the tail: The emergence of autocatalytic networks* (2017).

## Limite
L'autocatalyse ne démontre aucune tendance cosmique vers la conscience.

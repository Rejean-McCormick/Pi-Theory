# Information geometry

## Auteur central
Shun-ichi Amari.

## Concept
Une famille de distributions probabilistes peut être représentée comme une variété géométrique munie de structures métriques et affines.

## Pertinence
Pi Theory cherche une chaîne :

`distinction/information → mesure → géométrie`.

Information geometry démontre rigoureusement qu'une géométrie peut être construite à partir de relations entre distributions informationnelles.

## Ce que cela ne montre pas
Elle ne démontre pas que l'espace physique est une variété d'information au sens cosmologique.

## À lire
Shun-ichi Amari, *Information Geometry and Its Applications*.

## Question de recherche
Une notion abstraite de différence entre états peut-elle fournir une métrique avant l'introduction d'un espace physique ?

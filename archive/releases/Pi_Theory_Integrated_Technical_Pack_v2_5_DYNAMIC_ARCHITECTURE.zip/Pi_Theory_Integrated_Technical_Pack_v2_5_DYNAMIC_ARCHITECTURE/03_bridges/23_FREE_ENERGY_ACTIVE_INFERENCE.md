# Free Energy Principle et Active Inference

## Claim Pi Theory ciblé
`M → retour vers régimes cohérents`
`BIEN → contraintes de viabilité`.

## Formulation scientifique
Dans le cadre du FEP, les organismes/agents occupent un répertoire limité d'états et perception/action peuvent être décrites par minimisation de free energy variationnelle.

## Analogie Pi Theory
`M` pourrait être comparé à la tendance à rester dans des régimes compatibles avec la persistance.

`BIEN` pourrait être rapproché, très prudemment, de contraintes de viabilité.

## Auteur central
Karl Friston.

## Sources
- Friston, *The free-energy principle: a unified brain theory?* Nature Reviews Neuroscience (2010).
- Friston, *The free-energy principle: a rough guide to the brain?* Trends in Cognitive Sciences (2009).

## Critique indispensable
La portée universelle du FEP est contestée. Certaines analyses soutiennent qu'il ne constitue pas une explication générale de toute auto-organisation biologique.

## Statut
**outil potentiel de formalisation — non pilier ontologique**.

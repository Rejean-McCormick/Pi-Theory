# Systèmes dynamiques, attracteurs, contrôle et homeostasie

## Claim Pi Theory ciblé
`Division → écart / dispersion`
`M → contre-mouvement vers cohérence`.

## Formalisation minimale
Soit un état :

`x(t) ∈ X`

et une dynamique :

`dx/dt = F(x)`.

Un ensemble `A ⊂ X` est attractif si des trajectoires proches convergent vers lui.

Cette structure fournit une traduction possible de M :

`M ≈ propriété/dynamique qui rend certains régimes de cohérence attractifs`.

## Concepts
- attracteur;
- bassin d'attraction;
- stabilité de Lyapunov;
- perturbation;
- feedback;
- bifurcation;
- contrôle;
- robustesse;
- homeostasie;
- allostasie.

## Différence cruciale
Un attracteur scientifique n'est pas « le Bien ».

Pour introduire BIEN il faut définir un critère supplémentaire :
- viabilité;
- fonction;
- performance;
- persistance;
- contrainte.

## Auteurs
Henri Poincaré, Aleksandr Lyapunov, Stephen Smale, Steven Strogatz, Norbert Wiener, W. Ross Ashby, Walter Cannon.

## Programme Pi Theory
Définir :
1. espace d'états;
2. mesure de cohérence `C(x)`;
3. dynamique de division;
4. dynamique intégrative;
5. états/ensembles attractifs;
6. seuils de changement d'échelle.

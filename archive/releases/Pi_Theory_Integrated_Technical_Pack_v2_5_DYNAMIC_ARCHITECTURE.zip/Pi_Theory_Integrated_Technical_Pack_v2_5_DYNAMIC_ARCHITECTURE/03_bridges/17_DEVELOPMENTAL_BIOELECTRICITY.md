# Bioélectricité développementale et homeostasie morphologique

## Claim Pi Theory ciblé
`M = contre-mouvement immanent vers cohérence`.

## Résultat scientifique pertinent
La communication bioélectrique entre cellules participe au contrôle de la morphogenèse, de la polarité, de la régénération et de décisions multicellulaires à grande échelle.

Des réseaux de potentiels membranaires et de jonctions communicantes peuvent coordonner des cellules vers des résultats anatomiques globaux malgré perturbations.

## Pourquoi c'est important pour Pi Theory
C'est beaucoup plus précis qu'une analogie « Love = gravité ».

On dispose ici d'un système où :
1. des unités locales sont séparées;
2. elles partagent de l'information;
3. une organisation de niveau supérieur contraint leurs comportements;
4. la perturbation peut déclencher des réponses correctives;
5. une forme globale est restaurée.

Schéma :

`perturbation → erreur morphologique → coordination → correction → forme`.

## Hypothèse comparative
M pourrait être traité comme **abstraction métaphysique** d'une classe générale de phénomènes de correction vers cohérence.

## Auteurs
- Michael Levin
- Alexis Pietak
- Daniel Lobo
- Giovanni Pezzulo

## Sources prioritaires
- Levin et al., *Bioelectrical controls of morphogenesis* (2019).
- Pietak & Levin, *Bioelectrical control of positional information in development and regeneration* (2018).
- Levin, *Morphogenetic fields in embryogenesis, regeneration, and cancer* (2012).
- Levin, *Bioelectric signaling: Reprogrammable circuits underlying embryogenesis, regeneration, and cancer* (2021).

## Limites
- Il ne s'agit pas d'une force cosmique.
- Les objectifs morphologiques résultent de mécanismes biologiques évolués.
- La notion de « mémoire de forme » doit être employée selon la littérature expérimentale, pas comme preuve d'un modèle platonicien.

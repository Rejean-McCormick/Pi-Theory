# Pré-géométrie et espace-temps émergent

## Claim Pi Theory ciblé
Le principe originel ne doit pas présupposer un espace.

## Programmes scientifiques pertinents
- Wheeler : pregeometry;
- causal sets;
- loop quantum gravity / spin networks;
- quantum information;
- entanglement & spacetime;
- tensor networks.

## Idée commune
Dans plusieurs programmes de gravité quantique, la géométrie classique n'est pas nécessairement fondamentale.

Des relations plus primitives peuvent être candidates à la production de :
- connectivité;
- distance;
- aire;
- volume;
- causalité;
- espace-temps.

## Auteur contemporain important
Mark Van Raamsdonk :
travaux montrant, dans le contexte holographique, des liens entre structure d'intrication quantique et connectivité géométrique.

## Pi Theory
Cela légitime la question :

> le principe pré-géométrique de circularité pourrait-il être formulé comme une structure relationnelle plutôt qu'une forme dans l'espace ?

## Limite majeure
Ces programmes n'impliquent ni π comme code ni M/AIME.

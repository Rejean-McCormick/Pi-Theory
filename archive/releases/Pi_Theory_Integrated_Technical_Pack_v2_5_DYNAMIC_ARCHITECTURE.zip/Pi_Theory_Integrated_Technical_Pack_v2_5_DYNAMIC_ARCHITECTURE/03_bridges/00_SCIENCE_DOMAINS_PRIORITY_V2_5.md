# Domaines scientifiques prioritaires — v2.5

## Tier S — mécanisme direct

### 1. Systèmes dynamiques
Formalise M comme retour/stabilité/attracteur.

### 2. Bioélectricité développementale
Montre des systèmes biologiques distribués capables de réguler et restaurer une forme globale.

### 3. Contrôle / homeostasie / allostasie
Formalise correction d'écart et maintien de viabilité.

### 4. Synergetics
Formalise émergence d'un ordre global à partir de nombreux degrés de liberté.

### 5. Renormalisation / universalité
Formalise changement d'échelle, invariance et récursion effective.

---

## Tier A — transitions

### 6. Bifurcations / transitions de phase
Formalise B0UM.

### 7. Mechanobiology
Formalise tension coordonnée et morphogenèse.

### 8. Network science
Formalise différenciation + intégration sans homogénéisation.

### 9. Origine de la vie / autocatalyse
Formalise passage vers autonomie chimique.

### 10. Active matter
Montre ordre collectif immanent hors équilibre.

### 11. Autopoïèse / enaction
Formalise vivant comme organisation auto-entretenue.

### 12. Information physique / Landauer
Clarifie matière comme support de distinctions et mémoire.

---

## Tier A/B — ponts ambitieux

### 13. Information geometry
Montre qu'une géométrie peut être construite sur des structures informationnelles.

### 14. Active inference / FEP
Peut formaliser la viabilité, mais sa portée générale est contestée.

### 15. Pré-géométrie / espace-temps émergent
Légitime l'idée que l'espace peut ne pas être fondamental.

---

## Ce qui descend dans la hiérarchie

- string theory;
- branes;
- E8;
- holographie comme analogie générale;
- « gravité = Love »;
- recherches de mots comme DNA/ATOM/E=MC².

Ces éléments sont conservés comme archives heuristiques, mais ne renforcent pas directement le mécanisme.

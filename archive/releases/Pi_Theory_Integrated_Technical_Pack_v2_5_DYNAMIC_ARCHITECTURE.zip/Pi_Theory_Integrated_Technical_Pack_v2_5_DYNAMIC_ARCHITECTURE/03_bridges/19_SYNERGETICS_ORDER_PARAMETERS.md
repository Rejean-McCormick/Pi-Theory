# Synergetics et paramètres d'ordre

## Auteur central
Hermann Haken.

## Résultat
La synergetics étudie la formation spontanée de structures spatiales, temporelles ou fonctionnelles dans des systèmes complexes composés de nombreuses parties.

Des variables macroscopiques — **order parameters** — peuvent décrire et coordonner un grand nombre de degrés de liberté.

## Pi Theory
Cela donne une architecture naturelle :

`D : multiplication des degrés de liberté`

puis :

`A/M : émergence d'un order parameter`

puis :

`order parameter → contraintes sur les composants`.

Le tout exerce donc un effet descendant sur ses parties sans nécessiter un organisateur extérieur.

## Concepts
- self-organization;
- instability;
- order parameter;
- slaving principle;
- phase transition;
- collective mode.

## Pourquoi majeur
C'est une formalisation potentielle du passage :

`multiplicité → cohérence globale`.

## Source
Hermann Haken, *Synergetics: Introduction and Advanced Topics*.

## Limite
Le paramètre d'ordre n'est pas une entité spirituelle ni un principe du Bien.

# Mechanobiology et morphogenèse mécanique

## Claim Pi Theory ciblé
`tension + cohésion → forme`.

## Science
Les cellules et tissus :
- génèrent des forces;
- détectent les contraintes;
- modifient leur comportement;
- réorganisent matrices et contacts;
- transforment mécaniquement la forme du tissu.

## Pi Theory
Le couple :
`division ↔ intégration`
peut être comparé aux tensions mécaniques dont l'équilibre dynamique produit/maintient une morphologie.

## Concept important
L'harmonie n'est pas nécessairement absence de tension.

Elle peut être :
> **tension coordonnée dans une structure stable**.

Cela rapproche Pi Theory de Héraclite, mais avec un analogue expérimental biologique.

## Limite
Aucune force mécanique particulière n'est M.

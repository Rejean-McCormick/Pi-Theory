# Squelette de formalisation — Pi Theory v2.5

## Objectif

Passer d'une grammaire verbale à un modèle minimal qui puisse échouer.

---

# 1. Espace d'états

Définir :

`x ∈ X`

où `x` encode un état du système.

Ne pas supposer encore que `X` est un espace physique.

---

# 2. Deux tendances fondamentales

Décomposer la dynamique :

`dx/dt = F_D(x) + F_M(x)`

où :

- `F_D` augmente certaines formes de différenciation;
- `F_M` augmente une mesure de cohérence.

Cette équation est un **squelette**, pas une loi physique établie.

---

# 3. Cohérence

Définir une ou plusieurs mesures :

`C(x)`.

Candidates selon domaine :
- stabilité;
- mutual information;
- modularity;
- robustness;
- synchronisation;
- distance à un attracteur;
- viability;
- integrated constraints.

Important :
une seule métrique universelle de cohérence n'est pas supposée.

---

# 4. BIEN / viabilité

Définir :

`V(x)` = mesure de viabilité/fonctionnalité.

Hypothèse testable :

`F_M` ne maximise pas simplement `C(x)`, mais favorise les états où :

`C(x)` et `V(x)` restent compatibles avec différenciation.

Cela formalise :

`harmonie ≠ homogénéité`.

---

# 5. Différenciation et intégration

Définir :

`D(x)` = degré de différenciation;

`I(x)` = degré d'intégration.

Un état « enrichi » devrait satisfaire :

`D(x) élevé`
et
`I(x) élevé`.

Une théorie future peut chercher un fonctionnel :

`H(x) = f(D(x), I(x), V(x))`

comme candidat à « harmonie/cohérence viable ».

---

# 6. Seuil

Définir un paramètre :

`τ(x)`.

Transition :

`τ(x) ≥ τ*  =>  x ∈ regime_(n+1)`.

Comparer :
- bifurcations;
- transitions de phase;
- criticality;
- morphogenetic transitions.

---

# 7. Échelle

Définir une transformation de coarse-graining :

`R_s`.

Alors :

`x_(s+1) = R_s(x_s)`.

Question Pi Theory :

> les mêmes relations fonctionnelles réapparaissent-elles après transformation d'échelle ?

Chercher :
- invariants;
- fixed points;
- relevant variables;
- universality classes.

---

# 8. Matière comme mémoire

Introduire dépendance historique :

`x(t) = F[x(t0:t)]`

ou une variable mémoire `m(t)`.

Tester :
- hystérésis;
- path dependence;
- state memory;
- morphological memory.

---

# 9. Vie

Ajouter contraintes d'autonomie :

- frontière;
- auto-entretien;
- catalyse;
- énergie;
- réplication/hérédité;
- adaptation.

Pi Theory ne doit qualifier un état de « vivant » qu'après ces propriétés.

---

# 10. π-spécificité

Définir une hypothèse `H_π`.

Elle doit fournir une différence mesurable entre :

- π;
- e;
- √2;
- φ;
- contrôles aléatoires.

Sans cela, le modèle reste une **théorie générale du processus inspirée par π**, pas une théorie scientifique de π comme principe cosmique.

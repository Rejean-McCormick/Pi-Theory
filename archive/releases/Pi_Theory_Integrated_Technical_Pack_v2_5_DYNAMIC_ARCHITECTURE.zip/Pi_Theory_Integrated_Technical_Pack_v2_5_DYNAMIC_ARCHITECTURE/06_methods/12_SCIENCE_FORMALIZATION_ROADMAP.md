# Roadmap scientifique v2.4

## Étape 1 — formaliser M

Définir un système minimal :

`x_dot = F_D(x) + F_M(x)`

où :
- `F_D` augmente différenciation/dispersion;
- `F_M` augmente une mesure de cohérence.

Problème :
définir `C(x)` sans présupposer le résultat.

### Métriques candidates
- stabilité;
- modularité;
- information mutuelle;
- intégration;
- robustesse;
- distance à un attracteur;
- viabilité.

---

## Étape 2 — distinguer M de JNON

`M` = champ/tendance globale vers cohérence.

`JNON` = opérateur local qui assemble réellement des composants.

Chercher des systèmes où :
- une variable globale/order parameter existe;
- les opérations locales réalisent cette tendance.

Synergetics et bioélectricité sont prioritaires.

---

## Étape 3 — formaliser BIEN

Éviter la morale au départ.

Tester plusieurs notions :
- viabilité;
- persistance;
- stabilité;
- capacité de réparation;
- conservation de diversité;
- performance fonctionnelle.

Hypothèse :
`GOOD = cohérence qui maintient ou augmente la viabilité sans abolir la différenciation`.

---

## Étape 4 — formaliser SIZE

Passer de :
`SIZE`

à :
`échelle d'observation`

puis utiliser la renormalisation :

`R_s : description à échelle s → description à échelle s'`.

Question :
le kernel possède-t-il des invariants sous `R_s` ?

---

## Étape 5 — matière → vie

Construire une chaîne scientifique distincte :

`non-equilibrium structure`
→ `autocatalytic network`
→ `compartment`
→ `self-maintenance`
→ `heredity/evolution`
→ `autopoiesis`
→ `cognition`.

Ne pas sauter directement de « cohérence » à « conscience ».

---

## Étape 6 — espace émergent

Formuler le principe pré-géométrique sans cercle spatial.

Question :
quelles relations primitives peuvent générer :
- voisinage;
- distance;
- dimension;
- métrique;
- causalité ?

Comparer aux programmes de pré-géométrie seulement après formalisation.

---

## Étape 7 — test π-spécifique

Toutes les étapes précédentes peuvent soutenir le **kernel général** sans soutenir π.

Le test décisif reste :

> pourquoi π ?

Une version scientifique forte doit produire une propriété numérique ou structurelle qui :
1. dépend de π;
2. n'est pas arbitraire en base/encodage;
3. distingue π d'autres constantes;
4. correspond à une observation indépendante.

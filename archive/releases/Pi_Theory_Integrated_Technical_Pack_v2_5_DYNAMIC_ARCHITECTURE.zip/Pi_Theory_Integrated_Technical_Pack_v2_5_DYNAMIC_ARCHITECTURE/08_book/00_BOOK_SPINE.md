# Colonne vertébrale du futur livre

## Le livre devrait démontrer/établir son intérêt dans cet ordre

### 1. π
Ce que π est mathématiquement, et ce que ses digits ne sont pas.

### 2. Le phénomène de décodage
Montrer exactement la fenêtre, les règles, les six blocs et l'histoire v12→v13.

### 3. Le kernel
Abstraire les personnages et mots vers les fonctions :
`C → V → D → A → T → S`.

### 4. Le problème le plus original
`88 / SIZE` et la question :
**comment un domaine de magnitude/mesure apparaît-il ?**

### 5. Intemporel et devenir
`π exact → représentation → hypothèse de manifestation`.

### 6. Processus et matière
Simondon / Whitehead / information / mémoire de processus.

### 7. Vie et conscience
Darwin → morphogenèse → Varela/Deacon → Teilhard comme lecture métaphysique.

### 8. Traditions métaphysiques
Seulement après que le modèle est clair :
Plotin, Proclus, Cues, Böhme, Louria, Érigène.

### 9. Sémiotique
Peirce et la question : pourquoi les mots devraient-ils porter une information sur une structure mathématique ?

### 10. Test
Nulls, préenregistrement, Rosetta prédictif, falsification.

### 11. La grande hypothèse
Seulement à la fin :
> le cosmos comme résolution/manifestation d'une structure dont π serait une expression privilégiée.

## À éviter
Ne pas faire un livre qui passe sans cesse :
Pythagore → Kabbale → Einstein → Jung → strings → Christ → π.

Cela dilue l'idée originale.

Les auteurs doivent intervenir **par problème**, pas comme accumulation de convergences.


## Mise à jour v2.3 — colonne vertébrale métaphysique

Le livre doit maintenant expliciter AVANT le kernel :

`Principe pré-géométrique de cohérence/circularité`
`→ Division originelle`
`→ M/AIME comme contre-mouvement`
`→ BIEN comme orientation`
`→ Différenciation ↔ Intégration`
`→ Seuil`
`→ Scale`

Puis seulement :

`Scale → mesure → métrique → espace/temps → matière → vie → conscience`.

Cette articulation remplace l'ancienne lecture trop linéaire où M n'était qu'un bloc initial.


## Mise à jour v2.4 — insertion d'une partie « science du mécanisme »

Après l'explication du kernel et avant les grandes traditions métaphysiques, insérer :

### Partie — Science du contre-mouvement et de la cohérence
1. Systèmes dynamiques et attracteurs.
2. Contrôle, homeostasie et allostasie.
3. Bioélectricité développementale — Michael Levin.
4. Synergetics — Hermann Haken.
5. Tension, mechanobiology et morphogenèse.

### Partie — Échelle et universalité
6. Renormalisation — Wilson/Kadanoff/Fisher.
7. Transitions de phase et seuils.
8. Network science et multi-échelle.

### Partie — De la matière au vivant
9. Active matter.
10. Autocatalyse et origine de la vie.
11. Autopoïèse.
12. Active inference comme modèle comparatif.
13. Deacon et l'émergence du sens.

### Partie — Du pré-géométrique à la géométrie
14. Information geometry.
15. Wheeler et la pré-géométrie.
16. Entanglement / emergent spacetime.

Cette structure rend la progression scientifique continue :

`M → cohérence → seuil → scale → autonomie → vie → information sémantique → espace/conscience`

sans utiliser les traditions spirituelles comme chaînons scientifiques.


# Mise à jour v2.5 — ordre optimal du livre

## Partie 0 — La distinction fondamentale
1. Le cercle n'est pas l'origine : il l'instancie.
2. π comme rapport sans dimension.
3. Principe pré-géométrique de circularité/cohérence.
4. Division originelle.
5. M/AIME comme contre-mouvement.

## Partie I — Le décodage
6. Pipeline v13.
7. Six blocs.
8. Limites méthodologiques et ex-post reproducibility.

## Partie II — La dynamique
9. M et BIEN.
10. Differentiation ↔ Integration.
11. B0UM/seuil.
12. SIZE/échelle.
13. Unité enrichie et récursion.

## Partie III — Science du mécanisme
14. Systèmes dynamiques.
15. Contrôle/homeostasie.
16. Bioélectricité développementale.
17. Synergetics.
18. Mechanobiology.
19. Transitions de phase.
20. Renormalisation.
21. Network science.

## Partie IV — Matière → vie
22. Matière comme mémoire.
23. Active matter.
24. Autocatalyse.
25. Autopoïèse.
26. Cognition et sens.

## Partie V — Espace et mesure
27. SIZE → mesure.
28. Riemann/Weyl.
29. Information geometry.
30. Pré-géométrie et spacetime émergent.

## Partie VI — Métaphysiques comparées
31. Empédocle.
32. Proclus.
33. Cues.
34. Böhme.
35. Teilhard.
36. Stoïciens / Denys / Érigène / Whitehead.

## Partie VII — Le problème π
37. π exact/représenté/manifesté.
38. Ongoing resolution.
39. Null models.
40. Prédiction π-spécifique.
41. Ce qui falsifierait la théorie.

Cette structure empêche que les parallèles spirituels soient utilisés comme substituts aux mécanismes scientifiques.

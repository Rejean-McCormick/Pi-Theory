# Pi Theory — Integrated Technical Pack v2.5 — Dynamic Architecture

Ce dépôt réconcilie deux ensembles antérieurs :

1. **Documentation de travail — futur livre sur π** : architecture doctrinale, corpus interne, niveaux de preuve, programme méthodologique.
2. **Pi Theory Author Atlas** : auteurs, scholars, disciplines, matrices et parcours de lecture.

La version v2 place désormais **Pi Theory au centre** et les auteurs/sciences autour d'elle.

## Principe directeur

Le dépôt distingue toujours :

`source interne → fait établi → observation du décodage → lecture sémiotique → convergence comparative → hypothèse métaphysique → hypothèse physique`

Aucune analogie philosophique, spirituelle ou scientifique n'est traitée comme une validation automatique de Pi Theory.

## Point de départ canonique

Le document interne de référence est **Pi v13**, avec le kernel :

`M → BIEN → GIHECEF → JNON → B0UM → SIZE`

abstrait comme :

`cohésion → orientation/valeur → différenciation → intégration → seuil/événement → échelle`

Le pulse central est :

`DIFFÉRENCIER ↔ INTÉGRER`

## Navigation

- `00_INDEX.md` — index maître.
- `01_core/` — théorie elle-même.
- `02_claims/` — registre des propositions et niveaux épistémiques.
- `03_bridges/` — ponts vers philosophie, physique, information, vivant, conscience.
- `04_authors/` — fiches auteurs classées par domaine.
- `05_scholars/` — chercheurs et historiens secondaires.
- `06_methods/` — tests, falsification, coût interprétatif, préenregistrement.
- `07_matrices/` — cartes transversales.
- `08_book/` — architecture du futur livre.
- `09_sources/` — bibliographies et provenance.
- `10_archive_map/` — correspondance avec les packs précédents.


## v2.1 — réintégration après audit du corpus
La v2.1 restaure, sous statuts explicites, plusieurs éléments que la v2 avait trop comprimés :
temporal lens, ongoing resolution, mirror G0D/B0N, rôle de 0 dans B0UM, τ/τ*, images convergentes/essence, base-9 legacy, first fractal, détails token-level, Kristal/kOA, Metaphysical Informatics, tests cross-culturels et archive des analogies physiques.


## v2.2 — principe de curation
La v2.1 cherchait surtout à ne rien perdre.  
La v2.2 ajoute une hiérarchie explicite : **noyau → modules importants → secondaire → archive**.

Aucun élément historiquement utile n'est détruit, mais le lecteur ne peut plus confondre les analogies périphériques avec les thèses qui portent réellement Pi Theory.


## v2.3 — changement conceptuel majeur

La v2.3 incorpore comme élément canonique la distinction suivante :

`principe pré-géométrique de circularité → division originelle → M/AIME comme contre-mouvement de cohésion`.

M n'est plus traité comme une simple première étape consommée par le kernel. Il devient l'impulsion persistante par laquelle la multiplicité tend vers des unités enrichies.

La v2.3 remplace aussi le vocabulaire ambigu « cercle sans dimension » par « principe pré-géométrique de circularité/symétrie » et reclassifie les auteurs en fonction de cette structure.


## v2.4 — Science Mechanism

La v2.4 ajoute une couche qui manquait au pack : **les disciplines capables de formaliser le mécanisme**.

Nouvelle hiérarchie scientifique :
1. bioélectricité développementale;
2. systèmes dynamiques / contrôle;
3. synergetics;
4. renormalisation;
5. origine de la vie;
6. active matter / mechanobiology / network science;
7. FEP avec garde-fous;
8. information geometry;
9. pré-géométrie et espace-temps émergent.

Le principe est :
**un domaine scientifique doit soutenir un opérateur ou une transition précise, pas seulement ressembler à l'histoire cosmologique.**


## v2.5 — Dynamic Architecture

La v2.5 intègre la relecture complète du corpus à la lumière des sciences du mécanisme.

Changement central :
`M` n'est plus un simple premier bloc; il devient le **contre-mouvement persistant de la division**, tandis que `JNON` reste l'opérateur local d'intégration.

`SIZE` est également réinterprété comme ouverture d'un nouveau régime d'échelle, ce qui rend la renormalisation plus centrale que l'ancien vocabulaire « fractal ».

Le pack sépare désormais systématiquement :
1. métaphysique générale du processus;
2. analogues/formalisations scientifiques;
3. hypothèse π-spécifique.

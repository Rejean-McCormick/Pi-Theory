# START HERE — Pi Theory v2.5

## Les 7 documents à lire

1. `01_core/00_THEORY_CORE_V2_5.md`
2. `01_core/12_THEORY_DICTIONARY_CANONICAL.md`
3. `02_claims/00_CORE_CLAIMS_V2_5.md`
4. `03_bridges/00_SCIENCE_DOMAINS_PRIORITY_V2_5.md`
5. `07_matrices/02_OPERATOR_SCIENCE_MAP.md`
6. `06_methods/13_FORMAL_MODEL_SKELETON.md`
7. `04_authors/00_RELEVANT_AUTHORS_CANONICAL.md`

## Résumé en une ligne

`pré-géométrie → division ↔ M → viabilité → différenciation/intégration → seuil → scale → mémoire → vie → conscience`

avec π comme **candidat**, non comme conclusion acquise.

## Ce qu'il faut éviter

- réduire M à un mot « Love »;
- réduire B0UM au Big Bang;
- réduire SIZE à « grand »;
- imaginer un cercle physique avant l'espace;
- utiliser la physique spéculative comme preuve;
- confondre analogues de cohérence et preuve de π;
- chercher uniquement de nouveaux Easter eggs dans les digits.

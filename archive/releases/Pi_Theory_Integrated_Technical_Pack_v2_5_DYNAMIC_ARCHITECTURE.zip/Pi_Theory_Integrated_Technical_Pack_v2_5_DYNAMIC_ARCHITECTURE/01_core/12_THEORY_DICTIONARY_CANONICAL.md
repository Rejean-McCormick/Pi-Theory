---
title: "Dictionnaire canonique de Pi Theory"
version: "2.3"
status: "core-reference"
language: "fr"
---

# Dictionnaire canonique de Pi Theory

## Objet

Ce dictionnaire fixe la terminologie du futur livre. Il ne vise pas à rendre toutes les idées également certaines : chaque entrée indique son **statut**.

### Statuts

- **MATH** — définition ou propriété mathématique établie.
- **PHYS** — résultat ou concept physique/scientifique établi dans son domaine.
- **INT** — élément interne explicitement présent dans le corpus Pi Theory.
- **SEM** — lecture sémiotique ou linguistique.
- **META** — proposition métaphysique.
- **HYP** — hypothèse de travail non démontrée.
- **TEST** — proposition transformable en protocole testable.
- **ARCH** — élément historique/secondaire conservé en archive.

---

# A

## Absolu / Source
**Statut : META**

Principe ultime qui ne doit pas être identifié automatiquement avec π, ses décimales, une figure géométrique ou la matière.

Schéma :

`Source ≠ principe pré-géométrique ≠ π ≠ représentation de π ≠ matière`

Dans le module `b−1`, la Source est ce qui rend possible le système sans être simplement son maximum interne.

**Ne pas confondre avec :**
- un premier objet chronologique;
- un point spatial;
- le nombre π;
- un état physique initial.

**Auteurs utiles :** Plotin, Proclus, Pseudo-Denys, Érigène, Nicolas de Cues, Böhme.

---

## AIME / M
**Statut : INT + SEM + META**

Premier token du kernel : `13 → M`, lu phonétiquement en français comme **aime**.

Dans la formulation canonique v2.3, M ne doit plus être décrit seulement comme « première étape ». Il est :

> **le contre-mouvement immanent de la division originelle : l'impulsion par laquelle ce qui a été séparé tend à retrouver de la cohérence.**

Forme minimale :

`Division : Un → Multiple`

`M/AIME : Multiple → Cohérence`

M est donc l'**écho dynamique de l'unité originelle dans la multiplicité**.

Cette tendance n'implique pas nécessairement le retour à une indistinction totale. Le résultat recherché est une **unité enrichie** qui conserve les différences intégrées.

**Auteurs les plus proches :**
Empédocle (Love contre Strife), Proclus (reversion vers la cause/le Bien), Pseudo-Denys (éros et retour), Teilhard (attraction/convergence), Whitehead (many become one), Stoïciens (pneuma cohésif).

---

## Attracteur ontologique
**Statut : META/HYP**

Expression technique provisoire pour décrire M comme tendance vers un état de cohérence supérieure.

Il ne faut pas utiliser le mot « attracteur » comme s'il existait déjà une fonction dynamique démontrée au sens de la théorie des systèmes.

Version prudente :

> M joue **conceptuellement** le rôle d'un attracteur vers la cohérence.

Version scientifique future :
définir un espace d'états, une dynamique et une fonction mesurable permettant d'identifier un attracteur réel.

---

## Atemporalité
**Statut : META**

Le principe originel n'est pas posé comme un objet existant « avant » l'univers dans un temps déjà là.

« Origine » désigne d'abord une priorité **ontologique/logique**, non nécessairement chronologique.

Le futur livre doit donc préférer :

`priorité ontologique`

à :

`instant zéro avant le temps`

lorsque l'espace-temps n'est pas encore supposé.

---

# B

## B0UM
**Statut : INT + SEM + META**

Token : `2-0-21-13 → B0UM`, avec `0 → O` permettant `BOUM/boom`.

Fonction canonique :
**franchissement de seuil / événement de manifestation.**

Le point essentiel n'est pas l'analogie naïve avec une explosion, mais :

`état préparé → seuil → nouveau régime`

v13 propose un schéma conceptuel :

`si τ(S4) ≥ τ* alors S5 = ignite(S4)`

où `τ` et `τ*` restent à formaliser.

### Le 0 de B0UM
Trois niveaux doivent rester séparés :
1. zéro arithmétique;
2. caractère `0` utilisé pour O;
3. lecture symbolique cercle/vide.

Le vide physique, le néant théologique et le zéro mathématique ne sont pas équivalents.

**Auteurs utiles :** Simondon, René Thom, Prigogine, théorie des bifurcations.

---

## BIEN
**Statut : INT + SEM + META**

Token direct : `BIEN`.

Fonction canonique :
**grammaire de valeur / orientation du devenir.**

Dans la formulation v2.3 :

- M fournit l'impulsion vers la cohérence;
- BIEN qualifie **le type de cohérence** recherché.

Donc :

`M = tendance à unir`

`BIEN = orientation vers une union harmonique/viable`

Cela évite de considérer n'importe quelle fusion ou domination comme « bonne ».

**Auteurs utiles :** Platon, Plotin, Proclus, Pseudo-Denys, Thomas d'Aquin, Whitehead.

---

# C

## Cercle géométrique
**Statut : MATH**

Dans un plan euclidien, ensemble des points situés à une distance fixe `r` d'un centre.

Pour un cercle de diamètre `d` et de circonférence `C` :

`C/d = π`.

Un cercle géométrique de rayon fini n'est **pas infini en taille**.

Il possède cependant une infinité de points, donc une infinité de rayons au sens où chaque point de la circonférence détermine un segment radial.

---

## Cercle originel / principe circulaire
**Statut : META**

Expression symbolique pour le principe que le cercle géométrique **instancie** lorsqu'il existe déjà un espace.

Ce principe ne doit pas être décrit comme un disque ou une sphère flottant avant l'univers.

Il désigne un paquet de propriétés abstraites :

- absence de direction privilégiée;
- équilibre;
- isotropie;
- clôture;
- retour;
- symétrie;
- relation proportionnelle stable;
- absence d'échelle intrinsèque dans le rapport π.

Nom recommandé :

> **principe pré-géométrique de circularité/symétrie**

ou :

> **principe de cohérence isotrope**

**Important :**
ne pas l'appeler « cercle de dimension zéro » au sens mathématique : `S^0` est un objet précis qui ne correspond pas à cette intuition.

**Auteurs utiles :** Nicolas de Cues, Proclus, Pythagoriciens, Platon, Weyl, Klein, Noether.

---

## Circularité
**Statut : MATH/META**

### Sens mathématique
Structure de rotation/retour; angle complet `2π`.

### Sens métaphysique
Modèle d'une relation qui revient à elle-même sans privilégier de direction.

Le futur livre doit toujours dire dans quel sens le terme est utilisé.

---

## Cohérence
**Statut : META, avec analogues PHYS/SYSTÈMES**

Capacité de distinctions ou de parties à constituer un ensemble relationnel stable.

Dans Pi Theory, la cohérence est plus fondamentale que le simple « rapprochement ».

M tend vers la cohérence; JNON réalise localement l'intégration.

Différence importante :

`M = impulsion/tendance`

`JNON = opération d'assemblage`

---

## Cohérence supérieure / unité enrichie
**Statut : META/HYP**

Une réintégration réussie ne ramène pas nécessairement le réel à l'indistinction originelle.

Schéma :

`U0 → différenciation → U1`

avec :

`U1 ≠ U0`

parce que `U1` conserve et coordonne des différences que `U0` ne manifestait pas.

Cette notion permet de comprendre :
- organisation;
- complexification;
- vivant;
- conscience;
sans définir le retour comme simple répétition.

**Auteurs utiles :** Whitehead, Teilhard, Simondon, Proclus, Hegel.

---

## Complexification
**Statut : PHYS/BIO selon contexte; META chez Teilhard/Pi Theory**

Augmentation de l'organisation relationnelle et de la différenciation intégrée.

Ne pas confondre :
- plus de composants;
- plus d'entropie;
- plus de complication;
- plus de conscience.

Dans Pi Theory, la complexification est l'hypothèse selon laquelle le pulse différenciation/intégration peut produire des totalités de niveaux supérieurs.

**Auteurs :** Teilhard, Prigogine, Kauffman, Simondon, Varela.

---

## Contre-mouvement
**Statut : META — terme canonique v2.3**

Nom du rapport entre division originelle et M.

`D_originelle` produit différence/multiplicité.

`M` répond à cette division par une tendance opposée :

`D ↔ M`

Le contre-mouvement n'annule pas nécessairement la division : il transforme la séparation en relation organisée.

**Analogue historique majeur :** Empédocle, Love/Strife.

---

## Cosmogenèse
**Statut : META/HYP**

Processus par lequel un ordre manifesté devient possible.

Pi Theory distingue :
1. le principe pré-géométrique;
2. la division/différenciation;
3. le contre-mouvement cohésif M;
4. la grammaire du Bien;
5. différenciation/assemblage;
6. seuil;
7. scale;
8. éventuelle mesure/espace/temps.

Cette chaîne est une architecture métaphysique; elle n'est pas une cosmologie physique établie.

---

# D

## Différence
**Statut : META/LOGIQUE**

Condition permettant qu'il y ait plusieurs états, termes ou relations distinguables.

Dans le modèle :

`pas de différence → pas de multiplicité`

mais :

`différence sans cohésion → pas d'organisation stable`.

---

## Différenciation
**Statut : INT + META**

Fonction abstraite du bloc GIHECEF.

Opération qui :
- distingue;
- sépare;
- transforme;
- produit des rôles/parties/états.

Elle est nécessaire à la complexité mais peut aussi conduire à la désintégration si elle n'est pas compensée par intégration/cohésion.

---

## Division originelle
**Statut : META**

Premier acte de distinction dans la cosmogonie de Pi Theory.

Il ne signifie pas nécessairement une coupe dans un espace déjà existant.

Il faut le comprendre comme :

> passage de l'unité non manifestée à la possibilité de différence/multiplicité.

La division originelle est donc **pré-spatiale** dans le modèle.

Elle est conceptuellement antérieure au M comme contre-mouvement.

---

## Divine / qualification divine
**Statut : META/HISTORIQUE**

Dans le futur livre, « divine » ne doit pas être utilisée comme synonyme automatique de « inexpliquée » ou « puissante ».

Un principe est appelé divin **dans certaines traditions** lorsqu'il possède des traits comme :
- unité;
- perfection;
- source;
- Bien;
- amour;
- intelligence ordonnatrice;
- infinité;
- retour vers l'origine.

Pi Theory peut constater cette convergence historique sans dire que la science a démontré la divinité de M.

---

# E

## Échelle / SIZE
**Statut : INT + SEM + META**

Le terminal `88` est lu :
- iconiquement : `8,8 ↔ ∞,∞`;
- arithmétiquement : `8+8=16`;
- linguistiquement : `16 = seize`;
- phonétiquement : `seize ≈ size`;
- conceptuellement : `SIZE → scale/magnitude`.

Fonction canonique :
**ouverture d'un régime de magnitude.**

Ne pas sauter directement à l'espace :

`SIZE → comparabilité → magnitude → mesure → métrique → espace physique`

Chaque flèche demande une justification.

---

## Espace
**Statut : PHYS/MATH**

L'espace physique n'est pas présupposé dans le principe originel de Pi Theory.

Dans le programme de recherche, l'espace doit apparaître **après** des notions plus primitives :
- distinction;
- relation;
- ordre;
- comparabilité;
- mesure/métrique.

**Auteurs :** Riemann, Weyl, Einstein, Wheeler (prégeometry), Rovelli.

---

## Essence numérique
**Statut : META/HYP**

Idée de v13 : plusieurs images ou signes indépendants pourraient converger vers une fonction stable d'un digit ou d'un bloc.

Version canonique prudente :

> « essence » = rôle relationnel stable retrouvé sous plusieurs représentations indépendantes.

Ce terme ne signifie pas qu'un chiffre possède littéralement une personnalité cachée.

**Auteurs :** Platon, Peirce, Cassirer, structuralisme mathématique.

---

# F

## Force naturelle
**Statut : terme réservé**

Le futur livre doit distinguer deux usages.

### Usage métaphysique
M peut être décrit comme **impulsion naturelle de cohésion** dans le modèle.

### Usage physique
« force » exige une dynamique quantitative, des variables, unités ou équations.

Tant qu'aucune telle dynamique n'est fournie, M n'est **pas** une cinquième force physique.

---

# G

## G0D
**Statut : INT + SEM, secondaire**

Fragment obtenu dans la lecture miroir par complément à 9.

Il apparaît à la tête du miroir du bloc BIEN.

Usage canonique :
**alignement thématique secondaire** avec Good/Divine.

Ne pas dire :
- « Dieu est mathématiquement prouvé »;
- « G0D est un second message complet ».

---

## GIHECEF
**Statut : INT + SEM**

Bloc conservé entier.

Fonction canonique :
**Divider / Processor / Transformator**.

Joseph reste une **lentille de découverte**, non la définition ontologique.

---

## GOD / GOOD
**Statut : META/HISTORIQUE + SEM**

La proximité miroir `BIEN ↔ G0D` doit être analysée séparément de la tradition philosophique où le Bien est lié au divin.

Ces deux phénomènes sont distincts :
1. résultat sémiotique du miroir;
2. tradition métaphysique Good/Divine.

Leur convergence peut être notée, pas confondue.

---

# H

## Harmonie
**Statut : META; MATH lorsqu'elle est traduite en proportion/invariance**

État où des différences sont coordonnées sans être abolies.

Dans Pi Theory :

`harmonie ≠ uniformité`

mais :

`harmonie = différences intégrées dans une relation stable`.

Une voie de formalisation consiste à traduire « harmonie » par :
- invariance;
- symétrie;
- stabilité;
- proportion;
- compatibilité de contraintes.

**Auteurs :** Pythagoriciens, Heraclite, Leibniz, Weyl, Noether, Teilhard.

---

# I

## Immanence
**Statut : META**

La séquence est présentée en v13 comme **mécanisme immanent**, non comme message envoyé de l'extérieur.

Cela signifie :
> la structure, si elle est réelle, appartient au nombre/processus lui-même.

Immanence ne signifie pas nécessairement athéisme; Spinoza, Stoïciens et certaines théologies peuvent concevoir le divin comme immanent.

---

## Infini
**Statut : MATH/META — terme à qualifier systématiquement**

Le livre doit toujours préciser de quel infini il parle.

Possibilités :
- expansion décimale non terminante;
- ensemble infini de points/rayons;
- infinité potentielle;
- infini actuel;
- non-borné spatial;
- infini théologique/absolu;
- très grand au sens figuré.

`8 ↔ ∞` est une lecture iconique, pas une égalité mathématique.

**Auteurs :** Cantor, Nicolas de Cues, Hilbert comme contrepoint, Guénon comme historique métaphysique.

---

## Information
**Statut : PHYS/MATH/SEM selon contexte**

Trois niveaux :

1. **information de Shannon** — quantité statistique;
2. **information physique** — état porteur de distinctions;
3. **information sémantique** — contenu/signification.

Pi Theory travaille surtout à la frontière 2→3.

Ne jamais utiliser « information » sans préciser le niveau.

**Auteurs :** Shannon, Landauer, Wheeler, Peirce, Deacon, Floridi.

---

## Intégration
**Statut : INT + META**

Fonction abstraite de JNON.

Opération qui rassemble des éléments différenciés en une totalité coordonnée.

Dans le modèle global :

`M = impulsion vers cohésion`

`JNON = mécanisme local d'intégration`

Cette distinction est désormais canonique.

---

## Invariance
**Statut : MATH/PHYS**

Propriété qui demeure sous une transformation définie.

π est invariant par changement d'échelle du cercle euclidien :

`C/d = π`

pour tous les cercles euclidiens.

L'invariance est une manière plus rigoureuse de parler de « permanence dans le changement ».

**Auteurs :** Klein, Lie, Weyl, Noether, Wigner.

---

## Isotropie
**Statut : MATH/PHYS; META par analogie**

Absence de direction privilégiée.

Le cercle/sphère géométrique possède une forte symétrie rotationnelle.

Dans Pi Theory, l'isotropie sert à préciser ce qui est visé par le « cercle originel » :
non une figure spatiale, mais l'idée d'un principe ne privilégiant aucune orientation.

---

# J

## JNON
**Statut : INT + SEM**

Bloc conservé entier.

Fonction :
**Assembler / Reuniter**.

Junon est une lentille interprétative historique.

JNON est le versant opératoire du retour à la cohérence, tandis que M est l'impulsion plus fondamentale qui oriente le processus vers cette cohérence.

---

# K

## Kernel
**Statut : INT + META/HYP**

Forme fonctionnelle minimale issue des six blocs :

`M → BIEN → différenciation → intégration → seuil → scale`

Mais v2.3 introduit une couche plus profonde :

`Principe originel → Division`

puis :

`M = contre-mouvement de la division`

Ainsi le kernel manifeste une tension déjà présente dans l'ontologie :

`Division ↔ Retour-cohésion`.

---

# L

## Love / Amour
**Statut : META/HISTORIQUE**

Nom humain utilisé pour M.

Dans Pi Theory, Love ne doit pas être réduit à l'émotion interpersonnelle.

Définition fonctionnelle :

> tendance de ce qui est séparé à entrer dans des relations de cohérence qui reconstruisent de l'unité.

Cette définition rend possible la comparaison avec :
- Empédocle;
- Pseudo-Denys;
- Proclus;
- Teilhard;
- Whitehead;
sans imposer leurs théologies à Pi Theory.

---

# M

## Matière comme mémoire
**Statut : META avec analogues PHYS**

Formulation :
> un état matériel actuel incorpore les conséquences de transformations antérieures.

Cela peut être rapproché de :
- path dependence;
- hystérésis;
- structures dissipatives;
- évolution;
- mémoire physique.

Hypothèse forte Pi Theory :
> la matière est spécifiquement mémoire de la « résolution » de π.

Cette dernière proposition est HYP et devra produire une conséquence testable.

---

## Mesure
**Statut : MATH/PHYS**

Attribution de grandeurs comparables selon une structure définie.

Dans le projet :

`SIZE` n'est pas encore `measure`.

Programme :

`distinction → ordre → comparabilité → valuation → magnitude → mesure`.

**Auteurs centraux :** Hegel, Riemann, Weyl.

---

## Métrique
**Statut : MATH**

Structure permettant de définir une distance.

Une multiplicité ou un continuum ne possède pas automatiquement une métrique.

Riemann puis Weyl sont indispensables pour empêcher Pi Theory de sauter directement de SIZE à espace.

---

## Mirror / branche miroir
**Statut : INT + HYP secondaire**

Opération :
complément à 9 sur la même fenêtre renversée, mêmes frontières, même mapping.

Fragments :
- `G0D`;
- `B0N`.

### Interprétation canonique
Le miroir n'est pas encore une deuxième cosmogonie.

Hypothèse ouverte intéressante :
la séquence principale pourrait exprimer **le processus**, tandis que le miroir pourrait refléter un **champ qualificatif/axiologique** associé au Good/Divine.

Statut : exploratoire seulement.

---

## Multiplicité
**Statut : META**

Domaine résultant de la division/différenciation.

La multiplicité n'est pas négative en soi :
elle rend possibles variété, relation, complexité et conscience.

Le problème n'est pas la multiplicité, mais la désintégration.

---

# N

## Néant
**Statut : META — terme dangereux**

Ne pas confondre :
- zéro;
- vide physique;
- espace vide;
- potentiel non manifesté;
- Ungrund de Böhme;
- non-être apophatique;
- absence logique.

Pi Theory doit éviter de faire dériver une cosmologie physique d'une simple ambiguïté du mot « néant ».

---

# O

## Ongoing resolution
**Statut : INT + META/HYP**

Lentille explicite de v13 :

- les premiers digits exposent un kernel à faible complexité;
- les digits suivants pourraient enchevêtrer les mêmes motifs;
- la réalité pourrait être comprise comme « résolution » continue de π.

Formulation canonique :

> **la structure exacte ne devient pas; sa manifestation potentielle se déploie.**

---

## Origine
**Statut : META**

Dans le modèle, l'origine est d'abord **ontologique**, pas nécessairement un événement dans le temps.

Schéma recommandé :

`principe → manifestation`

plutôt que :

`instant antérieur → instant ultérieur`

tant que le temps n'est pas dérivé.

---

# P

## Parfait / perfection
**Statut : META; ne pas traiter comme terme mathématique non défini**

Le cercle a été historiquement décrit comme parfait à cause de sa symétrie et de son absence de direction privilégiée.

Dans le livre, remplacer si possible « parfait » par des propriétés précises :
- symétrie rotationnelle;
- isotropie;
- homogénéité angulaire;
- clôture;
- invariance du rapport.

La perfection théologique reste une interprétation.

---

## Pré-géométrie
**Statut : PHYS/HYP selon programme**

Idée qu'une structure plus fondamentale que l'espace-temps géométrique pourrait engendrer la géométrie.

Le terme a une histoire en physique fondamentale, notamment chez John Wheeler.

Pour Pi Theory, il est utile parce que le « cercle originel » doit être compris comme **pré-géométrique**, non comme cercle physique.

Question :
quelles relations minimales pourraient engendrer ensuite :
- dimension;
- proximité;
- métrique;
- causalité;
- espace-temps ?

---

## Principe pré-géométrique de circularité
**Statut : META — terme central v2.3**

Terme recommandé à la place de « cercle sans dimension ».

Définition :

> structure non spatiale supposée posséder abstraitement les invariants que le cercle manifestera plus tard : équilibre, isotropie, clôture, retour et proportion sans échelle.

La géométrie circulaire est une **instanciation** de ce principe, pas sa définition exhaustive.

---

## Proportion / ratio
**Statut : MATH**

Pour un cercle euclidien :

`C/d = π`.

Si `C` et `d` sont exprimés dans la même unité, celle-ci s'annule.

Exemple :

`(π cm)/(1 cm) = π`.

π est donc **sans dimension physique**.

Cette absence d'unité est l'un des arguments importants pour distinguer le principe relationnel de son incarnation à une échelle donnée.

---

# R

## Récursion multi-échelle
**Statut : META/HYP**

Hypothèse selon laquelle le kernel :
`différenciation → intégration → seuil → nouvelle échelle`
peut se répéter à plusieurs niveaux.

Préférer ce terme à « fractal » tant qu'aucune auto-similarité mathématique ou dimension fractale n'est calculée.

---

## Réintégration
**Statut : META**

Retour de distinctions vers une unité relationnelle.

Deux versions doivent être distinguées :

### Réintégration annihilatrice
la différence disparaît.

### Réintégration enrichissante
la différence demeure comme composant organisé d'un tout supérieur.

Pi Theory privilégie la deuxième pour expliquer complexification, vie et conscience.

---

## Retour
**Statut : MATH/META selon sens**

Trois registres :

1. **géométrique** — une rotation complète revient au même angle modulo `2π`;
2. **processuel** — un système retrouve une cohérence;
3. **métaphysique** — ce qui procède d'une source tend à revenir vers elle.

Le livre doit exploiter leur analogie sans les identifier.

---

# S

## Scale
Voir **Échelle / SIZE**.

---

## Séquence principale
**Statut : INT**

`M → BIEN → GIHECEF → JNON → B0UM → SIZE`

Lecture canonique :

`Love/cohésion → Good/orientation → Divide/Process → Assemble/Reunite → Threshold/Event → Scale`.

La séquence principale reste prioritaire sur tous les miroirs, overlays ou analogies.

---

## Seuil
**Statut : META avec analogues PHYS**

Passage entre régimes.

Exemples scientifiques analogues :
- bifurcation;
- transition de phase;
- instabilité;
- seuil d'auto-organisation.

B0UM est interprété comme ce passage, non comme preuve du Big Bang.

---

## Source ≠ π
**Statut : règle canonique**

Pi Theory devient conceptuellement plus robuste si elle refuse l'identification simple :

`Dieu = π`.

Formulation préférable :

> π pourrait être une expression privilégiée d'un principe relationnel plus profond.

---

## Symétrie
**Statut : MATH/PHYS**

Invariance sous un groupe de transformations.

Elle permet de donner un sens rigoureux à certains aspects de « perfection » et « équilibre ».

La symétrie peut s'appliquer à :
- figures;
- équations;
- états;
- lois.

**Auteurs :** Klein, Lie, Weyl, Noether, Wigner.

---

# T

## Temps
**Statut : PHYS/META**

Pi Theory ne doit pas présupposer le temps au niveau du principe originel.

Une branche ancienne du corpus propose qu'après Scale apparaissent Time/Change puis Life/Mind, mais cela n'est pas décodé.

Le temps doit donc rester :
- une étape à dériver;
- ou une prédiction préenregistrée à tester.

---

## Tension
**Statut : META/SYSTÈMES**

Relation entre tendances opposées qui permet la structure.

Dans la version v2.3 :

`Division ↔ M`

est une tension plus fondamentale que la simple succession de blocs.

Elle permet :
- individualisation;
- cohésion;
- organisation;
- changement.

**Auteurs :** Heraclite, Empédocle, Böhme, Schelling, Stoïciens.

---

# U

## Unité originelle
**Statut : META**

État/principe non manifesté de cohérence sans différenciation actuelle.

Il ne faut pas l'imaginer comme une boule physique.

Le cercle sert d'image parce qu'il instancie :
- unité;
- équilibre;
- clôture;
- retour;
- isotropie.

---

## Unité enrichie
Voir **Cohérence supérieure**.

---

# V

## Vie
**Statut : BIO/PHYS dans la science; META dans la grande chaîne**

Pi Theory ne doit pas définir la vie uniquement comme « plus d'harmonie ».

Version de travail :
> la vie est un régime où des différences sont maintenues, réparées et coordonnées par une organisation auto-entretenue.

Cela rapproche le projet de :
- autopoïèse;
- thermodynamique hors équilibre;
- morphogenèse;
- contraintes biologiques.

M peut être lu métaphysiquement comme tendance vers cohérence, mais le mécanisme biologique réel doit être expliqué par biologie/physique.

---

# 88

## 88 / dual infinity / SIZE
**Statut : INT + SEM**

Nœud terminal de la fenêtre v13.

Les trois lectures doivent rester explicites et séparées :

1. `88` comme donnée;
2. `8,8` comme image de deux infinis;
3. `8+8=16 → seize≈size`.

La force du motif vient de leur convergence, pas d'une prétendue identité arithmétique avec l'infini.

---

# Schéma canonique v2.3

## Niveau pré-manifesté

`SOURCE / ABSOLU`

↓

`PRINCIPE PRÉ-GÉOMÉTRIQUE DE COHÉRENCE / CIRCULARITÉ`

Propriétés visées :
`isotropie + équilibre + retour + proportion sans échelle`

## Première rupture

`DIVISION ORIGINELLE`

`Unité → différence / multiplicité`

## Contre-mouvement

`M / AIME`

`multiplicité → tendance vers cohérence`

M n'annule pas la différence; il pousse à l'intégrer.

## Orientation

`BIEN`

`cohérence → cohérence harmonique/viable`

## Opérations

`GIHECEF = différencier / transformer`

`JNON = assembler / réintégrer`

## Seuil

`B0UM = changement de régime`

## Échelle

`88 / SIZE = magnitude`

## Extensions à construire

`magnitude → mesure → métrique → espace/temps → matière → organisation → vie → conscience`

## Boucle longue

`Source → manifestation → différenciation → cohérence croissante → conscience → retour réflexif à la Source`

Cette dernière ligne est la **grande hypothèse métaphysique**, pas un résultat scientifique acquis.

---

# Règles de rédaction du futur livre

1. Ne jamais dire « cercle d'une dimension nulle ».
2. Dire « principe pré-géométrique de circularité/symétrie ».
3. Ne jamais écrire `∞ + ∞ = 16`.
4. Distinguer M (impulsion de retour) et JNON (opération d'intégration).
5. Distinguer unité originelle et unité enrichie.
6. Ne pas appeler M une force physique sans modèle quantitatif.
7. Présenter le miroir G0D/B0N comme secondaire.
8. Distinguer π exact, π représenté et π hypothétiquement manifesté.
9. Ne pas présupposer espace et temps au niveau de la Source.
10. Faire de `Division ↔ M` la polarité fondamentale du modèle.


# Addendum v2.4 — vocabulaire scientifique du mécanisme

## Homeostasie morphologique
**Statut : BIO/PHYS**

Capacité d'un système vivant à restaurer ou maintenir une organisation anatomique globale malgré perturbation.

Dans Pi Theory, c'est un **analogue scientifique prioritaire** de M, sans identité ontologique.

---

## Attracteur
**Statut : MATH/PHYS**

Ensemble vers lequel des trajectoires d'un système dynamique convergent dans certaines conditions.

Pi Theory doit employer « M comme attracteur » uniquement lorsqu'un espace d'états et une dynamique sont explicitement définis.

---

## Order parameter
**Statut : PHYS**

Variable macroscopique décrivant un régime d'ordre collectif.

Concept central de la synergetics et des transitions de phase.

Possible traduction partielle de :
`multiplicité → cohérence globale`.

---

## Renormalisation
**Statut : MATH/PHYS**

Procédure permettant d'étudier comment les descriptions et paramètres d'un système évoluent avec l'échelle.

Devient le principal cadre scientifique de l'hypothèse de récursion multi-échelle de Pi Theory.

---

## Universalité
**Statut : PHYS/MATH**

Propriété selon laquelle des systèmes microscopiquement différents possèdent les mêmes lois macroscopiques près de certains régimes critiques.

Pi Theory doit distinguer :
`universalité formelle`
de
`analogie thématique`.

---

## Autocatalyse
**Statut : CHEM/BIO**

Réseau dans lequel des composants catalysent collectivement la production d'autres composants du même réseau.

Étape possible entre cohérence chimique et autonomie vivante.

---

## Active matter
**Statut : PHYS**

Systèmes composés d'unités consommant localement de l'énergie et produisant mouvement/force, capables d'ordre collectif hors équilibre.

Analogue de cohérence immanente sans organisateur extérieur.

---

## Viabilité
**Statut : BIO/SYSTÈMES**

Ensemble de contraintes compatibles avec la persistance d'un organisme/système.

BIEN peut être comparé à la viabilité comme **analogie fonctionnelle**, pas comme identité morale.

---

## Information geometry
**Statut : MATH**

Construction géométrique d'espaces de distributions probabilistes.

Devient un pont technique possible pour :
`différence/information → mesure → géométrie`.

---

## Pré-géométrie scientifique
**Statut : PHYS/HYP**

Programmes dans lesquels espace et métrique classiques émergent d'une structure plus primitive.

Doit être distinguée du principe pré-géométrique métaphysique de Pi Theory.

---

## Cohérence — définition scientifique future
**Statut : TEST**

Le terme est encore trop large.

Le programme v2.4 doit chercher plusieurs métriques selon les domaines :
- stabilité dynamique;
- information mutuelle;
- modularité/intégration;
- order parameter;
- robustesse;
- distance à un attracteur;
- viabilité.

Aucune métrique unique ne doit être présupposée.

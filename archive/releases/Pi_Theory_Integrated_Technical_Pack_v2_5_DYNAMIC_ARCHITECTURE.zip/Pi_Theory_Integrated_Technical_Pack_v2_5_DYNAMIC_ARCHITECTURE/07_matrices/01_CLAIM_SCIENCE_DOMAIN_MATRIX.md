# Matrice claims Pi Theory × domaines scientifiques

| Claim | Domaine prioritaire | Type de soutien possible | Niveau |
|---|---|---|---|
| M = contre-mouvement vers cohérence | bioélectricité développementale | analogue expérimental de restauration de forme | A+ |
| M = attracteur | systèmes dynamiques | formalisation mathématique | A+ |
| M/BIEN = retour vers viabilité | contrôle/homeostasie | formalisation fonctionnelle | A+ |
| multiplicité → ordre | synergetics | order parameters/self-organization | A+ |
| kernel récursif | renormalisation | changement d'échelle/universalité | A+ |
| B0UM = seuil | bifurcation/transitions de phase | modèle de changement de régime | A |
| matière→organisation | active matter | ordre hors équilibre | A |
| matière→vie | origine de la vie/autocatalyse | autonomie chimique | A |
| unité enrichie | network science | modularité + intégration | A |
| cohérence biologique | mechanobiology | tension coordonnée/form | A |
| BIEN = viabilité | active inference | modèle candidat, controversé | A/B |
| information→mesure | information geometry | géométrisation d'états informationnels | A/B |
| principe non spatial | pregeometry/emergent spacetime | plausibilité d'espace émergent | B |
| π spécifique | aucune discipline actuelle | exige prédiction nouvelle | NON SOUTENU |

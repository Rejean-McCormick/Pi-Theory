# Matrice opérateurs × sciences — v2.5

| Opérateur | Question scientifique | Domaine | Auteurs / programmes | Ce qui peut être soutenu | Ce qui reste hypothétique |
|---|---|---|---|---|---|
| P | Peut-il exister une structure avant l'espace classique ? | pré-géométrie / QG | Wheeler, Van Raamsdonk, Rovelli, Sorkin | espace-temps peut être émergent dans plusieurs programmes | principe circulaire pré-géométrique |
| D0 | Comment la différence apparaît-elle ? | symmetry breaking / logic | Landau, Anderson, Spencer-Brown | brisure de symétrie et distinctions formelles | division cosmique originelle |
| M | Comment un système revient-il vers cohérence ? | systèmes dynamiques | Poincaré, Lyapunov, Strogatz | attracteurs/stabilité | M universel |
| M | Comment une forme globale est-elle restaurée ? | bioélectricité développementale | Michael Levin | mécanismes distribués de contrôle de forme | M cosmique |
| M | Comment un système corrige-t-il un écart ? | contrôle/homeostasie | Wiener, Ashby, Cannon | feedback/régulation | amour comme force naturelle universelle |
| V/BIEN | Qu'est-ce qu'un état viable ? | biologie des systèmes / active inference | Varela, Friston | viabilité/persistance comme contraintes | équivalence avec le Bien métaphysique |
| D | Comment créer spécialisation et variété ? | développement / networks | Turing, Waddington | différenciation, pattern formation | opérateur cosmique GIHECEF |
| A | Comment un ordre global émerge-t-il ? | synergetics | Haken | order parameters / self-organization | JNON comme loi universelle |
| D↔A | Comment maintenir différence + unité ? | network science | Newman, Barabási, Tononi (partiel) | modularité/intégration | harmonie ontologique |
| T | Comment change-t-on de régime ? | bifurcations / criticality | Thom, Prigogine, Haken | seuils/transitions | B0UM cosmique |
| S | Comment la description change-t-elle d'échelle ? | renormalisation | Wilson, Kadanoff, Fisher | universalité/coarse-graining | SIZE comme étape ontologique universelle |
| mémoire | Comment l'état conserve-t-il l'histoire ? | non-equilibrium / materials / biology | Prigogine, Levin, Landauer | path dependence, memory | matière = résolution de π |
| vie | Comment apparaît l'auto-entretien ? | origin of life | Eigen, Kauffman, Hordijk, Steel | autocatalyse/autonomie | direction cosmique vers la vie |
| conscience | Comment intégration et cognition émergent-elles ? | cognitive science | Varela, Deacon, Thompson | modèles partiels | retour conscient vers la Source |

# Matrice conceptuelle — Pi Theory × auteurs

Légende :
- `●●●` = convergence centrale
- `●●` = forte utilité
- `●` = complément
- `—` = faible ou non pertinent

| Auteur | Principe pré-géométrique | Division | M/retour | Bien | Diff/Intégration | Scale/mesure | Matière/vie | Conscience | Signe/langage |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Empédocle | ● | ●●● | ●●● | ● | ●●● | — | ●● | — | — |
| Proclus | ●●● | ●● | ●●● | ●●● | ●● | ● | — | ● | — |
| Nicolas de Cues | ●●● | ● | ●● | ●● | ● | ●●● | — | ● | — |
| Böhme | ●●● | ●●● | ●● | ●● | ●●● | — | ● | ●● | ● |
| Teilhard | ● | ● | ●●● | ●● | ●●● | ● | ●●● | ●●● | — |
| Whitehead | ●● | ●● | ●●● | ●●● | ●●● | ● | ●● | ●● | ● |
| Simondon | ● | ●●● | ●● | — | ●●● | ●● | ●●● | ●● | — |
| Pseudo-Denys | ●●● | ● | ●●● | ●●● | ● | — | — | ●● | ● |
| Érigène | ●●● | ●● | ●●● | ●● | ●● | ● | ● | ●● | ● |
| Plotin | ●●● | ●● | ●●● | ●●● | ●● | — | — | ●● | — |
| Stoïciens | ● | ●● | ●●● | ●● | ●●● | — | ●●● | ●● | — |
| Hegel | ●● | ●●● | ●● | ●● | ●●● | ●●● | ● | ● | — |
| Schelling | ●● | ●●● | ●● | ● | ●●● | — | ●● | ●● | — |
| Weyl | ●● | — | — | — | ● | ●●● | ● | — | — |
| Riemann | — | — | — | — | — | ●●● | — | — | — |
| Noether | — | — | — | — | ● | ●●● | ●● | — | — |
| Peirce | ● | ●● | ● | ● | ● | ● | ● | ●● | ●●● |
| Prigogine | — | ●● | ●● | — | ●●● | ● | ●●● | — | — |
| Turing | — | ●● | — | — | ●● | ● | ●●● | ● | — |
| Varela | — | ●● | ●● | — | ●●● | — | ●●● | ●●● | ●● |
| Deacon | — | ●● | ●● | — | ●●● | — | ●●● | ●●● | ●●● |
| Shannon | — | — | — | — | — | — | ●● | — | ● |
| Landauer | — | — | — | — | — | — | ●●● | — | — |
| Wheeler | ●●● | ● | ● | — | ● | ●● | ●● | — | ● |
| Laozi/Daoïsme | ●●● | ●● | ●●● | ● | ●● | — | ● | ●● | ● |
| Louria/Vital | ●●● | ●●● | ●●● | ●● | ●●● | — | ● | ●● | ●● |
| Heraclite | ● | ●●● | ●● | ● | ●●● | ●● | ● | ● | ● |
| Pythagoriciens | ●● | ●● | ●● | ●● | ●● | ●● | — | — | ● |
| Platon | ●●● | ●● | ●● | ●●● | ●● | ●● | — | ●● | ●● |

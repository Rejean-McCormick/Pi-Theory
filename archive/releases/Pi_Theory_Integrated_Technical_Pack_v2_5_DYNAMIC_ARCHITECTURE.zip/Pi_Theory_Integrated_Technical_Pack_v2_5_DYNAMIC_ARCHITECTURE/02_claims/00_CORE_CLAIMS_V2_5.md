# Claims centraux — v2.5

| ID | Claim | Statut |
|---|---|---|
| C01 | La fenêtre v13 produit les six blocs publiés sous les règles finales. | résultat interne / ex post |
| C02 | Les blocs peuvent être abstraits en fonctions dynamiques. | interprétation centrale |
| C03 | La structure la plus profonde est `division ↔ contre-mouvement de cohésion`. | métaphysique centrale |
| C04 | M est une impulsion persistante vers cohérence, non seulement un bloc initial. | canonique v2.5 |
| C05 | BIEN qualifie/oriente la cohérence plutôt que d'être une simple deuxième cause. | canonique v2.5 |
| C06 | GIHECEF/JNON forment un pulse différenciation ↔ intégration. | canonique |
| C07 | B0UM est prioritairement un seuil/changement de régime. | canonique |
| C08 | SIZE ouvre un problème de magnitude et potentiellement de changement d'échelle. | canonique/interprétatif |
| C09 | π exact est distinct de toute expansion numérique. | mathématique |
| C10 | Le principe originel ne doit pas être imaginé comme cercle physique avant l'espace. | canonique |
| C11 | Le terme recommandé est « principe pré-géométrique de circularité/cohérence ». | terminologie canonique |
| C12 | Une unité enrichie conserve les différences qu'elle intègre. | métaphysique centrale |
| C13 | La matière peut être comprise comme mémoire stabilisée de processus. | philosophie + analogues scientifiques |
| C14 | Les sciences de régulation/morphogenèse donnent des analogues de M. | convergence scientifique |
| C15 | Renormalisation/universalité est le cadre prioritaire pour la récursion multi-échelle. | programme scientifique |
| C16 | Vie et conscience exigent des mécanismes additionnels; elles ne suivent pas automatiquement de « cohérence ». | garde-fou |
| C17 | Les digits ultérieurs pourraient contenir des échos/mutations du kernel. | hypothèse testable |
| C18 | G0D/B0N sont secondaires et non une deuxième cosmogonie établie. | garde-fou |
| C19 | La thèse « le réel est spécifiquement résolution de π » reste métaphysique/non démontrée. | hypothèse forte |
| C20 | La scientificité future dépend d'une prédiction π-spécifique indépendante. | critère décisif |

# Sources académiques — mise à jour v2.3

## Sources web utilisées pour la carte des auteurs

- Stanford Encyclopedia of Philosophy — Empedocles / Presocratic Philosophy  
  https://plato.stanford.edu/entries/presocratics/

- Stanford Encyclopedia of Philosophy — Proclus  
  https://plato.stanford.edu/entries/proclus/

- Stanford Encyclopedia of Philosophy — Pseudo-Dionysius  
  https://plato.stanford.edu/entries/pseudo-dionysius-areopagite/

- Stanford Encyclopedia of Philosophy — John Scottus Eriugena  
  https://plato.stanford.edu/entries/scottus-eriugena/

- Stanford Encyclopedia of Philosophy — Nicolas of Cusa  
  https://plato.stanford.edu/entries/cusanus/

- Cambridge University Press — Jacob Boehme, contrariety and manifestation  
  https://www.cambridge.org/core/books/abs/gender-in-mystical-and-occult-thought/gender-in-the-works-of-jacob-boehme/6B7070976EA1C7DE2C42FB3C9C6B4FFD

- Stanford Encyclopedia of Philosophy — Whitehead  
  https://plato.stanford.edu/entries/whitehead/

- University of Minnesota Press — Simondon, *Individuation in Light of Notions of Form and Information*  
  https://www.upress.umn.edu/9780816680016/individuation-in-light-of-notions-of-form-and-information/

- Stanford Encyclopedia of Philosophy — Peirce's Theory of Signs  
  https://plato.stanford.edu/entries/peirce-semiotics/

- Stanford Encyclopedia of Philosophy — Weyl  
  https://plato.stanford.edu/entries/weyl/

- Stanford Encyclopedia of Philosophy — Symmetry and Symmetry Breaking  
  https://plato.stanford.edu/entries/symmetry-breaking/

- Stanford Encyclopedia of Philosophy — Gauge Theories / Noether  
  https://plato.stanford.edu/entries/gauge-theories/

- Encyclopedia of Mathematics — Erlangen Program  
  https://encyclopediaofmath.org/wiki/Erlangen_program

- Stanford Encyclopedia of Philosophy — Stoicism  
  https://plato.stanford.edu/entries/stoicism/

- Stanford Encyclopedia of Philosophy — Laozi / Daoism  
  https://plato.stanford.edu/entries/laozi/  
  https://plato.stanford.edu/entries/daoism/

- Nobel Prize — Ilya Prigogine, dissipative structures  
  https://www.nobelprize.org/prizes/chemistry/1977/summary/

- American Teilhard Association — timeline / complexity-consciousness / Omega discussions  
  https://teilharddechardin.org/

- Springer — pregeometric spaces and history of Wheeler's term "pregeometry"  
  https://link.springer.com/article/10.1007/s10773-024-05576-0

## Source interne dominante

`Pi v13 (2).docx`

Points particulièrement importants pour la v2.3 :
- cercle décrit comme parfaitement équilibré;
- M = initiating drive toward unity and beneficence;
- Love comme réponse à la division de l'unité;
- cercle qui « remembers unity »;
- GIHECEF = divider/processor;
- JNON = assembler/reuniter;
- B0UM = threshold event;
- 88 = SIZE;
- temporal lens / ongoing resolution;
- mirror G0D/B0N comme co-émergents secondaires.

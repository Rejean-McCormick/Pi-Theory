# Registre de sources — science du mécanisme v2.4

## Bioélectricité / morphogenèse
- Michael Levin et al. — *Bioelectrical controls of morphogenesis: from ancient mechanisms of cell coordination to biomedical opportunities*. Current Opinion in Genetics & Development (2019). PMID 31442749.
- Alexis Pietak & Michael Levin — *Bioelectrical control of positional information in development and regeneration*. Progress in Biophysics and Molecular Biology (2018). PMID 29626560.
- Michael Levin — *Morphogenetic fields in embryogenesis, regeneration, and cancer*. BioSystems (2012). PMID 22542702.
- Michael Levin — *Bioelectric signaling: Reprogrammable circuits underlying embryogenesis, regeneration, and cancer*. Cell (2021). PMID 33826908.

## Synergetics
- Hermann Haken — *Synergetics: Introduction and Advanced Topics*. Springer.
- Hermann Haken — *Synergetics: An Introduction*. Springer.

## Renormalisation
- Kenneth G. Wilson — *The Renormalization Group and Critical Phenomena*. Nobel Lecture, 8 Dec 1982.
- Leo Kadanoff — travaux sur block-spin/scaling.
- Michael E. Fisher — travaux sur scaling, universality and critical phenomena.

## Active matter
- Marchetti, Joanny, Ramaswamy et al. — *Hydrodynamics of soft active matter*. Reviews of Modern Physics 85, 1143 (2013).
- Bowick, Fakhri, Marchetti, Ramaswamy — *Symmetry, Thermodynamics, and Topology in Active Matter*. Physical Review X 12, 010501 (2022).

## Origine de la vie
- Wim Hordijk & Mike Steel — *Chasing the tail: The emergence of autocatalytic networks*. BioSystems (2017). PMID 28027958.

## Free Energy Principle
- Karl Friston — *The free-energy principle: a unified brain theory?* Nature Reviews Neuroscience 11 (2010).
- Karl Friston — *The free-energy principle: a rough guide to the brain?* Trends in Cognitive Sciences (2009).
- Bruineberg et al. / critiques de portée : littérature critique sur Markov blankets et universalisation du FEP, notamment *The Markov blanket trick* (2021), PMID 34563472.

## Information geometry
- Shun-ichi Amari — *Information Geometry and Its Applications*. Springer, 2016.

## Emergent spacetime
- Mark Van Raamsdonk — *Building up spacetime with quantum entanglement* (2010), arXiv:1005.3035.
- Mark Van Raamsdonk — *Lectures on Gravity and Entanglement* (2016), arXiv:1609.00026.

## Principe documentaire
Une source scientifique est citée uniquement pour le claim qu'elle soutient directement.
Exemple :
- Levin peut soutenir « des systèmes biologiques restaurent des formes globales par mécanismes bioélectriques ».
- Il ne soutient pas « M est une force cosmique issue de π ».

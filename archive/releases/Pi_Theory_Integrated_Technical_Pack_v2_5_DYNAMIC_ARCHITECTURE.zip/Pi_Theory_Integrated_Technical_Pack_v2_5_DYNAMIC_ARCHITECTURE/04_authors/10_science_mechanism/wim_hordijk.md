---
name: "Wim Hordijk"
dates: ""
domain: "origine de la vie / réseaux autocatalytiques"
priority: "A"
type: "science-mechanism"
---

# Wim Hordijk

## Pertinence
Travaux sur RAF theory et réseaux autocatalytiques.

## Pi Theory
Formalisation possible du passage :
`réseau chimique → auto-entretien → proto-autonomie`.

## À lire
- Hordijk & Steel, *Chasing the tail: The emergence of autocatalytic networks*.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

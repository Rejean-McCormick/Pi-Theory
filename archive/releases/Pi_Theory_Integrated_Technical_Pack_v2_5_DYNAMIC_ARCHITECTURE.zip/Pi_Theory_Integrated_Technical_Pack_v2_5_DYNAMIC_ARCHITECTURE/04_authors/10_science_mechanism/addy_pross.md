---
name: "Addy Pross"
dates: ""
domain: "chimie / origine de la vie"
priority: "B"
type: "science-mechanism"
---

# Addy Pross

## Pertinence
Approche de la stabilité dynamique et de l'émergence du vivant à partir de systèmes chimiques réplicatifs.

## Pi Theory
Intéressant pour cohérence persistante et sélection de systèmes dynamiques.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

---
name: "Karl Friston"
dates: "1959–"
domain: "neurosciences théoriques / active inference"
priority: "A/B"
type: "science-mechanism"
---

# Karl Friston

## Pertinence
Le FEP fournit un formalisme pour la persistance d'agents dans un ensemble restreint d'états via perception/action.

## Pi Theory
Analogie possible :
`M → retour vers états viables`
`BIEN → viability constraints`.

## Limite
Portée universelle controversée. Ne pas utiliser comme validation de M.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

---
name: "Mike Steel"
dates: ""
domain: "biomathématiques / réseaux autocatalytiques"
priority: "A"
type: "science-mechanism"
---

# Mike Steel

## Pertinence
Co-développement de RAF theory.

## Pi Theory
Permet de tester formellement des propriétés de clôture et auto-entretien dans des réseaux chimiques.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

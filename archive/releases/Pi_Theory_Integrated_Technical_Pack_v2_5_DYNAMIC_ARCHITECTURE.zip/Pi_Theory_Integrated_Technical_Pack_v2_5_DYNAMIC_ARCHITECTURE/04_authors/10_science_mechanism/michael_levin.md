---
name: "Michael Levin"
dates: "1969–"
domain: "biologie du développement / bioélectricité"
priority: "A+"
type: "science-mechanism"
---

# Michael Levin

## Pourquoi central
Levin étudie comment les cellules coordonnent leurs comportements vers des formes anatomiques globales, notamment par des réseaux bioélectriques.

## Pi Theory
Meilleur analogue expérimental actuel de :
`perturbation → contre-action distribuée → restauration de cohérence/form`.

## À lire
- *Bioelectrical controls of morphogenesis* (2019).
- *Morphogenetic fields in embryogenesis, regeneration, and cancer* (2012).
- *Bioelectric signaling: Reprogrammable circuits underlying embryogenesis, regeneration, and cancer* (2021).

## Limite
L'homeostasie morphologique biologique n'est pas la preuve d'une impulsion cosmique M.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

---
name: "M. Cristina Marchetti"
dates: ""
domain: "physique / active matter"
priority: "A"
type: "science-mechanism"
---

# M. Cristina Marchetti

## Pertinence
Théorie hydrodynamique des systèmes actifs et de l'ordre collectif loin de l'équilibre.

## Pi Theory
Analogue de cohérence émergente à partir d'agents locaux.

## À lire
- Marchetti et al., *Hydrodynamics of Soft Active Matter*, Rev. Mod. Phys. 85 (2013).

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

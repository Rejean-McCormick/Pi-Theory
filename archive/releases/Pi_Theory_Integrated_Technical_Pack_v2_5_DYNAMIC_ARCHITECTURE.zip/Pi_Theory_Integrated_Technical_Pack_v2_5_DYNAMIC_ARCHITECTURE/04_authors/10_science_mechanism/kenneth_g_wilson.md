---
name: "Kenneth G. Wilson"
dates: "1936–2013"
domain: "physique théorique / renormalisation"
priority: "A+"
type: "science-mechanism"
---

# Kenneth G. Wilson

## Pourquoi central
Le groupe de renormalisation permet d'étudier comment la description d'un système change avec l'échelle et comment apparaissent universalité et fixed points.

## Pi Theory
Indispensable pour SIZE et récursion multi-échelle.

## À lire
- Nobel Lecture: *The Renormalization Group and Critical Phenomena*.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

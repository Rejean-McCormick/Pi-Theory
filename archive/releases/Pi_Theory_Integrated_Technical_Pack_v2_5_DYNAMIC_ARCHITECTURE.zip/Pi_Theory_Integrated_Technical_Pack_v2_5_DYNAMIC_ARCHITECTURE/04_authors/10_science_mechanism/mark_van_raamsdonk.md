---
name: "Mark Van Raamsdonk"
dates: ""
domain: "gravité quantique / information quantique"
priority: "B"
type: "science-mechanism"
---

# Mark Van Raamsdonk

## Pertinence
Travaux sur le lien entre entanglement et émergence de connectivité géométrique dans l'holographie.

## Pi Theory
Important pour la possibilité d'un ordre relationnel pré-géométrique.

## À lire
- *Building up spacetime with quantum entanglement* (2010).

## Limite
Contexte AdS/CFT; aucune relation directe avec π.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

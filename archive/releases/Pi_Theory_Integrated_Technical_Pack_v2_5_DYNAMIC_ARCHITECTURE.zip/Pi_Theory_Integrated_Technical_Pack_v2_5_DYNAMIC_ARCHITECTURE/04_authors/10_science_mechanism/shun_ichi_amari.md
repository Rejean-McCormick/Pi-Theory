---
name: "Shun-ichi Amari"
dates: "1936–"
domain: "mathématiques / information geometry"
priority: "A/B"
type: "science-mechanism"
---

# Shun-ichi Amari

## Pertinence
Fondateur de l'information geometry.

## Pi Theory
Pont formel possible :
`information/différence → métrique → géométrie`.

## À lire
- *Information Geometry and Its Applications*.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

---
name: "Michael E. Fisher"
dates: "1931–2021"
domain: "physique statistique / critical phenomena"
priority: "A"
type: "science-mechanism"
---

# Michael E. Fisher

## Pertinence
Scaling, universalité et phénomènes critiques.

## Pi Theory
Aide à distinguer vraie universalité mathématique et simple ressemblance entre échelles.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

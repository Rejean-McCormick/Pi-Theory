---
name: "Leo Kadanoff"
dates: "1937–2015"
domain: "physique statistique / critical phenomena"
priority: "A"
type: "science-mechanism"
---

# Leo Kadanoff

## Pertinence
Block-spin transformations, scaling et criticalité.

## Pi Theory
Complète Wilson pour SIZE, coarse-graining et structure multi-échelle.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

---
name: "Sriram Ramaswamy"
dates: ""
domain: "physique statistique / active matter"
priority: "A"
type: "science-mechanism"
---

# Sriram Ramaswamy

## Pertinence
Pionnier de la physique de la matière active et des états collectifs hors équilibre.

## Pi Theory
Ordre immanent produit par interactions entre unités actives.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

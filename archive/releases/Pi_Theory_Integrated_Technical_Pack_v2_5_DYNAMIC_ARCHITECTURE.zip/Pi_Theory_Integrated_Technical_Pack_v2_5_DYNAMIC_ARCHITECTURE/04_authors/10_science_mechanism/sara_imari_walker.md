---
name: "Sara Imari Walker"
dates: ""
domain: "astrobiologie / origine de la vie / information"
priority: "A/B"
type: "science-mechanism"
---

# Sara Imari Walker

## Pertinence
Travaux contemporains sur causalité, information et origines de la vie.

## Pi Theory
Interlocutrice pour la transition entre chimie et systèmes où l'information devient causalement structurante.

## Limite
Ne pas confondre programmes en cours et consensus établi.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

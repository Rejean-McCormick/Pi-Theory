---
name: "Hermann Haken"
dates: "1927–2024"
domain: "physique théorique / synergetics"
priority: "A+"
type: "science-mechanism"
---

# Hermann Haken

## Pourquoi central
Fondateur de la synergetics : self-organization, order parameters, slaving principle.

## Pi Theory
Formalisation du passage :
`multiplicité → paramètre d'ordre → cohérence collective`.

## À lire
- *Synergetics: An Introduction*.
- *Synergetics: Introduction and Advanced Topics*.

## Règle d'usage
Cet auteur éclaire une pièce du mécanisme; il ne valide pas l'ontologie π-spécifique par autorité.

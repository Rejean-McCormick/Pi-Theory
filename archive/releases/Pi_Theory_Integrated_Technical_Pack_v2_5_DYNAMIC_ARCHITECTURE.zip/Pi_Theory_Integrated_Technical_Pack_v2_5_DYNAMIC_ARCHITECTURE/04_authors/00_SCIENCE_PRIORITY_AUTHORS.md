# Auteurs scientifiques prioritaires — v2.4

## Tier S — à intégrer directement au fil argumentatif

1. **Michael Levin** — bioélectricité, contrôle de forme, régénération.
2. **Hermann Haken** — synergetics, order parameters, self-organization.
3. **Kenneth Wilson** — renormalisation, échelle, universalité.
4. **Ilya Prigogine** — seuils et ordre hors équilibre.
5. **Alan Turing** — calcul + morphogenèse.
6. **Hermann Weyl** — symétrie, mesure, espace.
7. **Emmy Noether** — invariance et conservation.
8. **Claude Shannon** — information sans sémantique.
9. **Rolf Landauer** — physicalité de l'information.
10. **Francisco Varela** — autopoïèse/enaction.
11. **Terrence Deacon** — contraintes, fonction, émergence du sens.

## Tier A — mécanismes spécialisés

12. Leo Kadanoff — scaling.
13. Michael Fisher — criticality/universality.
14. M. Cristina Marchetti — active matter.
15. Sriram Ramaswamy — active matter.
16. Wim Hordijk — autocatalytic networks.
17. Mike Steel — RAF theory.
18. Karl Friston — active inference/FEP avec garde-fous.
19. Shun-ichi Amari — information geometry.
20. Mark Van Raamsdonk — entanglement/spacetime.
21. Walter Cannon — homeostasis.
22. W. Ross Ashby — regulation.
23. Norbert Wiener — feedback.
24. Stuart Kauffman — auto-organization/origin of life.
25. Sara Imari Walker — information/origin of life.

## Tier B — pré-géométrie et formalisation plus spéculative

- John Wheeler
- Carlo Rovelli
- Rafael Sorkin
- Roger Penrose
- Ted Jacobson
- Max Tegmark

## Principe de sélection

Les auteurs de Tier S sont prioritaires parce qu'ils permettent de remplacer des mots métaphysiques vagues par des problèmes techniques :

| Pi Theory | Domaine / auteur |
|---|---|
| M / retour | Levin + systèmes dynamiques |
| M / cohésion collective | Haken |
| BIEN / viabilité | contrôle + Varela + Friston (prudent) |
| Divide/Assemble | systems / network science |
| B0UM | Prigogine / bifurcations |
| SIZE | Wilson / Kadanoff / Fisher |
| invariant circulaire | Weyl / Noether |
| matière-information | Shannon / Landauer |
| matière→vie | autocatalyse / Turing / Varela |
| vie→sens | Deacon |
| pré-géométrie→espace | Wheeler / Van Raamsdonk |

# Registre des claims

| ID | Proposition | Niveau | Provenance | Statut |
|---|---|---|---|---|
| PT-C001 | Le pipeline final reproduit six blocs sur la fenêtre étudiée. | E1 | Pi v13 | active |
| PT-C002 | M peut être lu phonétiquement comme « aime » et associé à Love/cohésion. | E2 | Pi v13 | active |
| PT-C003 | BIEN donne directement un terme français de valeur positive. | E2 | Pi v13 | active |
| PT-C004 | GIHECEF est interprété comme opérateur de différenciation/traitement. | E2/E3 | Pi v13 | active |
| PT-C005 | JNON est interprété comme opérateur d'assemblage/réintégration. | E2/E3 | Pi v13 | active |
| PT-C006 | B0UM est lu comme boom/boum et événement de seuil/création. | E2/E3 | Pi v13 | active |
| PT-C007 | 88 supporte la chaîne 8+8=16→seize≈size. | E0+E2 | Pi v13 | active |
| PT-C008 | 88 peut être lu iconiquement comme dualité d'infini. | E2 | Pi v13 | active |
| PT-C009 | SIZE peut être étendu philosophiquement vers magnitude puis mesure. | E3/E4 | Pack intégré | active |
| PT-C010 | La différenciation et l'intégration forment le pulse central du kernel. | E3 | Pi v13 + synthèse | active |
| PT-C011 | Le kernel peut se répéter à plusieurs échelles. | E4 | Pi v13 + synthèse | hypothesis |
| PT-C012 | π exact doit être distingué de son développement en base 10. | E0 | Mathématiques + modèle b−1 | active |
| PT-C013 | Le cosmos pourrait être une manifestation/résolution d'une structure liée à π. | E4 | Pi Theory | hypothesis |
| PT-C014 | La matière peut être comprise philosophiquement comme mémoire stabilisée de processus. | E3/E4 | Synthèse | active |
| PT-C015 | La matière est spécifiquement mémoire de la résolution de π. | E5 | Pi Theory | unconfirmed |
| PT-C016 | e, π, i forment une triade utile pour variation continue, cycle et phase. | E0/E3 | 3 fundamental constants | active |
| PT-C017 | Toute cyclicité présuppose une variation continue. | — | ancienne formulation | downgraded |
| PT-C018 | Les règles du décodage étaient entièrement a priori/préenregistrées. | — | v12 | rejected |
| PT-C019 | La cohérence observée a déjà une probabilité extrêmement faible quantifiée. | — | v12/v13 objection section | unestablished |
| PT-C020 | Rosetta peut servir de moteur prédictif si les prédictions sont faites avant inspection. | E3→testable | Pack intégré | active |
